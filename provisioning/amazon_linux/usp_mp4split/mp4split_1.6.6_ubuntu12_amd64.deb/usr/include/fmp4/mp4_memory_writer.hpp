/*******************************************************************************
 mp4_memory_writer.hpp - A library for writing to a memory buffer.

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_MEMORY_WRITER_HPP_AKW
#define MP4_MEMORY_WRITER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_platform.hpp"
#include "mp4_types.hpp"
#include <inttypes.h>
#include <string>
#include <vector>

namespace fmp4
{

MP4_DLL_LOCAL inline void write_8(uint8_t* buffer, unsigned int v)
{
  buffer[0] = (uint8_t)(v >> 0);
}

MP4_DLL_LOCAL inline void write_16(uint8_t* buffer, unsigned int v)
{
#if defined(FMP4_FAST_UNALIGNED) && defined(FMP4_LITTLE_ENDIAN)
  *(reinterpret_cast<uint16_t*>(buffer)) = mp4_byteswap16(v);
#else
  buffer[0] = (uint8_t)(v >> 8);
  buffer[1] = (uint8_t)(v >> 0);
#endif
}

MP4_DLL_LOCAL inline void write_24(uint8_t* buffer, unsigned int v)
{
  buffer[0] = (uint8_t)(v >> 16);
  buffer[1] = (uint8_t)(v >> 8);
  buffer[2] = (uint8_t)(v >> 0);
}

MP4_DLL_LOCAL inline void write_32(uint8_t* buffer, unsigned int v)
{
#if defined(FMP4_FAST_UNALIGNED) && defined(FMP4_LITTLE_ENDIAN)
  *(reinterpret_cast<uint32_t*>(buffer)) = mp4_byteswap32(v);
#else
  buffer[0] = (uint8_t)(v >> 24);
  buffer[1] = (uint8_t)(v >> 16);
  buffer[2] = (uint8_t)(v >> 8);
  buffer[3] = (uint8_t)(v >> 0);
#endif
}

MP4_DLL_LOCAL inline void write_64(uint8_t* buffer, uint64_t v)
{
#if defined(FMP4_FAST_UNALIGNED) && defined(FMP4_LITTLE_ENDIAN)
  *(reinterpret_cast<uint64_t*>(buffer)) = mp4_byteswap64(v);
#else
  write_32(buffer + 0, (uint32_t)(v >> 32));
  write_32(buffer + 4, (uint32_t)(v >> 0));
#endif
}

MP4_DLL_LOCAL inline void write_128(uint8_t* buffer, uint128_t const& v)
{
  write_64(buffer + 0, v.hi_);
  write_64(buffer + 8, v.lo_);
}

class MP4_DLL_EXPORT memory_writer
{
public:
  memory_writer(uint8_t* buffer, std::size_t size);

  uint64_t tell() const
  {
    return pos_;
  }

  uint8_t* get_write_ptr()
  {
    return buffer_ + pos_;
  }

  void write_8(unsigned int v)
  {
    fmp4_assert_debug(pos_ + 1 <= size_);
    fmp4::write_8(buffer_ + pos_, v);
    pos_ += 1;
  }

  void write_16(unsigned int v)
  {
    fmp4_assert_debug(pos_ + 2 <= size_);
    fmp4::write_16(buffer_ + pos_, v);
    pos_ += 2;
  }

  void write_24(unsigned int v)
  {
    fmp4_assert_debug(pos_ + 3 <= size_);
    fmp4::write_24(buffer_ + pos_, v);
    pos_ += 3;
  }

  void write_32(unsigned int v)
  {
    fmp4_assert_debug(pos_ + 4 <= size_);
    fmp4::write_32(buffer_ + pos_, v);
    pos_ += 4;
  }

  void write_64(uint64_t v)
  {
    fmp4_assert_debug(pos_ + 8 <= size_);
    fmp4::write_64(buffer_ + pos_, v);
    pos_ += 8;
  }

  void write_128(uint128_t const& v)
  {
    fmp4_assert_debug(pos_ + 16 <= size_);
    fmp4::write_128(buffer_ + pos_, v);
    pos_ += 16;
  }

  void write(char const* first, char const* last);
  void write(uint8_t const* first, uint8_t const* last);
  void write(std::vector<uint8_t> const& vec);
  void write_base64(uint8_t const* first, uint8_t const* last);

  // write string including zero-terminator
  void write_str(std::string const& str);

  void write_n(unsigned int n, uint32_t v);
//void write_utf16le(wchar_t const* first, wchar_t const* last);
//void write_utf16le(char const* first, char const* last);

  void fill(uint32_t size, uint8_t v);

private:
  uint8_t* buffer_;
  std::size_t size_;
  uint64_t pos_;
};

struct bitstream_writer_t
{
  bitstream_writer_t(uint8_t* first, uint8_t* last);

  void write_bit(unsigned int v);
  void write_boolean(bool v);
  void write_bits(int bits, unsigned int v);
  void write_ue(unsigned int v);
  void write_se(int v);

  std::size_t tell();

private:
  uint8_t* first_;
  uint8_t* last_;
  unsigned int index_;
};

} // namespace fmp4

#endif // MP4_MEMORY_WRITER_HPP_AKW

// End Of File



/*******************************************************************************
 mp4_pool.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_POOL_HPP_AKW
#define MP4_POOL_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <iosfwd>
#include <string>
#include <map>
#include <set>

struct mp4_process_context_t;
struct fmp4_handler_io_t;

namespace fmp4 {
  struct mp4_context_t;
}

struct MP4_DLL_EXPORT pool_t
{
private:
  pool_t(pool_t const& rhs);
  pool_t& operator=(pool_t rhs);

public:
  explicit pool_t(mp4_process_context_t& context);
  ~pool_t();

  void string_must_exist(char const* p);

  char const* get_string(std::string const& str);

  fmp4_handler_io_t& get_handler_io(char const* filename);
  fmp4_handler_io_t& get_handler_io(std::string const& filename);

  fmp4_result get_mp4_context(fmp4_handler_io_t& src_io,
                              int open_flags, int must_exist_flags,
                              fmp4::mp4_context_t*& mp4_context);

private:
  mp4_process_context_t& context_;

  typedef std::map<char const*, fmp4_handler_io_t*> files_t;
  files_t files_;

  typedef std::set<std::string> strings_t;
  strings_t strings_;

  struct cached_context_t
  {
    cached_context_t(fmp4::mp4_context_t* context, int open_flags)
    : context_(context)
    , open_flags_(open_flags)
    {
    }
    fmp4::mp4_context_t* context_;
    int open_flags_;
  };

  typedef std::map<fmp4_handler_io_t*, cached_context_t> mp4_contexts_t;
  mp4_contexts_t mp4_contexts_;
};

#endif // MP4_POOL_HPP_AKW

// End Of File



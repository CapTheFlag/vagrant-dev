/*******************************************************************************
 mp4_handler_io.hpp -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_HANDLER_IO_HPP_AKW
#define MP4_HANDLER_IO_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_counted_ptr.hpp"
#include <inttypes.h>
#include <string>
#include <memory>
#include <list>

struct fmp4_handler_io_t;

namespace fmp4 {

// The io_cached_range is a base class holding a range of bytes. Either from
// a file (a filemapping) or http (a byte array). It is the unit which is
// cached by the fmp4_handler_io class and ranges/references are made available
// through the io_buf class which is returned by the get_read_buf and
// get_write_buf functions.
//
// When there are no more references (either from a io_buf or the
// fmp4_handler_io cache) then it is the reponsibility of this class to free
// any allocated resources (e.g. a file mapping, or a memory buffer).

class io_cached_range
{
public:
  io_cached_range()
  : offset_(0)
  , size_(0)
  {
  }

  virtual ~io_cached_range() = 0;

  virtual void* get_base() = 0;

  uint64_t offset_;
  uint32_t size_;
};

typedef counted_ptr<io_cached_range> io_cached_range_ptr;

// A simple cache for io_cached_range classes. It keeps the recently used
// io_cached_range and when a new entry is inserted it may remove an entry in
// the cache that is no longer referenced.

class io_cache_t
{
public:
  void insert(io_cached_range_ptr const& io_cached_range);
  io_cached_range_ptr find(uint64_t offset, uint32_t len) const;

private:
  typedef std::list<io_cached_range_ptr> io_cached_ranges_t;
  io_cached_ranges_t io_cached_ranges_;
};

// The io_buf structure is returned by the fmp4_handler_io. You can use the
// get_read_ptr and get_write_ptr functions to get a pointer to the data for
// reading or writing.
//
// The io_cached_range is an underlying reference counted pointer which holds
// the actual data. It is the responsibility of the derived implementation to
// free any allocated resources.
//
// Each fmp4_handler_io has its own cache. Since fmp4_handler_io's are
// cached themselves (one for a unique file/url) in the pool, we get a nice
// hit ratio. MP4 boxes are mostly read just once (moov, mfra, etc...)

class MP4_DLL_EXPORT io_buf
{
private:
  io_buf(io_buf const& rhs);
  io_buf& operator=(io_buf const& rhs);

public:
  io_buf(io_cached_range_ptr io_cached_range, uint64_t offset, uint32_t size);

  const void* get_read_ptr() const;

  void* get_write_ptr() const;

  uint64_t offset() const
  {
    return offset_;
  }

  uint32_t size() const
  {
    return size_;
  }

private:
  io_cached_range_ptr io_cached_range_;
  uint64_t offset_;
  uint32_t size_;
};

typedef counted_ptr<io_buf> io_buf_ptr;

MP4_DLL_EXPORT extern
fmp4_handler_io_t* create_handler_io(char const* url, int flags);

} // namespace fmp4

struct MP4_DLL_EXPORT fmp4_handler_io_t
{
private:
  fmp4_handler_io_t(fmp4_handler_io_t const& rhs);
  fmp4_handler_io_t& operator=(fmp4_handler_io_t const& rhs);

public:
  static uint64_t const OFFSET_END;
  static uint64_t const SIZE_UNKNOWN;

  enum
  {
    read_only = 0,
    write_only = 1,
    read_write = 2
  };

protected:
  fmp4_handler_io_t(char const* url, int flags);

  bool is_read_only() const;
  bool is_write_only() const;

public:
  virtual ~fmp4_handler_io_t();

  // set any additional options
  // e.g. the http handler supports 'cookie'
  virtual fmp4_result set_option(char const* name, char const* value);

  // get any additional information
  // e.g. the http handler supports 'effective_url'
  virtual fmp4_result get_info(char const* name, std::string& value);

  std::string const& get_url() const;

  // returns the size of the file
  virtual fmp4_result size(uint64_t& filesize) = 0;

  // read only functions
  virtual fmp4_result get_read_buf(fmp4::io_buf_ptr& io_buf,
                                   uint64_t offset, uint32_t len) = 0;

  // write only functions
  virtual fmp4_result get_write_buf(fmp4::io_buf_ptr& io_buf,
                                    uint64_t offset, uint32_t len) = 0;
  virtual fmp4_result flush(fmp4::io_buf_ptr& buf) = 0;
  virtual fmp4_result resize(uint64_t new_size) = 0;

protected:
  // Scans the io_cache to see if the range is already available. If it is
  // the buffer is returned in 'buf'.
  bool is_cached(fmp4::io_buf_ptr& buf, uint64_t offset, uint32_t len) const;

protected:
  std::string url_;
  int flags_;
  uint64_t size_;
  fmp4::io_cache_t io_cache_;
};

#endif // MP4_HANDLER_IO_HPP_AKW

// End Of File


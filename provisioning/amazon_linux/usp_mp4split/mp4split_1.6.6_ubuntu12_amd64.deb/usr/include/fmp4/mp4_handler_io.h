/*******************************************************************************
 mp4_handler_io.h -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_HANDLER_IO_H_AKW
#define MP4_HANDLER_IO_H_AKW

#include "mod_streaming_export.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

struct fmp4_handler_io_t;

MP4_DLL_EXPORT extern
struct fmp4_handler_io_t* create_handler_io_no_mmap(char const* url, int flags);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MP4_HANDLER_IO_H_AKW

// End Of File


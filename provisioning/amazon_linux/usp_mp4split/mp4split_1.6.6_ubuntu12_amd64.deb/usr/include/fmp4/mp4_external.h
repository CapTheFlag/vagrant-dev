/*******************************************************************************
 mp4_external.h -

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_EXTERNAL_H_AKW
#define MP4_EXTERNAL_H_AKW

#include "mod_streaming_export.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

// The functions below are used to create a fragmented MP4 movie presentation.
//
// You start by creating a new movie and then adding audio/video tracks to the
// movie, specifying the attributes of the tracks (bitrate, codec, etc...).
// After this multiple movie fragments (moof boxes) are created. A new movie
// fragment starts on a video keyframe (in general between 2 and 4 seconds), or
// when it's an audio only movie then a fixed duration is picked.
//
// For an example see external_unit_test.cpp

////////////////////////////////////////////////////////////////////////////////

// Initialize a new movie presentation. Set is_live to 1 when this is a live
// presentation. When is_live is 0 it is a VOD presentation.
//
// For Vod a movie fragment random access box (mfra) is generated and stored at
// the end of the movie presentation.
//
// For Live two additional boxes are generated to make it compatible
// with a publishing point. An initial stream box (that includes the manifest
// of the streams being published) is inserted as well as a tfxd box in each
// moof box with the decoding timestamp of the first sample and the duration of
// the movie fragment.

MP4_DLL_EXPORT extern void* mp4_movie_init(int is_live);

// Destruct a movie presentation. Must be called to clean up any resources.

MP4_DLL_EXPORT extern void mp4_movie_exit(void* mp4_movie);

// Set encryption / DRM options for the movie presentation.
// url - the license acquisition URL
// kid - the 128-bit key id
// cek - the 128-bit content encryption key
// iv - the 128-bit random initialization vector

MP4_DLL_EXPORT extern void mp4_movie_add_playready(void* mp4_movie,
                                                   char const* url, 
                                                   unsigned char const kid[16],
                                                   unsigned char const cek[16],
                                                   unsigned char const iv[16]);

// Add a new track to the movie presentation

MP4_DLL_EXPORT extern void* mp4_movie_add_track(void* mp4_movie);

// Returns the size of the stream box.

MP4_DLL_EXPORT extern unsigned int mp4_movie_smil_size(void* mp4_movie);


// Output the server manifest file (for Live presentations only) in a
// stream-box. This is to announce the stream(s) to the publishing point.

MP4_DLL_EXPORT extern unsigned int mp4_movie_smil_write(void* mp4_movie, unsigned char* p);

// Returns the size of the ftyp box.

MP4_DLL_EXPORT extern unsigned int mp4_movie_ftyp_size(void* mp4_movie);

// Writes the ftyp box

MP4_DLL_EXPORT extern void mp4_movie_ftyp_write(void* mp4_movie, unsigned char* p);

// Returns the size of the moov box.

MP4_DLL_EXPORT extern unsigned int mp4_movie_moov_size(void* mp4_movie);

// Writes the moov box

MP4_DLL_EXPORT extern void mp4_movie_moov_write(void* mp4_movie, unsigned char* p);

// Returns the size of the mfra box.

MP4_DLL_EXPORT extern unsigned int mp4_movie_mfra_size(void* mp4_movie);

// Writes the mfra box.

MP4_DLL_EXPORT extern void mp4_movie_mfra_write(void* mp4_movie, unsigned char* p);

// Adds an index to the track fragment random acces box for the specified track,
// timestamps and file offset. (Only for VOD)

MP4_DLL_EXPORT extern void mp4_movie_tfra_add(void* mp4_movie, uint32_t track_index,
                                              uint64_t dts, uint64_t moof_offset);

// Sets the total time of the movie presentation. (Only for VOD).

MP4_DLL_EXPORT extern void mp4_movie_set_duration(void* mp4_movie, uint64_t duration);

// Starts a new movie fragment for the specified track starting at timestamp
// dts.

MP4_DLL_EXPORT extern void mp4_movie_moof_add(void* mp4_movie, unsigned int track_index, uint64_t dts);

// Add the given sample to the current movie fragment.
// track_index - the track the sample belongs to
// dts - the decode timestamp of the sample
// pts - the presentation timestamps of the sample
// duration - the duration of the sample
// frame_type - (for video only). 0 = IDR frame, 1 = P frame, 2 = B frame
// first - the first byte of the sample data
// last - one past the end of the sample data
//
// For H.264 / AVC the sample data needs to be in MP4 format (i.e. using NAL
// sizes, instead of a Annex-B start codes). One video sample must be exactly
// one video picture.
//
// For AAC audio the sample is a raw AAC frame. If your input has ADTS headers,
// then you need to skip the ADTS header (7 or 9 bytes). One audio sample must
// be exactly one AAC frame.

MP4_DLL_EXPORT extern void mp4_movie_sample_add(void* mp4_movie, unsigned int track_index, int64_t dts, int64_t pts,
                          uint64_t duration, unsigned int frame_type,
                          unsigned char* first, unsigned char *last);

// Returns the size of the moof box.

MP4_DLL_EXPORT extern unsigned int mp4_movie_moof_size(void* mp4_movie, unsigned int track_index);

// Writes the moof box.

MP4_DLL_EXPORT extern unsigned int mp4_movie_moof_write(void* mp4_movie, unsigned int track_index, unsigned char* p);

// Initialize a track previously created with mp4_movie_add_track
// bitrate - the bitrate of the track
// language - the language in ISO 639-2 format (e.g. 'eng', 'spa', 'chi', 'und')
// fourcc - the fourCC code of the codec (AVC1, AACL)
// track_id - the id of the track (starting at 1)
// track_name - the name of the track (e.g. 'audio', 'video', 'audio_eng')
// timescale - the timescale of the timestamps (e.g. 25, 90000, 44100)
// parent_track_name - always 0
// manifest_output - always 0
// private_data_data - the codec private data.
// For H.264 / AVC video this can be either:
//     - an avcC record or
//     - an SPS NAL unit followed by a PPS NAL unit (in Annex B format).
// For AAC audio this is the AudioSpecificConfig record as described by ISO/IEC 14496 Part 3 Audio in subclause 1.6.2.1 (Table 1.13).

// private_data_size - the size of the codec private data

MP4_DLL_EXPORT extern
int mp4_track_set(void* mp4_movie,
                  void* mp4_track,
                  uint32_t bitrate,
                  char const* language,
                  uint32_t fourcc,
                  uint32_t track_id,
                  char const* track_name,
                  uint32_t timescale,
                  char const* parent_track_name,
                  int manifest_output,
                  uint8_t const* private_data_data,
                  uint32_t private_data_size);

// Specific initialization for a video track.
// nal_unit_length_field = 4
// width - width of the video in pixels
// height - height of the video in pixels
// display_width = width of the video in pixels (after applying aspect ratio)
// display_height = height of the video in pixels (after applying aspect ratio)

MP4_DLL_EXPORT extern void
mp4_track_set_video(void* mp4_track,
                    unsigned int nal_unit_length_field,
                    unsigned int width,
                    unsigned int height,
                    unsigned int display_width,
                    unsigned int display_height);

// Specific initialization for an audio track
// samplerate - the samplerate in Hz
// channels - the number of audio channels
// sample_size - the number of bits per sample (16)
// packet_size - specific to the audio codec used
// audio_tag - 85 = MP3, 255 = AAC

MP4_DLL_EXPORT extern void
mp4_track_set_audio(void* mp4_track,
                    unsigned int samplerate,
                    unsigned int channels,
                    unsigned int sample_size,
                    unsigned int packet_size,
                    unsigned int audio_tag);

// Specific initialization for a text track.
// subtype - SCMD, CHAP, SUBT, CAPT, DESC, CTRL, DATA

MP4_DLL_EXPORT extern void
mp4_track_set_text(void* mp4_track,
                   char const* subtype);

// Specific initialization for a data track.

MP4_DLL_EXPORT extern void
mp4_track_set_data(void* mp4_track);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MP4_EXTERNAL_H_AKW

// End Of File



/*******************************************************************************
 mp4_rewrite.h - Rewriting URLs

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_REWRITE_H_AKW
#define MP4_REWRITE_H_AKW

#include "mod_streaming_export.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

MP4_DLL_EXPORT extern
int mp4_rewrite_url(char const* path_first, char const* path_last,
                    char const* args_first, char const* args_last,
                    char* path_out, unsigned int path_size,
                    char* args_out, unsigned int args_size,
                    unsigned int rewrite_ism,
                    unsigned int rewrite_f4f);

MP4_DLL_EXPORT extern
void mp4_rewrite_dir(char const* path_first, char const* path_last,
                     char* path_out, unsigned int path_size);

MP4_DLL_EXPORT extern
int mp4_rewrite_test();

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MP4_REWRITE_H_AKW

// End Of File


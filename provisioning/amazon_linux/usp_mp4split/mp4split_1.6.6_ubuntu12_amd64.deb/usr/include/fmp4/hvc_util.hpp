/*******************************************************************************
 hvc_util.hpp - HVC utility functions

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef HVC_UTIL_HPP_AKW
#define HVC_UTIL_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <list>

namespace fmp4
{

namespace hvc
{

enum nal_type_t
{
  NAL_TRAIL_N = 0,
  NAL_TRAIL_R = 1,
  NAL_TSA_N = 2,
  NAL_TSA_R = 3,
  NAL_STSA_N = 4,
  NAL_STSA_R = 5,
  NAL_RADL_N = 6,
  NAL_RADL_R = 7,
  NAL_RASL_N = 8,
  NAL_RASL_R = 9,
  NAL_RSV_VCL_N10 = 10,
  NAL_RSV_VCL_R11 = 11,
  NAL_RSV_VCL_N12 = 12,
  NAL_RSV_VCL_R13 = 13,
  NAL_RSV_VCL_N14 = 14,
  NAL_RSV_VCL_R15 = 15,
  NAL_BLA_W_LP = 16,
  NAL_BLA_W_DLP = 17,
  NAL_BLA_N_LP = 18,
  NAL_IDR_W_DLP = 19,
  NAL_IDR_N_LP = 20,
  NAL_CRA_NUT = 21,
  NAL_RSV_RAP_VCL22 = 22,
  NAL_RSV_RAP_VCL23 = 23,
  NAL_RSV_VCL24 = 24,
  NAL_RSV_VCL25 = 25,
  NAL_RSV_VCL26 = 26,
  NAL_RSV_VCL27 = 27,
  NAL_RSV_VCL28 = 28,
  NAL_RSV_VCL29 = 29,
  NAL_RSV_VCL30 = 30,
  NAL_RSV_VCL31 = 31,
  NAL_VPS_NUT = 32,
  NAL_SPS_NUT = 33,
  NAL_PPS_NUT = 34,
  NAL_AUD_NUT = 35,
  NAL_EOS_NUT = 36,
  NAL_EOB_NUT = 37,
  NAL_FD_NUT = 38,
  NAL_PREFIX_SEI_NUT = 39,
  NAL_SUFFIX_SEI_NUT = 40,
  NAL_RSV_NVCL41 = 41,
  NAL_RSV_NVCL42 = 42,
  NAL_RSV_NVCL43 = 43,
  NAL_RSV_NVCL44 = 44,
  NAL_RSV_NVCL45 = 45,
  NAL_RSV_NVCL46 = 46,
  NAL_RSV_NVCL47 = 47,
  NAL_UNSPEC48 = 48,
  NAL_UNSPEC49 = 49,
  NAL_UNSPEC50 = 50,
  NAL_UNSPEC51 = 51,
  NAL_UNSPEC52 = 52,
  NAL_UNSPEC53 = 53,
  NAL_UNSPEC54 = 54,
  NAL_UNSPEC55 = 55,
  NAL_UNSPEC56 = 56,
  NAL_UNSPEC57 = 57,
  NAL_UNSPEC58 = 58,
  NAL_UNSPEC59 = 59,
  NAL_UNSPEC60 = 60,
  NAL_UNSPEC61 = 61,
  NAL_UNSPEC62 = 62,
  NAL_UNSPEC63 = 63
};

MP4_DLL_EXPORT extern char const* to_string(nal_type_t nal_type);

// 7.3.3 profile, tier and level
struct profile_tier_level_t
{
  profile_tier_level_t();

  uint8_t general_profile_space_;
  uint8_t general_tier_flag_;
  uint8_t general_profile_idc_;
  uint32_t general_profile_compatibility_flags_;
  uint16_t general_reserved_zero_16bits_;
  uint8_t general_level_idc_;
  uint8_t sub_layer_profile_present_flag_;
  uint8_t sub_layer_level_present_flag_;

  uint8_t sub_layer_profile_space_[8];
  bool sub_layer_tier_flag_[8];
  uint8_t sub_layer_profile_idc_[8];
  uint32_t sub_layer_profile_compatibility_flags_[8];
  uint16_t sub_layer_reserved_zero_16bits_[8];
  uint8_t sub_layer_level_idc_[8];
};

// 7.3.2.1 video parameter set
struct video_parameter_set_t
{
  video_parameter_set_t();

  uint8_t vps_video_parameter_set_id_;
  uint8_t vps_reserved_three_2bits_;
  uint8_t vps_reserved_zero_6bits_;
  uint8_t vps_max_sub_layers_minus1_;
  bool vps_temporal_id_nesting_flag_;
  uint16_t vps_reserved_0xffff_16bits_;

  profile_tier_level_t profile_tier_level_;
#if 0
  bit_rate_pic_rate_info_t bit_rate_pic_rate_info_;

  bool vps_sub_layer_ordering_info_present_flag_;
  uint8_t vps_max_dec_pic_buffering_[8];
  uint8_t vps_max_num_reorder_pics_[8];
  uint8_t vps_max_latency_increase_[8];

  uint8_t vps_max_nuh_reserved_zero_layer_id_;
  uint8_t vps_num_op_sets_minus1_;
#endif
};

// parse the (emulation prevented) Video Parameter Set
MP4_DLL_LOCAL extern
fmp4_result read(video_parameter_set_t& vps,
                 uint8_t const* first, uint8_t const* last);

#if 0
struct vui_parameters_t
{
  static uint8_t const Extended_SAR;

  vui_parameters_t();

  bool aspect_ratio_info_present_flag_;
  uint8_t aspect_ratio_idc_;
  uint16_t sar_width_;
  uint16_t sar_height_;
  bool overscan_info_present_flag_;
  bool overscan_appropriate_flag_;
  bool video_signal_type_present_flag_;
  uint8_t video_format_;
  bool video_full_range_flag_;
  bool colour_description_present_flag_;
  uint8_t colour_primaries_;
  uint8_t transfer_characteristics_;
  uint8_t matrix_coefficients_;
  bool chroma_loc_info_present_flag_;
  uint32_t chroma_sample_loc_type_top_field_;
  uint32_t chroma_sample_loc_type_bottom_field_;

  bool neutral_chroma_indication_flag_;
  bool field_seq_flag_;
  bool frame_field_info_present_flag_;
  bool default_display_window_flag_;
  uint32_t def_disp_win_left_offset_;
  uint32_t def_disp_win_right_offset_;
  uint32_t def_disp_win_top_offset_;
  uint32_t def_disp_win_bottom_offset_;
  
  bool hrd_parameters_present_flag_;
  hrd_parameters_t hrd_parameters_;
};

// 7.3.2.2 sequence parameter set
struct sequence_parameter_set_t
{
  sequence_parameter_set_t();

  uint8_t sps_video_parameter_set_id_;
  uint8_t sps_max_sub_layers_minus1_;
  uint8_t sps_temporal_id_nesting_flag_;
  uint8_t sps_seq_parameter_set_id_;
  uint8_t chroma_format_idc_;
  bool separate_colour_plane_flag_;
  uint32_t pic_width_in_luma_samples_;
  uint32_t pic_height_in_luma_samples_;
  bool conformance_window_flag_;
  uint32_t conf_win_left_offset_;
  uint32_t conf_win_right_offset_;
  uint32_t conf_win_top_offset_;
  uint32_t conf_win_bottom_offset_;

  uint32_t bit_depth_luma_minus8_;
  uint32_t bit_depth_chroma_minus8_;
  uint32_t log2_max_pic_order_cnt_lsb_minus4_;

  bool sps_sub_layer_ordering_info_present_info_;
  uint8_t sps_max_dec_pic_buffering_[8];
  uint8_t sps_max_num_reorder_pics_[8];
  uint8_t sps_max_latency_increase_[8];

  uint32_t log2_min_luma_coding_block_size_minus3_;
  uint32_t log2_diff_max_min_luma_coding_block_size_;
  uint32_t log2_min_transform_block_size_minus2_;
  uint32_t log2_diff_max_min_transform_block_size_;
  uint32_t max_transform_hierarchy_depth_inter_;
  uint32_t max_transform_hierarchy_depth_intra_;
  bool scaling_list_enable_flag_;

  bool sps_scaling_list_data_present_flag_;
  scaling_list_data();

  bool amp_enabled_flag_;
  bool sample_adaptive_offset_enabled_flag_;
  bool pcm_enabled_flag_;
  uint8_t pcm_sample_bit_depth_luma_minus1_;
  uint8_t pcm_sample_bit_depth_chroma_minus1_;
  uint32_t log2_min_pcm_luma_coding_block_size_minus3_;
  uint32_t log2_diff_max_min_pcm_luma_coding_block_size_;
  bool pcm_loop_filter_disable_flag_;

  uint32_t num_short_term_ref_pic_sets_;
  short_term_ref_pic_set(i);

  bool long_term_ref_pics_present_flag_;
  uint32_t num_long_term_ref_pics_sps_;
  uint32_t ltref_pic_poc_lsb_sps_[xx];
  uint32_t used_by_curr_pic_lt_sps_flag_[xx];

  bool sps_temporal_mvp_enable_flag_;
  bool strong_intra_smoothing_enable_flag_;
  bool vui_parameters_present_flag_;
  vui_parameters_t vui_parameters_;
};
#endif

} // namespace hvc

} // namespace fmp4

#endif // HVC_UTIL_HPP_AKW

// End Of File


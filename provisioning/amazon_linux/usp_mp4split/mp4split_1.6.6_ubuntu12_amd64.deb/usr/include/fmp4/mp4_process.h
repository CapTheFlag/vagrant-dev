/*******************************************************************************
 mp4_process.h -

 Copyright (C) 2007-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_PROCESS_H_AKW
#define MP4_PROCESS_H_AKW

// enable use of key check / policy file
#define HAVE_POLICY

#include "mod_streaming_export.h"
#include "mp4_error.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

// Following section carries a global init/exit function which should be 
// called as first and as last function of the API (before and after 
// anything else) 

typedef struct mp4_global_context_t mp4_global_context_t;

MP4_DLL_EXPORT extern
mp4_global_context_t* libfmp4_global_init();

MP4_DLL_EXPORT extern
void libfmp4_global_exit(mp4_global_context_t* gctx);

MP4_DLL_EXPORT extern
char const* libfmp4_policy_check(mp4_global_context_t* gctx,
                                 char const* src,
                                 char const* version,
                                 char const* license);

MP4_DLL_EXPORT extern
char const* libfmp4_read_policy_file(char const* src,
                                     char const* filename);

MP4_DLL_EXPORT extern
int libfmp4_is_policy_available(mp4_global_context_t* gctx, 
                                char const* key);

// API data types

struct buckets_t;
struct mp4_split_options_t;

// Hook to override the default behaviour of reading a fragment. USP supports
// both reading the fragment from file or via http.
//
// The callback must return a pointer to the fragment with timestamp 'dts'. The
// format of the data must be an MP4 fragment (moof + mdat). The moof box must
// contain a track fragment for the requested track_id.
//
// To identify the underlying source of the fragment you can use either one
// of the following combinations:
//
// 1. track_name - bitrate or
// 2. filename - track_id
//
// Both combinations are unique. The track_name is the name specified in the
// server manifest file. The filename is a concatenation of the path where
// the server manifest file is located and the stream_id used to publish the
// stream.
//
// user_index is a user defined field (used in combination with the
// pubpoint_add_empty_fragment function).
//
// For example:
//
// get_fragment(dts=900693333,
//              track_name=audio, bitrate=65000,
//              filename=/var/www/test/oceans.ssml/oceans-64k.ismv, track_id=1)
//
// You must set size to the size of the fragment (moof + mdat). In case of an
// error, you must return NULL.

typedef unsigned char const* (*get_fragment_callback_t)(
  void* context,
  uint64_t dts,
  char const* track_name, unsigned int bitrate,
  char const* filename, unsigned int track_id,
  uint32_t user_index,
  uint32_t* size);

// Hook to process a fragment after it has been read from file/http or by the
// get_fragment_callback.
//
// This hook is useful in the case when the stored stream is already encrypted
// and it needs to be decrypted first before muxing to HLS or HDS.
//
// On input the buckets hold any number of moof/mdat MP4 fragment pairs.
//
// After processing the input buckets, the buckets need to be cleared and the
// output has to be written to the buckets.
//
// Returns FMP4_OK or any of the errors specified in mp4_error.h
//
// An example pass-through filter would be as follows:
//
// fmp4_result get_fragment_post(void* context, buckets_t* buckets)
// {
//   // read the input buckets into memory (from either memory, file or http).
//   uint64_t src_size = buckets_size(buckets, NULL);
//   uint8_t* src = malloc(src_size);
//   FMP4_CHECK(buckets_flatten(buckets, NULL, src));
//
//   // throw away the buckets, so we can write our new data to it.
//   buckets_clear(buckets);
//
//   // process 'src', decrypt, etc... For now we just pass-through the data.
//   std::size_t dst_size = src_size;
//   uint8_t* dst = malloc(dst_size);
//   std::copy(src, src + src_size, dst);
//
//   // copy the processed data (dst) with size (dst_size) into the buckets.
//   bucket_insert_tail(buckets, bucket_heap_create(dst, dst_size));
//
//   free(dst);
//   free(src);
//
//   return FMP4_OK;
// }
 
typedef fmp4_result (*get_fragment_post_callback_t)(
  void* context, struct buckets_t* buckets);

// Hook to override the default AES decoder. When an encrypted fragment is read
// then the fragment can be decrypted before further processing (and thus
// allowing to have e.g. Common Encrypted content stored on disk, but apply a
// different DRM system (e.g. HLS AES or HDS FLXS) to the final output.
//
// The type is:
// 0 = AES_CTR (AES 128-bit CTR) or
// 1 = AES_CBC (AES 128-bit CBC).
//
// The 128-bit key_id uniquely identifies the content key to be used.
//
// When the requested aes_decoder cannot be created (e.g. you don't have the
// associated content_key, or the requested AES type is not supported by your
// hook) you must return NULL.

typedef struct fmp4_aes_decoder* (*create_aes_decoder_t)(void* context, uint32_t type, uint8_t const key_id[16]);

// The I/O handler used. By default this is set to a handler that provides the
// built-in file (memory mapped) and http (through libcurl) functions.
//
// If you want to use your own I/O functions, you can override the
// create_handler_io_. In your function you can check the given url and if you
// do not want to handle it, just pass it on the previous handler. This allows
// you to override specifically for specific urls (e.g. only http).
//
// Reference:
// mp4_handler_io.hpp: The abstract base class for I/O.
// mp4_handler_io_file.cpp: Implementation for reading/writing files from disk.
// mp4_handler_io_http.cpp: Implementation for reading urls from http.

typedef struct fmp4_handler_io_t* (*create_handler_io_t)(char const* url, int flags);

// Requests the server variable 'name'. The pointer to the value must be
// returned in *value.  Returns the size of the string.
// E.g. "REQUEST_SCHEME", "HTTP_HOST", "REQUEST_URI"
 
typedef int (*get_server_variable_callback_t)(void* context, char const* name, char const** value);

// Callback for error logging.
// level is one of FMP4_LOG_DEBUG, FMP4_LOG_WARNING, FMP4_LOG_ERROR.

typedef enum
{
  FMP4_LOG_DEBUG,
  FMP4_LOG_WARNING,
  FMP4_LOG_ERROR
} fmp4_log_level_t;

typedef void (*log_error_callback_t)(void* context, fmp4_log_level_t level, char const* str);

struct pool_t;

struct mp4_process_context_t
{
  // program wide settings
  struct mp4_global_context_t* global_context;

  // The path/url to the source file.
  char const* filename_;

  // The filesize of the source file, or UINT64_MAX when unknown.
  uint64_t filesize_;

  // Verbosity level (0=none)
  uint32_t verbose_;

  // The output buckets
  struct buckets_t* buckets_;

  // Options passed in the query parameters.
  struct mp4_split_options_t* options_;

  fmp4_result result_;

  // In case of an error, holds additional information.
  char result_text_[256];

  // The command-line tool is less strict in its permissions.
  // 1. Allows for progressive download even when it isn't specifically enabled
  //    in the server manifest.
  // 2. Allow all POST actions. I.e. if this flag is set all actions are allowed
  //    for which normally the is_post_ flag has to be set.
  uint32_t no_restrictions_;

  // callbacks

  // Returns a pointer to the fragment with timestamp 'dts' in MP4 format.
  get_fragment_callback_t get_fragment_callback_;
  void* get_fragment_context_;

  // Preprocess the fragment before the samples are read (e.g. decrypting)
  get_fragment_post_callback_t get_fragment_post_callback_;
  void* get_fragment_post_context_;

  // Hook to decrypt an MP4 fragment after it has been read
  create_aes_decoder_t create_aes_decoder_;
  void* create_aes_decoder_context_;

  //
  create_handler_io_t create_handler_io_;

  //
  get_server_variable_callback_t get_server_variable_callback_;
  void* get_server_variable_context_;

  //
  log_error_callback_t log_error_callback_;
  void* log_error_context_;

  struct pool_t* pool_;

  // The base path of the output (only used when packaging F4F files directly
  // with mp4split, so it outputs the F4X files to the same directory).
  char const* out_base_path_;

  // Prefer static files over dynamically generated files (e.g. for client
  // manifest files).
  uint32_t prefer_static_;

  // Pass through MP4 fragments directly to Smooth Streaming.
  uint32_t iss_pass_through_;

  // Set to true when called from the webserver module and the HTTP method
  // equals POST.
  uint32_t is_post_;
};
typedef struct mp4_process_context_t mp4_process_context_t;

// The mp4_process function is the main entry point for the libfmp4 library.
//
// An example for retrieving the client manifest file would be as follows:
//
// char const* filename = "/var/www/videos/video.ism";
// char const* args = "file=Manifest";
//
// Create and initialize the context structure.
// mp4_process_context_t context;
// mp4_process_context_init(&context);
//
// Set the filename/url to process
// context.filename_ = filename;
//
// Parse the options
// mp4_split_options_set(context.options_, args, strlen(args));
//
// Call the library
// int http_status = mp4_process(&context);
//
// Check for an error
// if(http_status != 200)
// {
//   throw std::runtime_error(context.result_text_);
// }
//
// The output is stored in the buckets.
//
// bucket_t* bucket = buckets->bucket_;
// if(bucket)
// {
//   ... read memory/file buckets ...
// }
//
// Cleanup.
// mp4_process_context_exit(&context);
//

MP4_DLL_EXPORT extern void
mp4_process_context_init(mp4_process_context_t* context,
                         mp4_global_context_t* global_context);

MP4_DLL_EXPORT extern void
mp4_process_context_exit(mp4_process_context_t* context);

MP4_DLL_EXPORT extern int mp4_process(mp4_process_context_t* context);

MP4_DLL_EXPORT extern void
mp4_process_context_reset(mp4_process_context_t* context);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MP4_PROCESS_H_AKW

// End Of File


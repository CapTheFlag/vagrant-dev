/*******************************************************************************
 mp4_uri.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_URI_HPP_AKW
#define MP4_URI_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <iosfwd>
#include <string>
#include <vector>

namespace fmp4 {

typedef std::pair<std::string, std::string> nvp_t;
typedef std::vector<nvp_t> nvps_t;

MP4_DLL_LOCAL extern
fmp4_result nvps_from_query(char const* first, char const* last, char separator,
                            nvps_t& nvps);

struct MP4_DLL_EXPORT url_t
{
  friend url_t create_url_from_url(std::string const& url);
  friend url_t create_url_from_path(std::string const& path);

public:
  url_t();
  explicit url_t(std::string const& url);

  std::string join() const;

  bool is_path_absolute() const;
  bool is_http() const;
  bool is_https() const;
  bool is_file() const;

  std::string join_args() const;
//  bool is_relative_path() const;
//  bool is_file_path() const;
  bool empty() const;

  bool resolve(url_t const& base_url);

  nvps_t::const_iterator find(std::string const& name) const;
  std::string find_and_erase(std::string const& name);
  void erase(std::string const& name);

  bool scheme_defined_;
  std::string scheme_;
  bool hostname_defined_;
  std::string hostname_;
  std::string path_;
  std::string query_;
  std::string fragment_;
  nvps_t args_;

private:
  fmp4_result parse(std::string const& url);
};

MP4_DLL_LOCAL extern bool operator==(url_t const& lhs, url_t const& rhs);

MP4_DLL_EXPORT extern bool operator!=(url_t const& lhs, url_t const& rhs);

MP4_DLL_LOCAL extern bool operator<(url_t const& lhs, url_t const& rhs);

MP4_DLL_EXPORT extern
std::ostream& operator<<(std::ostream& os, url_t const& url);

MP4_DLL_EXPORT extern url_t create_url_from_path(std::string const& path);

MP4_DLL_EXPORT extern std::string create_path_from_url(url_t const& url);

MP4_DLL_EXPORT extern url_t create_url(std::string const& url_or_path);

MP4_DLL_LOCAL extern void append_args_to_url(url_t& url, std::string const& args);

MP4_DLL_LOCAL extern std::string remove_dot_segments(std::string const& path);

MP4_DLL_LOCAL extern fmp4_result remove(url_t const& url);
MP4_DLL_LOCAL extern fmp4_result rename(url_t const& src, url_t const& dst);
MP4_DLL_LOCAL extern fmp4_result exists(url_t const& url);
MP4_DLL_LOCAL extern fmp4_result mkdir(url_t const& url);

template<unsigned long long N>
struct bin
{
  enum { value = (N % 8) + 2 * bin<N / 8>::value };
};
template<>
struct bin<0>
{
  enum { value = 0 };
};
#define binary(n) bin<0##n>::value

// per IETF RFC3986:
//
// reserved = gen-delims / sub-delims
// gen-delims = ":" / "/" / "?" / "#" / "[" / "]" / "@"
// sub-delims = "!" / "$" / "&" / "'" / "(" / ")" / "*" / "+" / "," / ";" / "="
//
// unreserved = ALPHA / DIGIT / "-" / "." / "_" / "~"
//
// pchar = unreserved / pct-encoded / sub-delims / ":" / "@"
// query = pchar / "/" / "?"
//       = ALPHA DIGIT / "-" / "." / "_" / "~"
//       / "!" / "$" / "&" / "'" / "(" / ")" / "*" / "+" / "," / ";" / "="
//       / ":" / "@"
//       / "/" / "?"
static uint8_t const uri_path[] = 
{
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),

  //      !"#$%&'          ()*+,-./          01234567          89:;<=>?
  binary(11111111), binary(00000001), binary(00000000), binary(00001011),

  //     @ABCDEFG          HIJKLMNO          PQRSTUVW          XYZ[/]^_
  binary(00000000), binary(00000000), binary(00000000), binary(00011110),

  //     `abcdefg          hijklmno          pqrstuvw          xyz{|}~
  binary(10000000), binary(00000000), binary(00000000), binary(00011101),

  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
};

static uint8_t const uri_args[] = 
{
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),

  //      !"#$%&'          ()*+,-./          01234567          89:;<=>?
  binary(10010110), binary(00010000), binary(00000000), binary(00010001),

  //     @ABCDEFG          HIJKLMNO          PQRSTUVW          XYZ[/]^_
  binary(00000000), binary(00000000), binary(00000000), binary(00000000),

  //     `abcdefg          hijklmno          pqrstuvw          xyz{|}~
  binary(00000000), binary(00000000), binary(00000000), binary(00000001),

  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
  binary(11111111), binary(11111111), binary(11111111), binary(11111111),
};

static uint8_t const bitmask[8] =
{
  0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01
};

template<typename InputIterator>
std::size_t uri_escape_size(InputIterator first, InputIterator last,
                            uint8_t const* escape_table)
{
  std::size_t size = 0;
  for(; first != last; ++first)
  {
    uint8_t c = static_cast<unsigned char>(*first);
    size += (escape_table[c >> 3] & bitmask[c & 7]) ? 3 : 1;
  }

  return size;
}

template<typename InputIterator, typename OutputIterator>
OutputIterator uri_escape(InputIterator first, InputIterator last,
                          OutputIterator dst,
                          uint8_t const* escape_table)
{
  static const char* hex_upper = "0123456789ABCDEF";

  for(; first != last; ++first)
  {
    uint8_t c = static_cast<unsigned char>(*first);
    if(escape_table[c >> 3] & bitmask[c & 7])
    {
      *dst++ = '%';
      *dst++ = hex_upper[(c >> 4) & 15];
      *dst++ = hex_upper[(c >> 0) & 15];
    }
    else
    {
      *dst++ = *first;
    }
  }

  return dst;
}

MP4_DLL_EXPORT extern fmp4_result uri_unescape(std::string& str, bool is_query);

} // namespace fmp4

#endif // MP4_URI_HPP_AKW

// End Of File


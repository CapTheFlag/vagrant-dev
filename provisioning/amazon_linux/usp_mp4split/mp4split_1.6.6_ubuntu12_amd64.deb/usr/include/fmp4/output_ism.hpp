/*******************************************************************************
 output_ism.hpp - A library for writing Smooth Streaming Server Manifests.

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef OUTPUT_ISM_HPP_AKW
#define OUTPUT_ISM_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"

struct mp4_process_context_t;

//  // Setup libfmp4 process context
//  mp4_process_context_t context;
//  mp4_process_context_init(&context);
//
//  // Install custom IO handler
//  context.create_handler_io_ = mp4split_io_handler;
//
//  // The output server manifest
//  fmp4::ism_t ism("no_file.ism");
//
//  // No predicate, just add all the available tracks from the video file.
//  smil_switch_t predicate;
//  ism_insert_track_t insert_track;
//
//  // Add the streams from the file (video.ismv) to the server manifest file
//  ism_add_file(context, ism, insert_track, "video.ismv", predicate);
//
//  // Clean up the libfmp4 process context
//  mp4_process_context_exit(&context);

namespace fmp4
{

struct mp4_context_t;
struct moov_t;
struct trak_t;
struct ism_t;
struct smil_switch_t;
struct url_t;
struct ism_insert_track_t;

enum
{
  ism_add_calculate_bitrate = 0x0001,
  ism_add_closed_captions   = 0x0002
};

// Add the streams (matching the predicate) from the file to the server
// manifest file.
//
// When the flag ism_add_calculate_bitrate is set and the bitrate info
// is not available (through the esds or btrt box) then the bitrates are
// calculated using the actual samples. In the case of a fragmented-mp4 video
// this triggers a full file scan, since all the MOOF boxes have to be read.
//
// You can disable the possibility of a full file scan by not passing in the
// ism_add_calculate_bitrate flag. When the bitrate of a stream is not available
// it will be set to 0.
//
// When the flag ism_add_closed_captions is set then AVC video tracks are
// scanned for the presence of embedded Closed Captions.

MP4_DLL_EXPORT extern
fmp4_result ism_add_file(mp4_process_context_t& context,
                         ism_t& ism, ism_insert_track_t const& insert_track,
                         url_t const& url,
                         smil_switch_t const& predicate,
                         int ism_add_flags = ism_add_calculate_bitrate
                                           | ism_add_closed_captions);

MP4_DLL_EXPORT extern
void output_ism(mp4_process_context_t& context, ism_t const& ism);

MP4_DLL_EXPORT extern
fmp4_result update_smil_switch(smil_switch_t& smil_switch, trak_t const& trak);

MP4_DLL_EXPORT extern
fmp4_result update_smil_switch(smil_switch_t& smil_switch, moov_t const& moov);

} // namespace fmp4

#endif // OUTPUT_ISM_HPP_AKW

// End Of File


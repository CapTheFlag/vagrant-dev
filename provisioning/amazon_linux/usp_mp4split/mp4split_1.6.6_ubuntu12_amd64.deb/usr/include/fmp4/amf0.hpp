/*******************************************************************************
 amf0.hpp -

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef AMF0_HPP_AKW
#define AMF0_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <vector>
#include <map>
#include <memory>
#include <iosfwd>

namespace fmp4
{

enum amf0_marker_t
{
  amf0_number_marker       = 0x00,
  amf0_boolean_marker      = 0x01,
  amf0_string_marker       = 0x02,
  amf0_object_marker       = 0x03,
  amf0_movieclip_marker    = 0x04,
  amf0_null_marker         = 0x05,
  amf0_undefined_marker    = 0x06,
  amf0_reference_marker    = 0x07,
  amf0_ecma_array_marker   = 0x08,
  amf0_object_end_marker   = 0x09,
  amf0_strict_array_marker = 0x0a,
  amf0_date_marker         = 0x0b,
  amf0_long_string_marker  = 0x0c,
  amf0_unsupported_marker  = 0x0d,
  amf0_recordset_marker    = 0x0e,
  amf0_xml_document_marker = 0x0f,
  amf0_typed_object_marker = 0x10
};

struct MP4_DLL_LOCAL amf0_t
{
private:
  amf0_t(amf0_t const& rhs);
  amf0_t& operator=(amf0_t const& rhs);

public:
  amf0_t(amf0_marker_t const& type)
  : type_(type)
  {
  }

  virtual ~amf0_t()
  {
  }

  amf0_marker_t const& get_type() const
  {
    return type_;
  }

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last) = 0;
  virtual void print(std::ostream& os) const = 0;

private:
  amf0_marker_t type_;
};

MP4_DLL_LOCAL extern
std::ostream& operator<<(std::ostream& os, amf0_t const& amf);

struct MP4_DLL_LOCAL amf0_number_t : amf0_t
{
  amf0_number_t(double val = 0.);

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  double val_;
};

struct MP4_DLL_LOCAL amf0_boolean_t : amf0_t
{
  amf0_boolean_t(bool val = false);

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  bool val_;
};

struct MP4_DLL_LOCAL amf0_string_t : amf0_t
{
  amf0_string_t(std::string const& val = "");

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  std::string val_;
};

struct MP4_DLL_LOCAL amf0_object_t : amf0_t
{
  typedef std::pair<std::string, amf0_t*> array_pair_t;
  typedef std::vector<array_pair_t> array_t;

  amf0_object_t();
  virtual ~amf0_object_t();

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  array_t::const_iterator begin() const
  {
    return val_.begin();
  }

  array_t::const_iterator end() const
  {
    return val_.end();
  }

  array_t val_;
};

struct MP4_DLL_LOCAL amf0_reference_t : amf0_t
{
  amf0_reference_t(uint16_t val = 0);

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  uint16_t val_;
};

struct MP4_DLL_LOCAL amf0_ecma_array_t : amf0_t
{
  typedef std::pair<std::string, amf0_t*> array_pair_t;
  typedef std::vector<array_pair_t> array_t;

  amf0_ecma_array_t();
  virtual ~amf0_ecma_array_t();

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  array_t::const_iterator begin() const
  {
    return val_.begin();
  }

  array_t::const_iterator end() const
  {
    return val_.end();
  }

  array_t val_;
};

struct MP4_DLL_LOCAL amf0_strict_array_t : amf0_t
{
  typedef std::vector<amf0_t*> array_t;

  amf0_strict_array_t();
  virtual ~amf0_strict_array_t();

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  array_t::const_iterator begin() const
  {
    return val_.begin();
  }

  array_t::const_iterator end() const
  {
    return val_.end();
  }

  array_t val_;
};

struct MP4_DLL_LOCAL amf0_date_t : amf0_t
{
  amf0_date_t(double time = 0, uint16_t tz = 0);

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  std::pair<double, uint16_t> val_;
};

struct MP4_DLL_LOCAL amf0_long_string_t : amf0_t
{
  amf0_long_string_t(std::string const& val = "");

  virtual fmp4_result read(uint8_t const*& first, uint8_t const* last);
  virtual void print(std::ostream& os) const;

  std::string val_;
};

MP4_DLL_LOCAL extern
fmp4_result get_as_string(amf0_t const& amf0, std::string& val);

MP4_DLL_LOCAL extern
fmp4_result amf0_read(uint8_t const*& first, uint8_t const* last,
                      std::auto_ptr<amf0_t>& amf0);

////////////////////////////////////////////////////////////////////////////////

struct MP4_DLL_EXPORT amf0_onmetadata
{
  amf0_onmetadata();

  struct trackinfo_t
  {
    trackinfo_t();
    unsigned int timescale_;
    std::string language_;
  };

  std::string metadatacreator_;
  bool hasAudio_;
  bool hasVideo_;
  double duration_;
  bool canSeekToEnd_;

  std::string audiocodecid_;
  unsigned int aacaot_;
  unsigned int audiosamplerate_;
  unsigned int audiochannels_;
  unsigned int audiosamplesize_;
  unsigned int audiodatarate_;

  std::string videocodecid_;
  unsigned int avcprofile_;
  unsigned int avclevel_;
  unsigned int width_;
  unsigned int height_;
  unsigned int videodatarate_;
  double framerate_;

  typedef std::vector<trackinfo_t> trackinfos_t;
  trackinfos_t trackinfos_;
};

MP4_DLL_EXPORT extern
fmp4_result amf0_onmetadata_read(uint8_t const* first, uint8_t const* last,
                                 amf0_onmetadata& metadata);

struct MP4_DLL_EXPORT amf0_onfi
{
  std::string timecode_;    // hh:mm:ss:ff
  std::string system_date_; // dd-mm-yyyy
  std::string system_time_; // hh:mm:ss.ms
};

MP4_DLL_EXPORT extern
fmp4_result amf0_onfi_read(uint8_t const* first, uint8_t const* last,
                           amf0_onfi& onfi);


} // namespace fmp4

#endif // AMF0_HPP_AKW

// End Of File


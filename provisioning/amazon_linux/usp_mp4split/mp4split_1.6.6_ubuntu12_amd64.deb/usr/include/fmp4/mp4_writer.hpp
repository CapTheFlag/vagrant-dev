/*******************************************************************************
 mp4_writer.hpp - A library for writing MPEG4.

 Copyright (C) 2007-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_WRITER_HPP_AKW
#define MP4_WRITER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <algorithm>
#include <vector>

namespace fmp4
{

class bucket_writer;
class memory_writer;
struct unknown_atom_t;
struct moov_t;
struct trak_t;
struct mfra_t;
struct sidx_t;
struct moof_t;
struct tfxd_t;

MP4_DLL_LOCAL inline
bool has_fourcc(std::vector<uint32_t> const& list, uint32_t fourcc)
{
  return std::find(list.begin(), list.end(), fourcc) != list.end();
}

struct MP4_DLL_EXPORT ftyp_t
{
  ftyp_t();

  void set_brand(uint32_t fourcc, uint32_t version);
  void add_brand(uint32_t fourcc);
  bool has_brand(uint32_t fourcc) const;

  uint32_t major_brand_;
  uint32_t minor_version_;
  typedef std::vector<uint32_t> compatible_brands_t;
  compatible_brands_t compatible_brands_;
};

MP4_DLL_EXPORT extern
fmp4_result ftyp_read(ftyp_t& ftyp, uint8_t const* first, uint32_t size);

struct MP4_DLL_EXPORT mp4_writer_t
{
private:
  mp4_writer_t(mp4_writer_t const& rhs);
  mp4_writer_t& operator=(mp4_writer_t rhs);

public:
  mp4_writer_t();

  void set_brand(uint32_t fourcc, uint32_t version);
  void add_brand(uint32_t fourcc);
  void add_brands(std::vector<uint32_t> const& fourcc);
  bool has_brand(uint32_t fourcc) const;

  ftyp_t ftyp_;
};

MP4_DLL_EXPORT extern
std::size_t ftyp_size(mp4_writer_t const& mp4_writer, bool add_padding = true);
MP4_DLL_EXPORT extern
void ftyp_write(mp4_writer_t const& mp4_writer, memory_writer& mem_writer, bool add_padding = true);
MP4_DLL_LOCAL extern
void styp_write(mp4_writer_t const& mp4_writer, memory_writer& mem_writer);

MP4_DLL_LOCAL extern
uint8_t* write_preamble(uint32_t type, memory_writer& mem_writer);

MP4_DLL_LOCAL extern
void trak_shift_offsets_inplace(trak_t* trak, int64_t offset);

MP4_DLL_EXPORT extern
void moov_write(mp4_writer_t& mp4_writer, moov_t const& moov, memory_writer& mem_writer);
MP4_DLL_EXPORT extern
std::size_t moov_size(mp4_writer_t& mp4_writer, moov_t const& moov);

MP4_DLL_EXPORT extern
void mfra_write(mp4_writer_t& mp4_writer, mfra_t const& mfra, memory_writer& mem_writer);

MP4_DLL_EXPORT extern
std::size_t mfra_size(mp4_writer_t& mp4_writer, mfra_t const& mfra);

MP4_DLL_LOCAL extern
void sidx_write(mp4_writer_t& mp4_writer,
                sidx_t const& sidx, memory_writer& mem_writer);

MP4_DLL_LOCAL extern
std::size_t sidx_size(mp4_writer_t& mp4_writer, sidx_t const& sidx);

MP4_DLL_EXPORT extern
std::size_t moof_write(mp4_writer_t& mp4_writer, moof_t const& moof, memory_writer& mem_writer);

MP4_DLL_EXPORT extern
std::size_t moof_size(mp4_writer_t& mp4_writer, moof_t const& moof);

MP4_DLL_EXPORT extern std::size_t tfxd_size();
MP4_DLL_EXPORT extern
std::size_t tfxd_write(mp4_writer_t& mp4_writer, tfxd_t const& tfxd, memory_writer& mem_writer);

} // namespace fmp4

#endif // MP4_WRITER_HPP_AKW

// End Of File


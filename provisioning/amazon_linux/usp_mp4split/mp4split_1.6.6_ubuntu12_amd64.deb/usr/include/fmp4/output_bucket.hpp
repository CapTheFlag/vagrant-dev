/*******************************************************************************
 output_bucket.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef OUTPUT_BUCKET_HPP_AKW
#define OUTPUT_BUCKET_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "output_bucket.h"
#include "mp4_util.hpp"
#include <inttypes.h>
#include <vector>
#include <iosfwd>
#include <cstdlib>

struct mp4_process_context_t;
struct buckets_t;
struct bucket_t;

namespace fmp4
{

MP4_DLL_EXPORT extern buckets_t* buckets_init();
MP4_DLL_EXPORT extern void buckets_exit(buckets_t* buckets);
MP4_DLL_EXPORT bool buckets_empty(buckets_t const* buckets);

MP4_DLL_LOCAL extern bucket_t* bucket_init();
MP4_DLL_LOCAL extern
void bucket_insert_after(bucket_t* bucket, bucket_t* after);
MP4_DLL_EXPORT extern
void bucket_insert_tail(buckets_t* buckets, bucket_t* bucket);
MP4_DLL_EXPORT extern void bucket_insert_tail(bucket_t* head, bucket_t* bucket);
MP4_DLL_LOCAL extern
void bucket_insert_head(buckets_t* buckets, bucket_t* bucket);

MP4_DLL_LOCAL extern
bucket_t* bucket_heap_make(bucket_t* bucket, uint8_t const* buf, std::size_t size);

MP4_DLL_EXPORT extern
bucket_t* bucket_heap_create(uint8_t const* buf, std::size_t size);

MP4_DLL_LOCAL extern
bucket_t* bucket_file_make(mp4_process_context_t& context,
                           bucket_t* bucket, char const* filename,
                           uint64_t offset, uint64_t size);

MP4_DLL_LOCAL extern
bucket_t* bucket_file_create(mp4_process_context_t& context,
                             char const* filename,
                             uint64_t offset, uint64_t size);

#if 0 && defined(_DEBUG)
MP4_DLL_EXPORT extern
std::ostream& operator<<(std::ostream& os, bucket_t const& bucket);
#endif

struct url_t;

class bucket_reader
{
public:
  bucket_reader(buckets_t const* buckets);

  // Returns a pointer to a buffer with a size that is a multiple of 16 bytes
  // (except for the last read).
  uint8_t* read(size_t& size);

  bool eof() const;

private:
  bool next_bucket();

private:
  buckets_t const* buckets_;
  bucket_t* bucket_;
  uint8_t const* bucket_buf_;
  size_t bucket_index_;
  uint8_t buf_[16];
  size_t buf_index_;
  size_t buf_size_;
};

class MP4_DLL_EXPORT bucket_writer
{
private:
  bucket_writer(bucket_writer const& rhs);
  bucket_writer& operator=(bucket_writer const& rhs);

public:
  bucket_writer(buckets_t* bucket, size_t minimum_size = 0);
  ~bucket_writer();

  // write memory buffer
  fmp4_result write(char const* first, std::size_t size);
  fmp4_result write(char const* first, char const* last);
  fmp4_result write(uint8_t const* first, uint8_t const* last);
//fmp4_result write_utf16le(char const* first, char const* last);
  fmp4_result write(std::vector<uint8_t> const& vec);
  fmp4_result write_base64(std::vector<uint8_t> const& vec);
  fmp4_result write(uint8_t val);

  // write file buffer, possible merging with the last bucket
  fmp4_result write(mp4_process_context_t& context,
                    char const* filename, uint64_t offset, uint32_t size);

  fmp4_result write(bucket_t* bucket);

  fmp4_result write(buckets_t& buckets, uint64_t offset, uint64_t size);

  // reserve place for a bucket, in case you don't know the size yet
  bucket_t* reserve_bucket();
  void flush_bucket(bucket_t* bucket);

  // returns pointer to buffer with guaranteed space for 'size' bytes
  fmp4_result reserve(size_t size, uint8_t*& buf);

  uint64_t tell() const
  {
    return pos_;
  }

  // append all the buckets, removing all the buckets from the source.
  fmp4_result append(buckets_t* buckets);

//  buckets_t* get_buckets();

private:
  MP4_DLL_LOCAL bool alloc_heap(std::size_t minimum_size = 1);
  MP4_DLL_LOCAL fmp4_result new_bucket(size_t minimum_size = 0);

// public:
//  // we need the context for bucket_file_t for file I/O.
//  mp4_process_context_t& context_;

private:
  // the output buckets
  bucket_t* head_;
  // the minimum size when creating a new bucket
  size_t minimum_size_;
  // the current byte position
  uint64_t pos_;
  // the last heap bucket reserved by the writer
  bucket_t* bucket_;
};

MP4_DLL_LOCAL inline
bucket_writer& operator<<(bucket_writer& writer, char const* str)
{
  writer.write(str, str + strlen(str));

  return writer;
}

MP4_DLL_LOCAL inline
bucket_writer& operator<<(bucket_writer& writer, std::string const& str)
{
  writer.write(str.data(), str.data() + str.size());

  return writer;
}

MP4_DLL_LOCAL inline
bucket_writer& operator<<(bucket_writer& writer, uint32_t val)
{
  char buf[UINT32_DIGITS];
  writer.write(itostr(val, buf), buf + sizeof(buf));

  return writer;
}

MP4_DLL_LOCAL inline
bucket_writer& operator<<(bucket_writer& writer, uint64_t val)
{
#if 1
  if(val <= UINT32_MAX)
  {
    writer << static_cast<uint32_t>(val);
  }
  else
#endif
  {
    char buf[UINT64_DIGITS];
    writer.write(itostr(val, buf), buf + sizeof(buf));
  }

  return writer;
}

////////////////////////////////////////////////////////////////////////////////

MP4_DLL_EXPORT extern
bucket_t* buckets_read(buckets_t const& buckets, uint64_t pos, uint32_t size);

MP4_DLL_EXPORT extern
fmp4_result buckets_read(buckets_t const& buckets, uint64_t pos,
                         uint8_t const*& src, std::size_t& size);

MP4_DLL_LOCAL extern
fmp4_result buckets_write(mp4_process_context_t& context,
                          buckets_t const* buckets, url_t const& url);

MP4_DLL_LOCAL extern
fmp4_result buckets_append(mp4_process_context_t& context,
                           buckets_t const* buckets, url_t const& url);

MP4_DLL_EXPORT extern
fmp4_result buckets_write_with_progress(mp4_process_context_t const& context,
                                        url_t const& out_url);

MP4_DLL_EXPORT extern
fmp4_result buckets_flatten(buckets_t const* buckets,
                            bucket_t const* end_bucket,
                            uint8_t* dst);

// Flatten the buckets into a single heap bucket.
MP4_DLL_EXPORT extern fmp4_result buckets_flatten(buckets_t* buckets,
                                                  uint8_t** dst);

MP4_DLL_EXPORT extern
fmp4_result buckets_merge(mp4_process_context_t& context, buckets_t& buckets);

} // namespace fmp4

#endif // OUTPUT_BUCKET_HPP_AKW

// End Of File


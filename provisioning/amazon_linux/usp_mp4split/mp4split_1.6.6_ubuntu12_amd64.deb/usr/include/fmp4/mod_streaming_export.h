/*******************************************************************************
 mod_streaming_export.h

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MOD_STREAMING_EXPORT_H_AKW
#define MOD_STREAMING_EXPORT_H_AKW

#if defined _WIN32 || defined __CYGWIN__
# define MOD_STREAMING_DLL_IMPORT __declspec(dllimport)
# define MOD_STREAMING_DLL_EXPORT __declspec(dllexport)
# define MOD_STREAMING_DLL_LOCAL
#else
# if __GNUC__ >= 4
#   define MOD_STREAMING_DLL_IMPORT __attribute__ ((visibility("default")))
#   define MOD_STREAMING_DLL_EXPORT __attribute__ ((visibility("default")))
#   define MOD_STREAMING_DLL_LOCAL  __attribute__ ((visibility("hidden")))
# else
#   define MOD_STREAMING_DLL_IMPORT
#   define MOD_STREAMING_DLL_EXPORT
#   define MOD_STREAMING_DLL_LOCAL
# endif
#endif

#if defined(BUILDING_MP4SPLIT)
#  if defined(MP4_STATIC)
#    define MP4_DLL_EXPORT
#  else
#    define MP4_DLL_EXPORT MOD_STREAMING_DLL_EXPORT
#  endif
#else
#  if defined(MP4_STATIC)
#    define MP4_DLL_EXPORT
#  else
#    define MP4_DLL_EXPORT MOD_STREAMING_DLL_IMPORT
#  endif
#endif

#define MP4_DLL_LOCAL MOD_STREAMING_DLL_LOCAL

#define MOD_H264_STREAMING_VERSION_MAJOR      2
#define MOD_H264_STREAMING_VERSION_MINOR      6
#define MOD_H264_STREAMING_VERSION_REVISION   6

#define X_MOD_H264_STREAMING_KEY         "X-Mod-H264-Streaming"
#define X_MOD_H264_STREAMING_VERSION     "version=2.6.6"

#define MOD_SMOOTH_STREAMING_VERSION_MAJOR      1
#define MOD_SMOOTH_STREAMING_VERSION_MINOR      6
#define MOD_SMOOTH_STREAMING_VERSION_REVISION   6

#define X_MOD_SMOOTH_STREAMING_KEY         "X-Mod-Smooth-Streaming"
#define X_MOD_SMOOTH_STREAMING_VERSION     "version=1.6.6"

#define MOD_SMOOTH_STREAMING_KEY_FILE  "usp-license.key"

#ifdef __cplusplus
#define __STDC_FORMAT_MACROS    // C++ should define this for PRIu64
#define __STDC_LIMIT_MACROS     // C++ should define this for UINT64_MAX
#define __STDC_CONSTANT_MACROS  // C++ should define this for INT64_C
#endif

#if defined(_MSC_VER)
# if !defined(NDEBUG)
#   define _CRTDBG_MAP_ALLOC
#   include <crtdbg.h>
// #   define new new ( _NORMAL_BLOCK, __FILE__, __LINE__ )
# endif
# define snprintf _snprintf
#endif

#ifdef __cplusplus
extern "C" {
#endif

MP4_DLL_EXPORT extern char const* fmp4_version_string();

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MOD_STREAMING_EXPORT_H_AKW

// End Of File


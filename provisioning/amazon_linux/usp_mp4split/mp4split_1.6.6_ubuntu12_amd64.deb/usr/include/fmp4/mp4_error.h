/*******************************************************************************
 mp4_error.h -

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_ERROR_H_AKW
#define MP4_ERROR_H_AKW

#include "mod_streaming_export.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FMP4_CHECK(a)             \
{                                 \
  fmp4_result result = (a);       \
  if(result != FMP4_OK)           \
  {                               \
    return result;                \
  }                               \
}

typedef enum
{
  FMP4_OK = 0,
  FMP4_100,
  FMP4_204,
  FMP4_400,
  FMP4_403,
  FMP4_404,
  FMP4_408,
  FMP4_409,
  FMP4_412,
  FMP4_415,
  FMP4_416,
  FMP4_500,
  FMP4_501,
  FMP4_503,
  FMP4_MISSING_FTYP,
  FMP4_MISSING_MOOV,
  FMP4_MISSING_MOOF,
  FMP4_MISSING_MFRO,
  FMP4_MISSING_TFRA,

  // the mp4 file is missing the 'sidx' box. This error may be returned when
  // creating an MPD from audio/video files and the file is missing the index.
  FMP4_MISSING_SIDX,

  FMP4_MISSING_NAL_SIZE,
  FMP4_INVALID_NAL_SIZE,
  FMP4_MISSING_NAL_DATA,
  FMP4_INVALID_NAL_TRAILING_ZEROES,
  FMP4_INVALID_NAL_EMULATION_PREVENTION,
  FMP4_INVALID_SEI,

  FMP4_CONTENT_KEY_MUST_BE_128_BITS,
  FMP4_ERROR_DECRYPTING_USING_AES_CBC,
  FMP4_ERROR_ENCRYPTING_USING_AES_CBC,
  FMP4_ERROR_DECRYPTING_USING_AES_CTR,
  FMP4_ERROR_ENCRYPTING_USING_AES_CTR,
  FMP4_ISS_FORBIDDEN,
  FMP4_HLS_FORBIDDEN,
  FMP4_HDS_FORBIDDEN,
  FMP4_MPD_FORBIDDEN,
//  FMP4_INVALID_PACKET_LENGTH,
  FMP4_IO_FILENAME_TOO_LONG,
  FMP4_IO_HTTP_ERROR,
  FMP4_IO_NO_SUCH_FILE_OR_DIRECTORY,
  FMP4_IO_NOT_A_DIRECTORY,
  FMP4_IO_PERMISSION_DENIED,
  FMP4_IO_BADF,
  FMP4_IO_SPIPE,
  FMP4_IO_READ_ERROR,
  FMP4_IO_WRITE_ERROR,
  FMP4_MISSING_AUDIO_CODEC_PRIVATE_DATA,
  FMP4_MISSING_DRM_OPTIONS_FOR_ISS,
  FMP4_MISSING_DRM_OPTIONS_FOR_HLS,
  FMP4_MISSING_DRM_OPTIONS_FOR_HDS,
  FMP4_MISSING_DRM_OPTIONS_FOR_MPD,
  FMP4_NO_SYNC_SAMPLES,
  FMP4_OUT_OF_MEMORY,
  FMP4_PARSE_ERROR,
  FMP4_STD_EXCEPTION,
  FMP4_UNSUPPORTED_REQUEST_FOR_FILE,

  // An invalid fragment index (0) was specified. The index of a fragment
  // for HLS and HDS always start at 1.
  FMP4_INVALID_MEDIA_SEQUENCE,

  // The requested fragment number is less than the first fragment available
  // in the DVR window.
  FMP4_FRAGMENT_NOT_FOUND,

  // The requested fragment number is missing from the DVR window.
  FMP4_FRAGMENT_MISSING,

  // The requested fragment number is larger than the last fragment available
  // in the DVR window.
  FMP4_FRAGMENT_NOT_AVAILABLE,

  // Smooth Streaming
  FMP4_ISS_FRAGMENT_NOT_FOUND,
  FMP4_ISS_FRAGMENT_MISSING,
  FMP4_ISS_FRAGMENT_NOT_AVAILABLE,

  // HTTP Live Streaming
  FMP4_HLS_FRAGMENT_NOT_FOUND,
  FMP4_HLS_FRAGMENT_MISSING,
  FMP4_HLS_FRAGMENT_NOT_AVAILABLE,

  // HTTP Dynamic Streaming
  FMP4_HDS_FRAGMENT_NOT_FOUND,
  FMP4_HDS_FRAGMENT_MISSING,
  FMP4_HDS_FRAGMENT_NOT_AVAILABLE,

  // DASH
  FMP4_MPD_FRAGMENT_NOT_FOUND,
  FMP4_MPD_FRAGMENT_MISSING,
  FMP4_MPD_FRAGMENT_NOT_AVAILABLE,

  // No suitable AES decoder is found for decrypting a fragment.
  FMP4_AES_DECODER_NOT_FOUND,

  // A fragment is encrypted with an unsupported AES mode. E.g. only
  // AES 128-bit CTR is supported for Common Encryption and PIFF.
  FMP4_AES_UNSUPPORTED_MODE,

  // The time range specified by [vbegin,vend> is invalid
  FMP4_INVALID_TIME,

  // The function called is a 'no operation'.
  FMP4_NOP,

  // No tracks are listed in the server manifest (e.g when a given predicate
  // doesn't match any input tracks).
  FMP4_NO_INPUT_TRACKS,

  FMP4_SRT_INVALID_TIMESPEC,
  FMP4_SRT_MISSING_TIMESEPARATOR,

  FMP4_MFX_ERROR

} fmp4_result;

// Convert the result code to a string
MP4_DLL_EXPORT char const* fmp4_result_to_string(fmp4_result rc);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MP4_ERROR_H_AKW

// End Of File


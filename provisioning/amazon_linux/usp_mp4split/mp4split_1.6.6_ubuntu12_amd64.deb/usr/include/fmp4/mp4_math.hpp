/*******************************************************************************
 mp4_math.hpp -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_MATH_HPP_AKW
#define MP4_MATH_HPP_AKW

#include "mod_streaming_export.h"
#include <inttypes.h>

namespace fmp4
{

class fraction_t
{
public:
  fraction_t(uint64_t x, uint32_t y)
  : x_(x)
  , y_(y)
  {
  }

#if 0
  operator bool() const
  {
    return x_ != 0;
  }
#endif

public:
  uint64_t x_;
  uint32_t y_;
};

MP4_DLL_LOCAL
bool operator<(fraction_t const& lhs, fraction_t const& rhs);

MP4_DLL_LOCAL
bool operator>(fraction_t const& lhs, fraction_t const& rhs);

MP4_DLL_LOCAL
bool operator==(fraction_t const& lhs, fraction_t const& rhs);

MP4_DLL_LOCAL
bool operator>=(fraction_t const& lhs, fraction_t const& rhs);

} // namespace fmp4

#endif // MP4_MATH_HPP_AKW

// End Of File


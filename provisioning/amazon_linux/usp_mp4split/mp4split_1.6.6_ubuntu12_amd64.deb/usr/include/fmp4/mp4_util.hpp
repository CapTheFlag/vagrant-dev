/*******************************************************************************
 mp4_util.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_UTIL_HPP_AKW
#define MP4_UTIL_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_uri.hpp"
#include "mp4_types.hpp"
#include <inttypes.h>
#include <algorithm>
#include <iosfwd>
#include <string>
#include <cstring>
#include <vector>
#include <stdexcept>

#define CONST_STR_LEN(a) a, sizeof(a) - 1

namespace fmp4 {

MP4_DLL_EXPORT extern
fmp4_result hex16_decode(char const* first, char const* last, uint8_t& val);

MP4_DLL_EXPORT extern
fmp4_result hex16_decode(char const* first, char const* last, uint32_t& val);

MP4_DLL_EXPORT extern
fmp4_result hex16_decode(char const* first, char const* last, uint64_t& val);

template<typename OutputIterator>
fmp4_result hex16_decode(char const* first, char const* last,
                         OutputIterator output)
{
  for(; first + 2 <= last; first += 2)
  {
    uint8_t val;
    FMP4_CHECK(hex16_decode(first, first + 2, val));
    *output++ = val;
  }

  if(first != last)
  {
    return fmp4_throw(FMP4_415, "Trailing hex16 character");
  }

  return FMP4_OK;
}

template<typename OutputIterator>
OutputIterator hex16(uint8_t c, OutputIterator output, bool lower_case = false)
{
  static const char* hex_upper = "0123456789ABCDEF";
  static const char* hex_lower = "0123456789abcdef";

  *output++ = (lower_case ? hex_lower : hex_upper)[(c >> 4) & 15];
  *output++ = (lower_case ? hex_lower : hex_upper)[(c >> 0) & 15];

  return output;
}

template<typename OutputIterator>
OutputIterator hex16(uint16_t c, OutputIterator output, bool lower_case = false)
{
  output = hex16(static_cast<uint8_t>(c >> 8), output, lower_case);
  output = hex16(static_cast<uint8_t>(c >> 0), output, lower_case);

  return output;
}

template<typename OutputIterator>
OutputIterator hex16(uint32_t c, OutputIterator output, bool lower_case = false)
{
  output = hex16(static_cast<uint16_t>(c >> 16), output, lower_case);
  output = hex16(static_cast<uint16_t>(c >>  0), output, lower_case);

  return output;
}

template<typename InputIterator, typename OutputIterator>
OutputIterator hex16(InputIterator first, InputIterator last,
                     OutputIterator output, bool lower_case = false)
{
  for(; first != last; ++first)
  {
    output = hex16(static_cast<uint8_t>(*first), output, lower_case);
  }

  return output;
}

template<unsigned int N>
struct base64_size
{
  enum { value = (N + 2) / 3 * 4 };
};

inline std::size_t base64_encode_size(std::size_t n)
{
  return (n + 2) / 3 * 4;
}

inline std::size_t base64_encode_size(uint8_t const* first, uint8_t const* last)
{
  return base64_encode_size(std::distance(first, last));
}

MP4_DLL_EXPORT extern
void base64_encode(uint8_t const* first, uint8_t const* last, char* output);

MP4_DLL_EXPORT extern fmp4_result base64_decode(uint8_t c, uint8_t& out);

template<typename OutputIterator>
fmp4_result base64_decode(char const* first, char const* last,
                          OutputIterator output)
{
  while(first != last)
  {
    if(*first == '\n' || *first == '\t' || *first == ' ')
    {
      ++first;
      continue;
    }

    uint8_t b0;
    FMP4_CHECK(base64_decode(*first++, b0));
    if(first == last)
    {
      return fmp4_throw(FMP4_415, "base64_decode: unexpected end of file?");
    }
    uint8_t b1;
    FMP4_CHECK(base64_decode(*first++, b1));
    *output++ = (b0 << 2) + ((b1 >> 4) & 3);
    if(first != last)
    {
      if(*first == '=')
      {
        break;
      }
      uint8_t b2;
      FMP4_CHECK(base64_decode(*first++, b2));

      *output++ = ((b1 << 4) & 0xf0) + ((b2 >> 2) & 15);
      if(first != last)
      {
        if(*first == '=')
        {
          break;
        }
        uint8_t b3;
        FMP4_CHECK(base64_decode(*first++, b3));
        *output++ = ((b2 & 3) << 6) + b3;
      }
    }

//    if(first != last && *first == '\n')
//      ++first;
  }

  return FMP4_OK;
}

enum extension_t
{
  EXT_UNSUPPORTED,
  EXT_264,
  EXT_AAC,
  EXT_AC3,
  EXT_BOOTSTRAP,
  EXT_CSM,
  EXT_DASH,
  EXT_DFXP,
  EXT_DRMFAXS,
  EXT_DRMMETA,
  EXT_F4F,
  EXT_F4M,
  EXT_F4X,
  EXT_FLV,
  EXT_ISM,
  EXT_ISMA,
  EXT_ISMC,
  EXT_ISML,
  EXT_ISMV,
  EXT_ISMT,
  EXT_JPEG,       // jpg, jpe, jpeg, jfif
  EXT_M3U8,
  EXT_M4S,
  EXT_MOV,
  EXT_MP4,
  EXT_MPD,
  EXT_PNG,
  EXT_SMIL,
  EXT_TS,
  EXT_WEBVTT,     // webvtt, vtt
  EXT_XML,
  EXT_SRT
};

MP4_DLL_EXPORT extern
extension_t get_extension(char const* first, std::size_t& size);

MP4_DLL_LOCAL extern
char const* get_extension(char const* first, char const* last);

MP4_DLL_EXPORT extern
std::string mp4_change_extension(std::string const& filename,
                                 std::string const& new_extension);

MP4_DLL_EXPORT extern std::string mp4_path_leaf(std::string const& path);

MP4_DLL_EXPORT extern
std::string mp4_path_basename(std::string const& path);

MP4_DLL_LOCAL extern
std::vector<std::string> split_path(std::string::const_iterator first,
                                    std::string::const_iterator last);

MP4_DLL_LOCAL extern
fmp4_result create_relative_path(url_t& path, url_t const& base,
                                 bool allow_upwards);

MP4_DLL_LOCAL extern
uint8_t const* find_startcode(uint8_t const* first, uint8_t const* last);

MP4_DLL_LOCAL extern
uint8_t const* find_endcode(uint8_t const* first, uint8_t const* last);

#if 0
MP4_DLL_LOCAL extern
std::vector<std::string> parse_nals(std::vector<uint8_t> const& str);
#endif

MP4_DLL_EXPORT extern uint64_t microseconds_since_1970();
MP4_DLL_EXPORT extern int64_t seconds_since_1904();

MP4_DLL_LOCAL extern
char const* skip_leading_whitespace(char const* first, char const* last);

MP4_DLL_LOCAL extern
char const* skip_trailing_whitespace(char const* first, char const* last);

MP4_DLL_LOCAL extern
uint64_t read_fraction(char const*& first, char const* last);

MP4_DLL_EXPORT extern
fmp4_result read_time(char const*& first, char const* last,
                      uint64_t& microseconds);

MP4_DLL_EXPORT extern std::string to_ntp_sec(uint64_t microseconds);

MP4_DLL_EXPORT extern std::string print_duration(uint64_t microseconds);

MP4_DLL_EXPORT extern std::string to_iso8601(uint64_t microseconds_since_1970);

MP4_DLL_LOCAL extern
fmp4_result from_iso8601(char const* first, char const* last,
                         uint64_t& microseconds_since_1970);

MP4_DLL_EXPORT extern
void mp4_from_microseconds(uint64_t duration, uint32_t& hours,
                           uint32_t& minutes, uint32_t& seconds,
                           uint32_t& milliseconds, uint32_t& microseconds);

MP4_DLL_LOCAL extern nvps_t::const_iterator find(nvps_t const& nvps, std::string const& name);

MP4_DLL_LOCAL extern fmp4_result uuid_create(uint128_t& uuid);

MP4_DLL_LOCAL
std::vector<std::string> mp4_split_string(char const* first, char const* last, char c);

MP4_DLL_LOCAL void mp4_fraction_reduce(uint64_t& num, uint64_t& den);

MP4_DLL_EXPORT std::string mp4_fourcc_to_string(uint32_t fourcc);

MP4_DLL_EXPORT std::string print_bytes_friendly(uint64_t bytes);

static const unsigned int UINT32_DIGITS = 10;
static const unsigned int UINT64_DIGITS = 20;

MP4_DLL_LOCAL char* itostr(uint32_t val, char buf[UINT32_DIGITS]);
MP4_DLL_LOCAL char* itostr(uint64_t val, char buf[UINT64_DIGITS]);
MP4_DLL_EXPORT std::string itostr(uint32_t val);
MP4_DLL_EXPORT std::string itostr(uint64_t val);

#if 0 && defined(__APPLE__)
// TODO: Shouldn't be necessary, try using uint32_t or uint64_t.
MP4_DLL_EXPORT std::string itostr(size_t val);
#endif

inline bool equals(char const* input, char const* test, std::size_t size)
{
  return std::equal(test, test + size, input);
}

inline bool starts_with(char const* input, std::size_t input_size,
                        char const* test, std::size_t test_size)
{
  return input_size >= test_size && equals(input, test, test_size);
}

inline bool starts_with(std::string const& input,
                        char const* test, std::size_t test_size)
{
  return starts_with(input.data(), input.size(), test, test_size);
}

MP4_DLL_LOCAL bool istarts_with(char const* input, std::size_t input_size,
                                char const* test, std::size_t test_size);

inline bool istarts_with(std::string const& input,
                         char const* test, std::size_t test_size)
{
  return istarts_with(input.data(), input.size(), test, test_size);
}

inline bool ends_with(char const* input, std::size_t input_size,
                      char const* test, std::size_t test_size)
{
  return input_size >= test_size
    && equals(input + input_size - test_size, test, test_size);
}

inline bool ends_with(std::string const& input,
                      char const* test, std::size_t test_size)
{
  return ends_with(input.data(), input.size(), test, test_size);
}

MP4_DLL_EXPORT bool iends_with(char const* input, std::size_t input_size,
                               char const* test, std::size_t test_size);

inline bool iends_with(std::string const& input,
                       char const* test, std::size_t test_size)
{
  return iends_with(input.data(), input.size(), test, test_size);
}

inline bool equals(char const* input, std::size_t input_size,
                   char const* test, std::size_t test_size)
{
  return input_size == test_size && equals(input, test, input_size);
}

inline bool equals(std::string const& input,
                   char const* test, std::size_t test_size)
{
  return equals(input.data(), input.size(), test, test_size);
}

inline bool iequals(char const* input, std::size_t input_size,
                    char const* test, std::size_t test_size)
{
  return input_size == test_size
    && istarts_with(input, input_size, test, test_size);
}

MP4_DLL_LOCAL unsigned int mp4_bits_set(uint8_t val);
MP4_DLL_LOCAL unsigned int mp4_bits_set(uint32_t val);
MP4_DLL_LOCAL uint32_t mp4_bits_reverse(uint32_t val);

class MP4_DLL_EXPORT progress_bar
{
public:
  progress_bar(uint32_t verbose, uint64_t total);

  void bytes(uint64_t bytes);
  void update(uint64_t pos);
  void final();

private:
  uint32_t verbose_;
  uint64_t total_;
  uint64_t now_;
  unsigned int last_percentage_shown_;
  uint64_t bytes_;
};

} // namespace fmp4

#endif // MP4_UTIL_HPP_AKW

// End Of File


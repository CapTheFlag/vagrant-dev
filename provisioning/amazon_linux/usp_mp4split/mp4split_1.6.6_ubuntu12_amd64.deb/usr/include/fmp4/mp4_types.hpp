/*******************************************************************************
 mp4_types.hpp -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_TYPES_HPP_AKW
#define MP4_TYPES_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_memory_reader.hpp"
#include "mp4_platform.hpp"
#include <inttypes.h>
#include <vector>

namespace fmp4
{

namespace { // anonymous

}

struct uint128_t
{
  uint128_t()
  {
  }

  uint128_t(uint64_t lo)
  : hi_(0)
  , lo_(lo)
  {
  }

  uint128_t(uint64_t hi, uint64_t lo)
  : hi_(hi)
  , lo_(lo)
  {
  }

  bool operator!() const
  {
    return !(hi_ || lo_);
  }

  bool operator==(uint128_t const& rhs) const
  {
    return hi_ == rhs.hi_ && lo_ == rhs.lo_;
  }

  bool operator!=(uint128_t const& rhs) const
  {
    return !(this->operator==(rhs));
  }

  bool operator<(uint128_t const& rhs) const
  {
    if(hi_ < rhs.hi_)
    {
      return true;
    }
    if(hi_ > rhs.hi_)
    {
      return false;
    }

    return lo_ < rhs.lo_;
  }

// private:
  uint64_t hi_;
  uint64_t lo_;
};

MP4_DLL_LOCAL inline uint128_t read_128(uint8_t const* buffer)
{
  return uint128_t(read_64(buffer), read_64(buffer + 8));
}

MP4_DLL_LOCAL extern std::string to_base64(uint128_t const& val);

MP4_DLL_EXPORT extern
fmp4_result hex16_decode(char const* first, char const* last,
                         uint128_t& output);

MP4_DLL_LOCAL extern std::string to_hex16(uint128_t const& val, bool lower_case = false);

MP4_DLL_LOCAL extern std::string to_uuid(uint128_t const& uuid);

MP4_DLL_EXPORT fmp4_result
uuid_decode(char const* first, char const* last, uint128_t& uuid);

MP4_DLL_LOCAL inline uint128_t uuid_swap_endianess(uint128_t const& uuid)
{
  return uint128_t(
    (static_cast<uint64_t>(
      mp4_byteswap32(static_cast<uint32_t>(uuid.hi_ >> 32))) << 32) |
    (static_cast<uint64_t>(
      mp4_byteswap16(static_cast<uint16_t>(uuid.hi_ >> 16))) << 16) |
    (static_cast<uint64_t>(
      mp4_byteswap16(static_cast<uint16_t>(uuid.hi_)))), uuid.lo_);
}

} // namespace fmp4

#endif // MP4_TYPES_HPP_AKW

// End Of File


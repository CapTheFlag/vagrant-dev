/*******************************************************************************
 expression_parser.hpp -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef EXPRESSION_PARSER_HPP_AKW
#define EXPRESSION_PARSER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <memory>

namespace fmp4
{

struct smil_switch_t;

struct MP4_DLL_LOCAL expression_parser_t
{
  expression_parser_t(char const* first, char const* last);
  ~expression_parser_t();

  bool operator()(smil_switch_t const& smil_switch) const;

private:
  struct impl;
  std::auto_ptr<impl> impl_;
};

} // namespace fmp4

#endif // EXPRESSION_PARSER_HPP_AKW

// End Of File


/*******************************************************************************
 mp4_fragment.hpp - A library for reading and writing Fragmented MPEG4.

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_FRAGMENT_HPP_AKW
#define MP4_FRAGMENT_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_math.hpp"
#include "ism_reader.hpp"
#include <inttypes.h>
#include <vector>
#include <map>

struct mp4_process_context_t;
struct buckets_t;

namespace fmp4
{

struct mp4_context_t;
struct mp4_writer_t;

struct traf_t;
struct sample_t;
struct piff_context_t;

class bucket_writer;
struct smil_switch_t;
struct options_t;

MP4_DLL_EXPORT extern
fmp4_result traf_add_samples(traf_t& traf,
                             smil_switch_t const& smil_switch,
                             uint32_t dst_timescale,
                             sample_t const* first, sample_t const* last,
                             bool output_keyframes_only);

MP4_DLL_LOCAL extern
fmp4_result traf_encrypt(mp4_process_context_t& context,
                         traf_t& traf, smil_switch_t const& smil_switch,
                         piff_context_t& piff_context,
                         buckets_t& mdat_buckets,
                         buckets_t& cenc_buckets);

// Fragment a complete file

MP4_DLL_LOCAL extern
fmp4_result mp4_fragment_file(mp4_process_context_t& context,
                              mp4_context_t const& mp4_context,
                              ism_t const& ism,
                              options_t const& options);

struct MP4_DLL_EXPORT tfra_collector_t
{
public:
  struct index_t
  {
    index_t(uint64_t time, uint64_t offset, uint32_t size, uint32_t duration)
    : time_(time)
    , offset_(offset)
    , size_(size)
    , duration_(duration)
    {
    }

    uint64_t time_;
    uint64_t offset_;
    uint32_t size_;
    uint32_t duration_;
  };

public:
  tfra_collector_t(uint32_t track_id, uint32_t timescale)
  : track_id_(track_id)
  , timescale_(timescale)
  {
  }

  void insert(uint64_t time, uint64_t offset, uint32_t size, uint32_t duration)
  {
    index_.push_back(index_t(time, offset, size, duration));
  }

public:
  uint32_t track_id_;
  uint32_t timescale_;
  typedef std::vector<index_t> indexes_t;
  indexes_t index_;
};

struct MP4_DLL_EXPORT mfra_collector_t
{
  mfra_collector_t();
  tfra_collector_t& insert(uint32_t track_id, uint32_t timescale);

  // returns the timespan [begin,end> of the presentation (all the tracks).
  std::pair<fraction_t, fraction_t> get_timespan() const;

  fmp4_result write(mp4_writer_t& mp4_writer, bucket_writer& writer,
                    int32_t offset) const;

public:
  typedef std::map<uint32_t, tfra_collector_t> tracks_t;
  tracks_t tracks_;
};

} // fmp4

#endif // MP4_FRAGMENT_HPP_AKW

// End Of File



/*******************************************************************************
 output_bucket.h - A library for writing memory / file buckets.

 Copyright (C) 2007-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef OUTPUT_BUCKET_H_AKW
#define OUTPUT_BUCKET_H_AKW

#include "mod_streaming_export.h"
#include "mp4_error.h"
#include <inttypes.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

struct mp4_process_context_t;

struct bucket_t;

struct bucket_type_t
{
  uint32_t type_;
  void (*destroy_)(void* data);
  fmp4_result (*read)(struct bucket_t* bucket, uint8_t const** buf, size_t* size);
  fmp4_result (*write)(struct bucket_t* bucket, uint8_t** buf, size_t* size);
  fmp4_result (*split)(struct bucket_t* bucket, uint64_t size);
  fmp4_result (*copy)(struct bucket_t* src, struct bucket_t** dst);
};
typedef struct bucket_type_t bucket_type_t;

MP4_DLL_LOCAL extern const bucket_type_t bucket_type_heap;
MP4_DLL_LOCAL extern const bucket_type_t bucket_type_file;
MP4_DLL_LOCAL extern const bucket_type_t bucket_type_http;

#if !defined(FOURCC)
#define FOURCC(a, b, c, d) ((uint32_t)(a) << 24) + \
                           ((uint32_t)(b) << 16) + \
                           ((uint32_t)(c) << 8) + \
                           ((uint32_t)(d))
#endif

#define IS_BUCKET_TYPE_HEAP(b) ((b)->type_->type_ == FOURCC('H', 'E', 'A', 'P'))
#define IS_BUCKET_TYPE_FILE(b) ((b)->type_->type_ == FOURCC('F', 'I', 'L', 'E'))
#define IS_BUCKET_TYPE_HTTP(b) ((b)->type_->type_ == FOURCC('H', 'T', 'T', 'P'))

struct bucket_t
{
  struct bucket_t* prev_;
  struct bucket_t* next_;

  uint64_t offset_;
  uint64_t size_;

  bucket_type_t const* type_;

  // bucket_memory_t*, bucket_file_t*
  void* data_;
};
typedef struct bucket_t bucket_t;

MP4_DLL_EXPORT extern char const* cache_control_no_cache;

struct buckets_t
{
  char const* content_type_;
  char const* cache_control_;
  uint64_t revision_id_;
  uint64_t updated_at_;
  uint64_t expires_at_;
  bucket_t* bucket_;
  char x_usp_header1[256];
  char x_usp_header2[256];
  char link_[512];
};
typedef struct buckets_t buckets_t;

// utility functions

MP4_DLL_EXPORT extern void bucket_exit(bucket_t* bucket);
MP4_DLL_EXPORT extern void bucket_delete(bucket_t* bucket);

MP4_DLL_EXPORT extern
uint64_t buckets_size(buckets_t const* buckets, bucket_t const* end_bucket);

MP4_DLL_EXPORT extern void buckets_clear(buckets_t* buckets);

MP4_DLL_EXPORT extern
void bucket_file_read(bucket_t* bucket, char const** filename,
                      uint64_t* offset, size_t* size);

MP4_DLL_EXPORT extern char* file_url_to_path(char* filename);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // OUTPUT_BUCKET_H_AKW

// End Of File


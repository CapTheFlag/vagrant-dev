/*******************************************************************************
 mp4_adobe.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_ADOBE_HPP_AKW
#define MP4_ADOBE_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <vector>
#include <string>
#include <inttypes.h>
#include <iosfwd>

namespace fmp4 {

struct mp4_writer_t;
class memory_writer;

struct afra_t
{
  struct local_t
  {
    local_t()
    {
    }

    local_t(uint64_t time, uint64_t offset)
    : time_(time)
    , offset_(offset)
    {
    }

    uint64_t time_;
    uint64_t offset_;
  };
  typedef std::vector<local_t> locals_t;

  struct global_t
  {
    global_t(uint64_t time, unsigned int segment, unsigned int fragment,
             uint64_t offset, uint64_t offset_from_afra)
    : time_(time)
    , segment_(segment)
    , fragment_(fragment)
    , offset_(offset)
    , offset_from_afra_(offset_from_afra)
    {
    }

    uint64_t time_;
    unsigned int segment_;
    unsigned int fragment_;
    uint64_t offset_;
    uint64_t offset_from_afra_;
  };
  typedef std::vector<global_t> globals_t;

  afra_t(uint32_t timescale);

  uint32_t timescale_;
  locals_t locals_;
  globals_t globals_;
};
MP4_DLL_LOCAL extern
std::size_t afra_size(mp4_writer_t& mp4_writer, afra_t const& afra);
MP4_DLL_LOCAL extern
std::size_t afra_write(mp4_writer_t& mp4_writer, afra_t const& afra, memory_writer& mem_writer);
MP4_DLL_LOCAL extern
fmp4_result afra_read(afra_t& afra, uint8_t const* buffer, uint64_t size);

struct segment_fragment_pair_t
{
  segment_fragment_pair_t(uint32_t first_segment,
                          uint32_t fragments_per_segment);

  uint32_t first_segment_;
  uint32_t fragments_per_segment_;
};

struct asrt_t
{
  // returns the total number of fragments for the segments in this run table
  uint32_t get_nr_of_fragments() const;

  // returns the corresponding segment for the given fragment.
  fmp4_result find(uint32_t fragment_index, uint32_t& segment) const;

  typedef std::vector<segment_fragment_pair_t> segment_fragment_pairs_t;
  segment_fragment_pairs_t segment_fragment_pairs_;
};

struct fragment_duration_pair_t
{
  fragment_duration_pair_t(uint32_t first_fragment,
                           uint64_t first_fragment_timestamp_,
                           uint32_t fragment_duration,
                           unsigned int discontinuity_indicator);

  bool is_end_of_presentation() const
  {
    return !duration_ && discontinuity_indicator_ == 0;
  }

  uint32_t fragment_;
  uint64_t timestamp_;
  uint32_t duration_;
  unsigned int discontinuity_indicator_;
};

struct afrt_t
{
  typedef std::vector<fragment_duration_pair_t> fragment_duration_pairs_t;

  afrt_t();
  afrt_t(uint32_t timescale);

  void insert(uint32_t fragment, uint64_t timestamp, uint32_t duration);
  void insert_eos();
  void insert_fragment_discontinuity(uint32_t fragment, uint64_t timestamp);

  unsigned int get_first_fragment() const;
  fmp4_result find_fragment_by_time(uint64_t time, uint32_t& fragment) const;

  unsigned int timescale_;
  typedef std::vector<std::string> quality_segment_url_modifiers_t;
  std::vector<std::string> quality_segment_url_modifiers_;
  fragment_duration_pairs_t fragment_duration_pairs_;
};

struct MP4_DLL_EXPORT abst_t
{
  typedef std::vector<asrt_t> segment_run_tables_t;
  typedef std::vector<afrt_t> fragment_run_tables_t;

  abst_t();
  abst_t(uint32_t timescale);

  // returns the total number of fragments for all the segments
  unsigned int get_nr_of_fragments() const;

  unsigned int bootstrap_version_;
  unsigned int profile_;
  bool live_;
  bool update_;
  unsigned int timescale_;
  uint64_t current_media_time_;
  uint64_t smpte_timecode_offset_;
  std::string movie_identifier_;
  typedef std::vector<std::string> server_base_urls_t;
  server_base_urls_t server_base_urls_;
  typedef std::vector<std::string> quality_segment_url_modifiers_t;
  quality_segment_url_modifiers_t quality_segment_url_modifiers_;
  std::string drm_data_;
  std::string meta_data_;
  segment_run_tables_t segment_run_tables_;
  fragment_run_tables_t fragment_run_tables_;
};
MP4_DLL_LOCAL extern
std::ostream& operator<<(std::ostream& os, abst_t const& abst);

MP4_DLL_LOCAL extern
std::size_t abst_size(mp4_writer_t& mp4_writer, abst_t const& abst);

MP4_DLL_LOCAL extern
std::size_t abst_write(mp4_writer_t& mp4_writer, abst_t const& abst, memory_writer& mem_writer);

MP4_DLL_EXPORT extern
fmp4_result abst_read(abst_t& abst, uint8_t const* buffer, uint64_t size);

} // namespace fmp4

#endif // MP4_ADOBE_HPP_AKW

// End Of File


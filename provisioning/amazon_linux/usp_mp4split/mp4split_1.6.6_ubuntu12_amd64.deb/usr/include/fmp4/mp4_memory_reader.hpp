/*******************************************************************************
 mp4_memory_reader.hpp - A library for reading from a memory buffer.

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_MEMORY_READER_HPP_AKW
#define MP4_MEMORY_READER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_platform.hpp"
#include <inttypes.h>
#include <string>

namespace fmp4
{

MP4_DLL_EXPORT inline uint8_t read_8(uint8_t const* buffer)
{
  return buffer[0];
}

MP4_DLL_EXPORT inline uint16_t read_16(uint8_t const* buffer)
{
  return (buffer[0] << 8) |
         (buffer[1] << 0);
}

MP4_DLL_EXPORT inline unsigned int read_24(uint8_t const* buffer)
{
  return (buffer[0] << 16) |
         (buffer[1] << 8) |
         (buffer[2] << 0);
}

MP4_DLL_EXPORT inline uint32_t read_32(uint8_t const* buffer)
{
#if defined(FMP4_FAST_UNALIGNED) && defined(FMP4_LITTLE_ENDIAN)
  return mp4_byteswap32(*(reinterpret_cast<uint32_t const*>(buffer)));
#else
  return (buffer[0] << 24) |
         (buffer[1] << 16) |
         (buffer[2] << 8) |
         (buffer[3] << 0);
#endif
}

MP4_DLL_EXPORT inline uint64_t read_64(uint8_t const* buffer)
{
#if defined(FMP4_FAST_UNALIGNED) && defined(FMP4_LITTLE_ENDIAN)
  return mp4_byteswap64(*(reinterpret_cast<uint64_t const*>(buffer)));
#else
  return ((uint64_t)(read_32(buffer)) << 32) | read_32(buffer + 4);
#endif
}

MP4_DLL_EXPORT inline uint32_t read_n(uint8_t const* buffer, unsigned int n)
{
  switch(n)
  {
  case 8:
    return read_8(buffer);
  case 16:
    return read_16(buffer);
  case 24:
    return read_24(buffer);
  case 32:
    return read_32(buffer);
  default:
    // program error
    return 0;
  }
}

template<unsigned int N>
struct nr_of_bytes
{
  enum { value = N };
};

MP4_DLL_LOCAL inline uint32_t read_bytes(uint8_t const* data, nr_of_bytes<1>)
{
  return read_8(data);
}

MP4_DLL_LOCAL inline uint32_t read_bytes(uint8_t const* data, nr_of_bytes<2>)
{
  return read_16(data);
}

MP4_DLL_LOCAL inline uint32_t read_bytes(uint8_t const* data, nr_of_bytes<3>)
{
  return read_24(data);
}

MP4_DLL_LOCAL inline uint32_t read_bytes(uint8_t const* data, nr_of_bytes<4>)
{
  return read_32(data);
}

template<unsigned int N, unsigned int M>
uint32_t read_bits(uint8_t const* data)
{
  uint32_t v = read_bytes(data + N / 8, nr_of_bytes<(N % 8 + M + 7) / 8>());

  v >>= (8 - (N + M) % 8) & 7;
  v &= 0xffffffffU >> (32 - M);

  return v;
}

class MP4_DLL_LOCAL memory_reader
{
public:
  memory_reader(uint8_t const* buffer, uint32_t size);

  uint64_t tell() const
  {
    return pos_;
  }

  bool eof() const
  {
    return pos_ == size_;
  }

  uint8_t const* get_read_ptr()
  {
    return buffer_ + pos_;
  }

  void skip(uint32_t size)
  {
    fmp4_assert(pos_ + size <= size_);
    pos_ += size;
  }

  uint8_t read_8()
  {
    fmp4_assert(pos_ + 1 <= size_);
    uint8_t v = fmp4::read_8(buffer_ + pos_);
    pos_ += 1;
    return v;
  }

  uint16_t read_16()
  {
    fmp4_assert(pos_ + 2 <= size_);
    uint16_t v = fmp4::read_16(buffer_ + pos_);
    pos_ += 2;
    return v;
  }

  unsigned int read_24()
  {
    fmp4_assert(pos_ + 3 <= size_);
    unsigned int v = fmp4::read_24(buffer_ + pos_);
    pos_ += 3;
    return v;
  }

  uint32_t read_32()
  {
    fmp4_assert(pos_ + 4 <= size_);
    uint32_t v = fmp4::read_32(buffer_ + pos_);
    pos_ += 4;
    return v;
  }

  uint64_t read_64()
  {
    fmp4_assert(pos_ + 8 <= size_);
    uint64_t v = fmp4::read_64(buffer_ + pos_);
    pos_ += 8;
    return v;
  }

private:
  uint8_t const* buffer_;
  uint32_t size_;
  uint64_t pos_;
};

struct MP4_DLL_LOCAL bitstream_t
{
  bitstream_t(uint8_t const* first, uint8_t const* last);

  int read_bit();
  bool read_boolean();
  int read_bits(int bits);
  unsigned int read_ue();
  int read_se();

  unsigned int bits_to_decode() const;
  bool byte_aligned() const;
  bool more_rbsp_data() const;

private:
  uint8_t const* first_;
  uint8_t const* last_;
  unsigned int index_;
};

} // namespace fmp4

#endif // MP4_MEMORY_WRITER_HPP_AKW

// End Of File



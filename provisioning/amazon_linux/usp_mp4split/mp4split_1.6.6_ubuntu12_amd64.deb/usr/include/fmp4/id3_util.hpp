/*******************************************************************************
 id3_util.hpp - ID3 utility functions

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef ID3_UTIL_HPP_AKW
#define ID3_UTIL_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_error.h"
#include "mp4_uri.hpp"
#include <inttypes.h>

struct pool_t;

namespace fmp4
{

class bucket_writer;

namespace id3
{

MP4_DLL_EXPORT extern fmp4_result read_syncsafe_32(uint8_t* buf, uint32_t& val);

// Usage example:
//
// reserve space for tag header:
//
// uint8_t* buf;
// writer.reserve(10, buf);
// uint64_t pos = writer.tell();
//
// write one or more frames:
//
// id3::apic_t apic("file:///var/www/video/image.jpg");
// FMP4_CHECK(id3::write(writer, apic));
//
// write tag header:
//
// id3::tag_t tag(writer.tell() - pos);
// FMP4_CHECK(write_header(buf, tag));
//
// write tag footer:
//
// uint8_t* footer;
// writer.reserve(10, footer);
// FMP4_CHECK(write_footer(footer, tag));

struct tag_t
{
  tag_t(uint32_t size);

  uint32_t size_;
}; 

MP4_DLL_LOCAL extern fmp4_result write_header(uint8_t* buf, tag_t const& tag);
MP4_DLL_LOCAL extern fmp4_result write_footer(uint8_t* buf, tag_t const& tag);

struct frame_t
{
  frame_t(uint32_t id, uint32_t size);

  uint32_t id_;
  uint32_t size_;
};

struct apic_t
{
  apic_t(url_t const& url, uint32_t fourcc);

  url_t url_;
  uint32_t fourcc_;
};

MP4_DLL_LOCAL extern
fmp4_result write(bucket_writer& writer, apic_t const& apic, pool_t* pool);

struct comm_t
{
  comm_t(std::string const& description, std::string const& comment);

  std::string description_;
  std::string comment_;
};

MP4_DLL_LOCAL extern
fmp4_result write(bucket_writer& writer, comm_t const& comm);

struct transportstream_timestamp_t
{
  transportstream_timestamp_t(uint64_t dts);

  uint64_t dts_;
};

MP4_DLL_LOCAL extern
fmp4_result write(bucket_writer& writer, transportstream_timestamp_t const& transportstream_timestamp);

struct audio_description_t
{
  audio_description_t(std::vector<uint8_t> const& data);

  std::vector<uint8_t> data_;
};

MP4_DLL_LOCAL extern
fmp4_result write(bucket_writer& writer, audio_description_t const& audio_description);

struct sei_t
{
  sei_t(uint8_t const* first, uint8_t const* last);

  uint8_t const* first_;
  uint8_t const* last_;
};

MP4_DLL_LOCAL extern fmp4_result write(bucket_writer& writer, sei_t const& sei);

struct sps_t
{
  sps_t(uint8_t const* first, uint8_t const* last);

  uint8_t const* first_;
  uint8_t const* last_;
};

MP4_DLL_LOCAL extern fmp4_result write(bucket_writer& writer, sps_t const& sps);

} // namespace id3

} // namespace fmp4

#endif // ID3_UTIL_HPP_AKW

// End Of File


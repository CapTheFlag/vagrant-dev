/*******************************************************************************
 mp4split.hpp -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4SPLIT_HPP_AKW
#define MP4SPLIT_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_uri.hpp"
#include "ism_reader.hpp"
#include <inttypes.h>
#include <vector>

namespace fmp4
{

struct dfxp_options_t
{
  dfxp_options_t()
  : offset_time_(0)
  {
  }

  // DFXP uses the timeExpression clock-time by default.
  // Specify --dfxp_offset_time for offset-time.
  uint32_t offset_time_;
};

struct options_t
{
  options_t()
  : verbose_(2)
  , use_dref_(false)
  , verify_(false)
  , dry_run_(false)
  , package_hls_(false)
  , package_mpd_(false)
  , output_single_file_(false)
  , base_media_file_("fileSequence")
  , stream_encrypt_(false)
  , streaming_key_delivery_(false)
  , start_segments_with_iframe_(false)
  , marlin_(false)
  , output_timescale_(0)
  , fragment_duration_(0)
  {
  }

  url_t output_file_;
  int verbose_;
  bool use_dref_;
  bool verify_;
  bool dry_run_;
  bool package_hls_;
  bool package_mpd_;

  // Options specific to HLS packaging
  // ---------------------------------

  //
  bool output_single_file_;

  //
  std::string base_media_file_;

  // 
  std::string encrypt_key_file_;

  // 
  std::string encrypt_key_url_;

  // use SAMPLE-AES instead of AES-128
  bool stream_encrypt_;

  // use 'com.apple.streamingkeydelivery' as KEYFORMAT
  bool streaming_key_delivery_;

  // start all segments with I-frames
  bool start_segments_with_iframe_;

  // Options specific to MPD packaging
  // ---------------------------------

  // When the content is encrypted with CENC, we follow
  // 2.3.1 'Implicit Content ID Mapping' that states:
  // - The file is signaled to be Marlin protected (that is we use --marlin)
  // - The file is protected with CENC.
  // - The file doesn't contain a MarlinKidMappingTableBox('mkid').
  //
  // Since in this case there is no pssh box specific to Marlin, we cannot
  // detect it and you need to signal it explictely so that the
  // ContentProtection field is populated.
  bool marlin_;

  // Options specific to MP4 packaging.
  // ----------------------------------

  // The output timescale used when fragmenting files. By default the original
  // timescale of the source material is used. Only to be used when preparing
  // content (ismv/piff) to be served by IIS for Smooth Streaming as this
  // requires a timescale of 10MHz.
  uint32_t output_timescale_;

  // The target duration of each fragment (in milliseconds). When the input
  // file has sync samples, then the fragments for all the streams are aligned,
  // so that an equal number of fragments are generated for each track.
  uint32_t fragment_duration_;

  // A list of (compatibility) brands.
  typedef std::vector<uint32_t> brands_t;
  brands_t brands_;

  //
  dfxp_options_t dfxp_;
};

struct input_t
{
  url_t url_;
  smil_switch_t predicate_;
};
typedef std::vector<input_t> inputs_t;

} // namespace fmp4

#endif // MP4SPLIT_HPP_AKW

// End Of File


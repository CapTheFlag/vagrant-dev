/*******************************************************************************
 mp4_platform.hpp - Platform specifics.

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_PLATFORM_HPP_AKW
#define MP4_PLATFORM_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <memory>

#ifdef UNUSED
#elif defined(__GNUC__)
# define UNUSED(x) UNUSED_ ## x __attribute__((unused))
#elif defined(__LCLINT__)
# define UNUSED(x) /*@unused@*/ x
#else
# define UNUSED(x) x
#endif

#if defined(_MSC_VER)
#define aligned_array(type, name, no, stride) \
  __declspec(align(stride)) type name[no]
#elif defined(__GNUC__)
#define aligned_array(type, name, no, stride) \
  type name[no] __attribute__ ((aligned(stride)))
#else
#define aligned_array(type, name, no, stride) \
  uint8_t _##name[no * sizeof(type) + stride];      \
  type *name = (type*)(((((intptr_t)(_##name)) + stride - 1) & ~(stride - 1)))
#endif

namespace fmp4
{

MP4_DLL_EXPORT extern void sleep(int millis);

MP4_DLL_EXPORT extern uint64_t atoi64(char const* val);
MP4_DLL_EXPORT extern uint64_t atoi64(char const* first, char const* last);

inline uint32_t atoi32(char const* first, char const* last)
{
  return static_cast<uint32_t>(atoi64(first, last));
}

inline uint16_t mp4_byteswap16(uint16_t val)
{
#if defined(_WIN32)
  return _byteswap_ushort(val);
#else
  return (val << 8) + (val >> 8);
#endif
}

inline uint32_t mp4_byteswap32(uint32_t val)
{
#if defined(_WIN32)
  return _byteswap_ulong(val);
#else
  return ((val << 24) & 0xff000000) +
         ((val <<  8) & 0x00ff0000) +
         ((val >>  8) & 0x0000ff00) +
         ((val >> 24) & 0x000000ff);
#endif
}

inline uint64_t mp4_byteswap64(uint64_t val)
{
#if defined(_WIN32)
  return _byteswap_uint64(val);
#else
  return mp4_byteswap32(val >> 32) +
         (static_cast<uint64_t>(mp4_byteswap32(val)) << 32);
#endif
}
	
MP4_DLL_EXPORT extern const char* mod_smooth_streaming_version();

MP4_DLL_LOCAL extern fmp4_result errno_to_fmp4_result();
MP4_DLL_LOCAL extern fmp4_result throw_last_error(std::string const& msg);

class MP4_DLL_LOCAL file_t
{
public:
  enum
  {
    read_only = 0,
    write_only = 1,
    read_write = 2
  };

public:
  file_t();
  ~file_t();

  fmp4_result open(char const* path, int flags);
  fmp4_result close();
  fmp4_result size(uint64_t& filesize);
  fmp4_result resize(uint64_t new_size);
  fmp4_result read(void* buf, uint64_t offset, uint32_t size);
  fmp4_result write(void const* buf, uint64_t offset, uint32_t size);
  fmp4_result map(uint64_t offset, uint32_t size, void*& addr);

private:
  class impl;
  std::auto_ptr<impl> impl_;
};

class mutex_t
{
public:
  mutex_t(char const* name);
  ~mutex_t();

  void wait();

private:
  void* handle_;
  char const* name_;
};

} // namespace fmp4

#endif // MP4_PLATFORM_HPP_AKW

// End Of File


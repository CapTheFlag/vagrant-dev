/*******************************************************************************
 mp4_wrmheader.hpp -

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_WRMHEADER_HPP_AKW
#define MP4_WRMHEADER_HPP_AKW

#include "mp4_exception.hpp"
#include "mp4_piff.hpp"
#include "mp4_io.hpp"
#include "mp4_types.hpp"
#include <inttypes.h>
#include <string>
#include <stdexcept>

namespace fmp4
{

enum piff_algorithm_t
{
  PIFF_NONE    = 0x000000,
  PIFF_AES_CTR = 0x000001,
  PIFF_AES_CBC = 0x000002
};

class MP4_DLL_EXPORT wrm_header_t
{
public:
  wrm_header_t();
  wrm_header_t(std::string const& url, uint128_t const& kid,
               piff_algorithm_t piff_algorithm);

  fmp4_result open(uint8_t const* first, uint8_t const* last);

public:
  std::string url_;
  uint128_t kid_;
  piff_algorithm_t algorithm_id_;
  uint32_t keylen_;
};

struct MP4_DLL_EXPORT playready_object_t
{
public:
  struct record_t
  {
    record_t(uint16_t type, std::vector<uint8_t> const& data)
    : type_(type)
    , data_(data)
    {
    }

    uint16_t type_;
    std::vector<uint8_t> data_;
  };

public:
  fmp4_result open(uint8_t const* first, uint8_t const* last);
  std::size_t size() const;

  typedef std::vector<record_t> records_t;
  records_t records_;
};

MP4_DLL_EXPORT extern
fmp4_result write(memory_writer& writer, playready_object_t const& obj);

struct is_type : public std::unary_function<playready_object_t::record_t, bool>
{
  is_type(uint16_t type)
  : type_(type)
  {
  }

  bool operator()(playready_object_t::record_t const& record) const
  {
    return record.type_ == type_;
  }

private:
  uint16_t type_;
};

} // namespace fmp4

#endif

// End Of File


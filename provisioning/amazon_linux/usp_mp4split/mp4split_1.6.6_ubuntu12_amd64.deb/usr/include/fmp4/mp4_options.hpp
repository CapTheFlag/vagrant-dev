/*******************************************************************************
 mp4_options.hpp - A library for splitting Quicktime/MPEG4 files.

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_OPTIONS_HPP_AKW
#define MP4_OPTIONS_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_options.h"
#include <inttypes.h>
#include <string>

struct mp4_split_options_t;

namespace fmp4
{

enum fragment_type_t
{
  FRAGMENT_TYPE_UNKNOWN,
  FRAGMENT_TYPE_AUDIO,
  FRAGMENT_TYPE_VIDEO,
  FRAGMENT_TYPE_TEXT,
  FRAGMENT_TYPE_DATA,
  FRAGMENT_TYPE_IMG
};

enum input_format_t
{
  INPUT_FORMAT_MP4,
  INPUT_FORMAT_FLV
};

enum output_format_t
{
  OUTPUT_FORMAT_MP4,
  OUTPUT_FORMAT_MOV,
  OUTPUT_FORMAT_RAW,
  OUTPUT_FORMAT_FLV,
  OUTPUT_FORMAT_TS,
  OUTPUT_FORMAT_MP4_ADOBE,
  OUTPUT_FORMAT_F4F,
  OUTPUT_FORMAT_ISMV,
  OUTPUT_FORMAT_MOOV,
  OUTPUT_FORMAT_DFXP,
  OUTPUT_FORMAT_ISMT,
  OUTPUT_FORMAT_F4M
};

MP4_DLL_EXPORT
fmp4_result mp4_options_parse(mp4_split_options_t& options,
                              const char* args_data, unsigned int args_size);

} // namespace fmp4

struct mp4_split_options_t
{
  mp4_split_options_t();
  ~mp4_split_options_t();

  int client_is_flash;
  uint64_t start;
  uint64_t end;
  int adaptive;
  std::string file;
  fmp4::output_format_t output_format;
  fmp4::input_format_t input_format;

  int seconds;
  uint64_t* byte_offsets;

//  int flv_header;

  // m3u8
  unsigned int start_index;

  // track selection (obsolete: you should use expression filter instead)
  std::string tracks_;
  std::string filter_;

  // additional query parameters
  std::string args_;

  // from query parameters min_bitrate=0&max_bitrate=1234
  // Note that only the bitrate of the video track is taken into account.
  unsigned int min_bitrate_;
  unsigned int max_bitrate_;

  // from query parameter H264. Instead of using the FourCC AVC1 for video
  // tracks in Smooth Streaming client manifests, use H264 instead.
  unsigned int h264_;
};

#endif // MP4_OPTIONS_HPP_AKW

// End Of File


/*******************************************************************************
 mp4_options.h - A library for splitting Quicktime/MPEG4 files.

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_OPTIONS_H_AKW
#define MP4_OPTIONS_H_AKW

#include "mod_streaming_export.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct mp4_split_options_t mp4_split_options_t;

MP4_DLL_EXPORT extern mp4_split_options_t* mp4_split_options_init();
MP4_DLL_EXPORT extern void mp4_split_options_exit(mp4_split_options_t* options);

MP4_DLL_EXPORT extern int mp4_split_options_set(mp4_split_options_t* options,
                                                const char* args_data,
                                                unsigned int args_size);

MP4_DLL_EXPORT extern
char const* mp4_split_options_get_file(mp4_split_options_t const* options);

MP4_DLL_EXPORT extern
uint32_t fmp4_get_throttle_seconds(mp4_split_options_t const* options);

MP4_DLL_EXPORT extern
uint64_t const* fmp4_get_throttle_offsets(mp4_split_options_t const* options);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif // MP4_OPTIONS_H_AKW

// End Of File


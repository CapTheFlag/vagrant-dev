/*******************************************************************************
 mpd_reader.hpp - A library for reading MPEG-DASH manifest files.

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MPD_READER_HPP_AKW
#define MPD_READER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_util.hpp"
#include <inttypes.h>
#include <iosfwd>
#include <string>
#include <vector>
#include <list>

struct buckets_t;
struct fmp4_handler_io_t;

namespace fmp4
{

namespace mpd
{

struct mpd_url_t
{
  mpd_url_t(std::string const& url = "", uint64_t offset = 0, uint32_t size = 0)
  : url_(url)
  , offset_(offset)
  , size_(size)
  {
  }

  std::string url_;
  uint64_t offset_;
  uint32_t size_;
};

MP4_DLL_EXPORT std::ostream& operator<<(std::ostream& os, mpd_url_t const& rhs);

MP4_DLL_EXPORT int compare(mpd_url_t const& lhs, mpd_url_t const& rhs);

struct segment_t
{
  segment_t(uint64_t time, uint32_t timescale, mpd_url_t const& mpd_url);

  uint64_t time_;
  uint32_t timescale_;
  mpd_url_t mpd_url_;
};
typedef std::vector<segment_t> segments_t;
MP4_DLL_EXPORT int compare(segment_t const& lhs, segment_t const& rhs);
MP4_DLL_LOCAL bool operator<(segment_t const& lhs, segment_t const& rhs);

class manifest_t;
struct period_t;
struct adaptation_set_t;
struct representation_t;

struct segment_timeline_t
{
  segment_timeline_t();
  ~segment_timeline_t();

  struct tdr_t
  {
    tdr_t(uint64_t time, uint32_t duration, uint32_t repeat)
    : time_(time)
    , duration_(duration)
    , repeat_(repeat)
    {
    }

    uint64_t time_;
    uint32_t duration_;
    uint32_t repeat_;
  };

  typedef std::vector<tdr_t> times_t;
  times_t times_;
};

struct segment_base_t
{
public:
  uint32_t timescale_;
  mpd_url_t index_;
  mpd_url_t initialization_;
};

struct segment_url_t
{
  mpd_url_t media_;
  mpd_url_t index_;
};

struct segment_list_t
{
public:
  segment_list_t();
  ~segment_list_t();
  fmp4_result set_attributes(char const** atts);

public:
  uint32_t timescale_;
  uint32_t duration_;
  mpd_url_t initialization_;
  typedef std::vector<segment_url_t> urls_t;
  urls_t urls_;
};

struct segment_template_t
{
public:
  segment_template_t();
  segment_template_t(segment_template_t const& rhs);
  segment_template_t& operator=(segment_template_t rhs);
  ~segment_template_t();

  friend void swap(segment_template_t& first, segment_template_t& second);

  fmp4_result set_attributes(char const** atts);

public:
  uint32_t timescale_;
  uint32_t presentation_time_offset_;
  uint32_t duration_;
  std::string initialization_;
  std::string media_;
  uint32_t start_number_;
  segment_timeline_t* segment_timeline_;
};

struct MP4_DLL_EXPORT content_protection_t
{
  content_protection_t();
  content_protection_t(uint128_t system_id);
  ~content_protection_t();

  std::string comment_;
  std::string scheme_id_uri_;
  std::string value_;
  uint128_t default_kid_;
  std::vector<uint8_t> specific_;
};

typedef std::vector<content_protection_t> content_protections_t;

struct scheme_id_value_pair_t
{
  scheme_id_value_pair_t(std::string const& scheme_id, std::string const& value)
  : scheme_id_(scheme_id)
  , value_(value)
  {
  }

  std::string scheme_id_;
  std::string value_;
};

typedef std::vector<scheme_id_value_pair_t> audio_channel_configurations_t;
typedef std::vector<scheme_id_value_pair_t> roles_t;

struct MP4_DLL_EXPORT representation_t
{
  typedef std::vector<std::string> dependency_id_t;

public:
  representation_t(adaptation_set_t const& adaptation_set);
  representation_t(representation_t const& rhs);
  representation_t& operator=(representation_t rhs);
  ~representation_t();

  friend void swap(representation_t& first, representation_t& second);

  fmp4_result get_initialization_url(mpd_url_t& mpd_url) const;
  segment_base_t const* get_segment_base() const;
  segment_list_t const* get_segment_list() const;
  segment_template_t const* get_segment_template() const;

  segments_t get_segments() const;

  bool resolve_url(url_t& url) const;

  uint32_t get_width() const;
  uint32_t get_height() const;

private:
  std::string fixup_url(std::string const& template_url, uint64_t time = 0,
                        uint32_t number = 0) const;

  segments_t get_segments_from_segment_base(segment_base_t const& segment_base) const;
  segments_t get_segments_from_segment_list(segment_list_t const& segment_list) const;
  segments_t get_segments_from_segment_timeline(segment_template_t const& segment_template, segment_timeline_t const& segment_timeline) const;
  segments_t get_segments_from_segment_template_static(segment_template_t const& segment_template) const;
  segments_t get_segments_from_segment_template_dynamic(segment_template_t const& segment_template) const;

public:
  adaptation_set_t const* adaptation_set_;

public:
  url_t base_url_;
  segment_base_t* segment_base_;
  segment_list_t* segment_list_;
  segment_template_t* segment_template_;
  std::string id_;
  uint32_t bandwidth_;
  std::string codecs_;
  dependency_id_t dependency_id_;

  // audio
  uint32_t audio_sampling_rate_;
  audio_channel_configurations_t audio_channel_configurations_;

  // video
  uint32_t width_;
  uint32_t height_;
  std::string sar_;
  std::string framerate_;
  std::string scantype_;
};

struct content_component_t
{
  std::string content_type_;
  std::string lang_;
};
typedef std::vector<content_component_t> content_components_t;

struct MP4_DLL_EXPORT adaptation_set_t
{
public:
  adaptation_set_t(period_t const& period);
  adaptation_set_t(adaptation_set_t const& rhs);
  adaptation_set_t& operator=(adaptation_set_t rhs);
  ~adaptation_set_t();

  friend void swap(adaptation_set_t& first, adaptation_set_t& second);

  segment_template_t const* get_segment_template() const;
  uint64_t get_duration() const;

  bool resolve_url(url_t& url) const;

public:
  period_t const* period_;

public:
  url_t base_url_;
  uint32_t group_;

  // common attributes (RepresentationBaseType)
  uint32_t width_;
  uint32_t height_;

  //
  std::string lang_;
  std::string mime_type_;
  std::string par_;
  uint32_t min_bandwidth_;
  uint32_t max_bandwidth_;
  uint32_t min_width_;
  uint32_t max_width_;
  uint32_t min_height_;
  uint32_t max_height_;
  std::string min_framerate_;
  std::string max_framerate_;

  std::string segment_alignment_;
//bool bitstream_switching_;
  std::string subsegment_alignment_;
  uint32_t subsegment_starts_with_sap_;
  uint32_t start_with_sap_;

  content_protections_t content_protections_;

  roles_t roles_;

  content_components_t content_components_;

  typedef std::list<representation_t> representations_t;
  representations_t representations_;

  segment_template_t* segment_template_;
};

struct period_t
{
public:
  period_t(manifest_t& manifest);
  ~period_t();

  bool resolve_url(url_t& url) const;
  uint64_t get_duration() const;

public:
  manifest_t& manifest_;

public:
  url_t base_url_;
  std::string id_;
  uint64_t start_;                        // in microseconds
  uint64_t duration_;                     // in microseconds

  typedef std::list<adaptation_set_t> adaptation_sets_t;
  adaptation_sets_t adaptation_sets_;
};

class MP4_DLL_EXPORT manifest_t
{
private:
  manifest_t(manifest_t const& rhs);
  manifest_t& operator=(manifest_t rhs);

public:
  manifest_t(url_t const& base_url);
  ~manifest_t();

  fmp4_result open(buckets_t const* buckets);
  fmp4_result open(char const* first, char const* last);
  fmp4_result open(fmp4_handler_io_t& src_io);

  bool resolve_url(url_t& url) const;
  uint64_t get_duration() const;

public:
  typedef std::pair<std::string, std::string> attribute_pair_t;
  typedef std::vector<attribute_pair_t> attributes_t;
  attributes_t attributes_;

  uint64_t created_at_;                   // in microseconds

  url_t base_url_;
  uint64_t min_buffer_time_;              // in microseconds
  std::string type_;
  typedef std::vector<std::string> profiles_t;
  profiles_t profiles_;

  // static
  uint64_t media_presentation_duration_;  // in microseconds

  // dynamic
  uint64_t availability_start_time_;      // in microseconds (e.g. 2011-12-25T12:30:00)
  uint64_t publish_time_;                 // in microseconds

  uint64_t minimum_update_period_;        // in microseconds
  uint64_t time_shift_buffer_depth_;      // in microseconds
  uint64_t max_segment_duration_;         // in microseconds

  typedef std::list<period_t> periods_t;
  periods_t periods_;
};

} // mpd

} // fmp4

#endif // MPD_READER_HPP_AKW

// End Of File


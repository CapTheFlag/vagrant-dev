/*******************************************************************************
 mp4_pubpoint.h - A library for pushing/polling input/output Fragmented MPEG4

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_PUBPOINT_H_AKW
#define MP4_PUBPOINT_H_AKW

#if !defined(FMP4_NO_INGEST_HTTP)

#include "mod_streaming_export.h"
#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

struct buckets_t;
struct mp4_split_options_t;

struct pubpoint_input_stream_t;
typedef struct pubpoint_input_stream_t pubpoint_input_stream_t;

MP4_DLL_EXPORT extern
pubpoint_input_stream_t* pubpoint_input_stream_init(
  char const* name, struct mp4_split_options_t const* options,
  char* result_text, unsigned int result_size);

MP4_DLL_EXPORT extern
void pubpoint_input_stream_exit(pubpoint_input_stream_t* pubpoint_input_stream);
 
// pubpoint_push_input_stream ingests media data.
//
// [first, last>
// The media data.
//
// result_text
// In case of an error, holds additional information.
//
// Return value:
// 200 OK.
//
// 400 Bad Request
// - Error parsing URL
//
// 403 Forbidden
// - Unable to make file mapping. Most likely cause is that the webserver
//   does not have permission to read/write to the file/directory.
//
// 404 Not Found
// - Stream not found.
// 
// 409 Conflict
// - Publishing to a stream which has previously been closed.
//
// 412 Precondition Failed
// - Requested fragment not yet available.
//
// 415 Unsupported Media Type
// - Invalid stream box.
// - Missing tfhd box in media fragment.
// - Missing tfxd box in media fragment.
// - Detected corrupt box in media fragment.
// - Box too large in media fragment.
// 
// 500 Internal Server Error
// - Not enough memory.
//

MP4_DLL_EXPORT extern
int pubpoint_push_input_stream(pubpoint_input_stream_t*,
                               unsigned char const* first,
                               unsigned char const* last,
                               char* result_text, unsigned int result_size);

// Adds an empty fragment to the database. This is used in combination with the
// get_fragment_callback. This function supplies the information used in the
// manifest generation, while the get_fragment_callback will supply the actual
// movie data.
//
// user_index is stored and passed as-is to the callback function.
// src is optional (and may be NULL). When set it points to the relative (to the
// stream's src) or absolute URL of the fragment. This is currently only used
// when ingesting HLS and then it points to the specific mpeg-ts fragment.

MP4_DLL_EXPORT extern
int pubpoint_add_empty_fragment(pubpoint_input_stream_t* pubpoint_input_stream,
                                char const* stream_name,
                                unsigned int track_id,
                                uint64_t dts, uint64_t duration,
                                uint32_t user_index,
                                char const* src,
                                char* result_text, unsigned int result_size);

MP4_DLL_EXPORT extern
int pubpoint_flush_empty_fragments(pubpoint_input_stream_t* pubpoint_input_stream,
                                   char* result_text, unsigned int result_size);

#ifdef __cplusplus
} /* extern C definitions */
#endif

#endif

#endif // MP4_PUBPOINT_H_AKW

// End Of File


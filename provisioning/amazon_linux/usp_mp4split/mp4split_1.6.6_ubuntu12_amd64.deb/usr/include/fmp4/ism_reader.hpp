/*******************************************************************************
 ism_reader.hpp - A library for reading SMIL.

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef ISM_READER_HPP_AKW
#define ISM_READER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_util.hpp"
#include "mp4_types.hpp"
#include "expression_parser.hpp"
#include "mp4_io.hpp"
#include <inttypes.h>
#include <string>
#include <vector>
#include <map>

struct mp4_process_context_t;
struct fmp4_handler_io_t;

namespace fmp4
{

struct moov_t;
struct trak_t;

enum http_streaming_t
{
  HTTP_STREAMING_UNDEFINED = 0x0000,
  HTTP_SMOOTH_STREAMING  = 0x0001,
  HTTP_LIVE_STREAMING    = 0x0002,
  HTTP_DYNAMIC_STREAMING = 0x0004,
  HTTP_DASH_STREAMING    = 0x0008
};

enum role_t
{
  ROLE_UNKNOWN = 0,

  // main media component which is intended for presentation if no other
  // information is provided.
  ROLE_MAIN,

  // media content component that is an alternative to a main media content
  // component of the same media component type.
  ROLE_ALTERNATE,

  // media content component that is supplementary to a media content component
  // of a different media component type.
  ROLE_SUPPLEMENTARY,

  // media content component with commentary (e.g. director's commentary)
  // (typically audio).
  ROLE_COMMENTARY,

  // media content component which is presented in a different language from the
  // original (e.g. dubbed audio, translated captions).
  ROLE_DUB
};

MP4_DLL_LOCAL extern
fmp4_result from_string(char const* str, std::size_t size, role_t& role);

MP4_DLL_LOCAL extern char const* to_string(role_t role);

struct MP4_DLL_EXPORT smil_switch_t
{
  typedef std::vector<uint32_t> track_ref_t;

  smil_switch_t();
  ~smil_switch_t();

  url_t get_source(url_t const& base_url) const;

  std::string type_;            // audio, video, textstream, data
  std::string src_;
  uint32_t system_bitrate_;

  // the ISO 639-2/T code of the language used. If the language is
  // unknown or to specify a neutral language use "und".
  std::string system_language_;

  uint32_t track_id_;

  // a set of track IDs that this representation depends on. For now (at least)
  // the tracks referred to must be defined in the same 'src' file.
  track_ref_t track_ref_;

  //
  std::string track_name_;
  uint32_t timescale_;
  uint32_t fourcc_;
  std::string parent_track_name_;
  bool manifest_output_;
  std::vector<uint8_t> codec_private_data_;

  // Data that is specific to the FourCC type. Used e.g. for storing the
  // ddts box, since that data is unforuntately not part of the codec private
  // data.
  std::vector<uint8_t> fourcc_data_;

  // user-friendly description. Used for alternative audio tracks in HDS (label)
  // and the NAME media attribute in HLS.
  std::string description_;

  // The GROUP-ID as used by for the GROUP-ID attribute in HLS. Defaults to
  // $type$-$fourcc$-$system_bitrate$.
  std::string group_id_;

  // main, alternate, supplementary, commentary, dub
  role_t role_;

  // video specific
  uint32_t nal_unit_length_field_;
  uint32_t max_width_;
  uint32_t max_height_;
  uint32_t display_width_;
  uint32_t display_height_;

  // audio specific
  uint32_t samplerate_;
  uint32_t channels_;
  uint32_t sample_size_;
  uint32_t packet_size_;
  uint32_t audio_tag_;      // 1, 85, 255, 353, 354, 65534

  // text specific
  std::string subtype_;     // SCMD, CHAP, SUBT, CAPT, DESC, CTRL, DATA

  // encryption
  uint32_t scheme_type_;
  uint32_t scheme_version_;

  // 0=not encrypted, 1=encrypted
  uint32_t is_encrypted_;

  // the size in bytes of the InitializationVector field. Supported values:
  // 0  - if the is_encrypted_ flag is 0 (not encrypted)
  // 8  - specifies 64-bit initialization vectors.
  // 16 - specifies 128-bit initialization vectors.
  uint32_t iv_size_;

  // the default KID
  uint128_t kid_;

  // the defaults as specified in the TrackExtends box.
  uint32_t default_sample_description_index_;
  uint32_t default_sample_duration_;
  uint32_t default_sample_size_;
  uint32_t default_sample_flags_;
};

MP4_DLL_EXPORT extern
fmp4_result set_smil_switch_from_attribute(smil_switch_t& smil_switch,
                             char const* name, char const* value);

inline bool is_img(smil_switch_t const& smil_switch)
{
  return equals(smil_switch.type_.data(), smil_switch.type_.size(),
                CONST_STR_LEN("img"));
}

inline bool is_data(smil_switch_t const& smil_switch)
{
  return equals(smil_switch.type_.data(), smil_switch.type_.size(),
                CONST_STR_LEN("data"));
}

inline bool is_audio(smil_switch_t const& smil_switch)
{
  return equals(smil_switch.type_.data(), smil_switch.type_.size(),
                CONST_STR_LEN("audio"));
}

inline bool is_video(smil_switch_t const& smil_switch)
{
  return equals(smil_switch.type_.data(), smil_switch.type_.size(),
                CONST_STR_LEN("video"));
}

inline bool is_text(smil_switch_t const& smil_switch)
{
  return equals(smil_switch.type_.data(), smil_switch.type_.size(),
                CONST_STR_LEN("textstream"));
}

inline bool is_hint(smil_switch_t const& smil_switch)
{
  return equals(smil_switch.type_.data(), smil_switch.type_.size(),
                CONST_STR_LEN("hint"));
}

struct is_track_id : public std::unary_function<smil_switch_t, bool>
{
  is_track_id(uint32_t track_id)
  : track_id_(track_id)
  {
  }

  bool operator()(smil_switch_t const& track) const
  {
    return track.track_id_ == track_id_;
  }

private:
  uint32_t track_id_;
};

struct is_track_name : public std::unary_function<smil_switch_t, bool>
{
  is_track_name(std::string const& track_name)
  : track_name_(track_name)
  {
  }

  bool operator()(smil_switch_t const& track) const
  {
    return track.track_name_ == track_name_;
  }

private:
  std::string track_name_;
};

struct is_track_type : public std::unary_function<smil_switch_t, bool>
{
  is_track_type(char const* track_type)
  : track_type_(track_type)
  {
  }

  bool operator()(smil_switch_t const& track) const
  {
    return track.type_ == track_type_;
  }

private:
  std::string track_type_;
};

MP4_DLL_LOCAL extern
bool operator<(smil_switch_t const& lhs, smil_switch_t const& rhs);

MP4_DLL_LOCAL extern std::string to_string(smil_switch_t const& track);

MP4_DLL_LOCAL extern
uint32_t get_audio_samples_per_frame(smil_switch_t const& smil_switch);

MP4_DLL_LOCAL extern
uint32_t get_audio_sample_duration(smil_switch_t const& smil_switch);

MP4_DLL_LOCAL extern
void get_dar(smil_switch_t const& smil_switch, uint32_t& darx, uint32_t& dary);
MP4_DLL_LOCAL extern
void get_par(smil_switch_t const& smil_switch, uint32_t& parx, uint32_t& pary);
MP4_DLL_LOCAL extern
void get_sar(smil_switch_t const& smil_switch, uint32_t& sarx, uint32_t& sary);
MP4_DLL_LOCAL extern
uint32_t get_dst_timescale(smil_switch_t const& smil_switch,
                           http_streaming_t http_streaming);
MP4_DLL_LOCAL extern
bool is_codec_supported(smil_switch_t const& smil_switch,
                        http_streaming_t http_streaming,
                        uint32_t client_manifest_version);
MP4_DLL_LOCAL extern
bool trak_matches_predicate(trak_t const& trak, smil_switch_t const& predicate);

MP4_DLL_EXPORT extern
bool track_matches_predicate(smil_switch_t const& track,
                             smil_switch_t const& predicate);

MP4_DLL_LOCAL extern
char const* get_trackspec_end(char const* first, char const* last);

MP4_DLL_EXPORT extern
bool get_track_info(char const*& first, char const* last,
                    std::string& track_name, uint32_t& bitrate);

struct MP4_DLL_EXPORT ism_insert_track_t
{
private:
  ism_insert_track_t(ism_insert_track_t const& rhs);
  ism_insert_track_t& operator=(ism_insert_track_t const& rhs);

public:
  ism_insert_track_t()
  {
  }

  virtual ~ism_insert_track_t()
  {
  }

  virtual bool operator()(smil_switch_t const& smil_switch) const
  {
    return true;
  }
};

struct MP4_DLL_LOCAL ism_skip_all : public ism_insert_track_t
{
  virtual bool operator()(smil_switch_t const& smil_switch) const
  {
    return false;
  }
};

struct MP4_DLL_LOCAL track_spec_filter : public ism_insert_track_t
{
  track_spec_filter(char const* first, char const* last, bool include_img)
  : first_(first)
  , last_(last)
  , include_img_(include_img)
  {
  }

  virtual bool operator()(smil_switch_t const& smil_switch) const
  {
    // always include img tracks, since they are not part of the track_spec,
    // but for audio only streams we do want to include them.
    if(include_img_ && is_img(smil_switch))
    {
      return true;
    }

    char const* first = first_;
    char const* last = last_;

    std::string track_name;
    uint32_t bitrate;
    while(get_track_info(first, last, track_name, bitrate))
    {
      if(smil_switch.system_bitrate_)
      {
        if(smil_switch.system_bitrate_ != bitrate)
        {
          continue;
        }
      }

      // if the server manifest file doesn't have a track_name set, use the type
      if(!smil_switch.track_name_.empty())
      {
        if(track_name != smil_switch.track_name_)
        {
          continue;
        }
      }
      else
      {
        if(track_name != smil_switch.type_)
        {
          continue;
        }
      }

      return true;
    }

    return false;
  }

  char const* first_;
  char const* last_;
  bool include_img_;
};

struct MP4_DLL_LOCAL track_expr_filter : public ism_insert_track_t
{
  track_expr_filter(char const* first, char const* last)
  : expression_parser_(first, last)
  {
  }

  virtual bool operator()(smil_switch_t const& smil_switch) const
  {
    return expression_parser_(smil_switch);
  }

private:
  expression_parser_t expression_parser_;
};

struct MP4_DLL_LOCAL predicate_filter : public ism_insert_track_t
{
  predicate_filter(smil_switch_t const& smil_switch)
  : predicate_(smil_switch)
  {
  }

  virtual bool operator()(smil_switch_t const& smil_switch) const
  {
    return track_matches_predicate(smil_switch, predicate_);
  }

private:
  smil_switch_t const& predicate_;
};

struct MP4_DLL_LOCAL ism_name_bitrate : public ism_insert_track_t
{
  ism_name_bitrate(std::string const& track_name, uint32_t system_bitrate)
  : track_name_(track_name)
  , system_bitrate_(system_bitrate)
  {
  }

  virtual bool operator()(smil_switch_t const& smil_switch) const
  {
    if(smil_switch.system_bitrate_)
    {
      if(smil_switch.system_bitrate_ != system_bitrate_)
      {
        return false;
      }
    }

    // if the server manifest file doesn't have a track_name set, use the type
    if(!smil_switch.track_name_.empty())
    {
      if(track_name_ != smil_switch.track_name_)
      {
        return false;
      }
    }
    else
    {
      if(track_name_ != smil_switch.type_)
      {
        return false;
      }
    }

    return true;
  }

  std::string const& track_name_;
  uint32_t system_bitrate_;
};

struct MP4_DLL_EXPORT ism_t
{
private:
//  ism_t(ism_t const& rhs);
//  ism_t& operator=(ism_t const& rhs);

private:
  enum type_t
  {
    TYPE_ISM,
    TYPE_ISML,
    TYPE_SMIL
  };

public:
  typedef std::vector<smil_switch_t> tracks_t;

  enum playout_type_t
  {
    // the playout's default is enabled for all formats
    PLAYOUT_TRUE,

    // playout is disabled and will throw a 403
    PLAYOUT_FALSE,

    // playout is specifically enabled to be in the clear
    PLAYOUT_CLEAR,

    // playout MUST be encrypted using AES
    PLAYOUT_AES,

    // playout MUST be encrypted using dxdrm
    PLAYOUT_DXDRM,

    // playout MUST be encrypted using Adobe Access
    PLAYOUT_FAXS,

    // playout MUST be encrypted using Marlin
    PLAYOUT_MARLIN,

    // playout MUST be encrypted using PlayReady
    PLAYOUT_PLAYREADY,

    // playout MUST be encrypted using SAMPLE-AES
    PLAYOUT_SAMPLE_AES,

    // playout MUST be encrypted using Verimatrix HLS
    PLAYOUT_VERIMATRIX_HLS,

    // playout MUST be encrypted using Irdeto Secure Key Exchange (HLS)
    PLAYOUT_IRDETO
  };

  struct drm_t
  {
  public:
    // In the case of preapplied DRM the protections field contains the
    // the system_id and the corresponding opaque client data.
    //
    // PlayReady   - WRMHEADER
    // FlashAccess - drmAdditionalHeader
    // Marlin      - MarlinSystemSpecificHeaderBox

//    typedef uint128_t system_id_t;
//    typedef std::vector<uint8_t> system_data_t;
//    typedef std::pair<system_id_t, system_data_t> protection_t;
//    typedef std::map<system_id_t, system_data_t> protections_t;
//    protections_t protections_;

      psshs_t protections_;

    // When DRM is pre-applied you can specify one or more pairs of key id
    // and content key. If the fragment is encrypted, it is decrypted first
    // and then passed on to the muxing stage.
    struct key_pair_t
    {
      key_pair_t(uint128_t kid = 0, uint128_t cek = 0)
      : kid_(kid)
      , cek_(cek)
      {
      }

      uint128_t kid_;
      uint128_t cek_;
    };

    typedef std::vector<key_pair_t> decrypt_keys_t;
    decrypt_keys_t decrypt_keys_;

    // In the case of on-the-fly DRM the protections field (above) is empty.
    // The specifics structure contains all the fields necessary for the
    // different DRM systems.
    struct MP4_DLL_EXPORT specific_t
    {
      // verimatrix, buydrm
      std::string key_provider_;
      std::string key_provider_url_;

      // the kid:cek pairs
      typedef std::vector<key_pair_t> encrypt_keys_t;
      encrypt_keys_t encrypt_keys_;

      // the kid:cek pairs share the IV and license server URL.
      std::vector<uint8_t> iv_;
      std::string license_server_url_;

      // The opaque client data
      std::vector<uint8_t> drm_specific_data_;
    };
    typedef std::map<std::string, specific_t> specifics_t;
    specifics_t specifics_;

    bool is_input_protected(uint8_t const system_id[16]) const;
    bool is_output_protected(std::string const& drm_type) const;

    fmp4_result get_output_protection(std::string const& drm_type,
                                      specific_t const*& specific) const;
  };

public:
  explicit ism_t(url_t const& url);
  ~ism_t();

  fmp4_result open(char const* first, char const* last,
                   ism_insert_track_t const& insert_track);
  fmp4_result open(fmp4_handler_io_t& src_io,
                   ism_insert_track_t const& insert_track);

  fmp4_result find(uint32_t bitrate, std::string const& track_name,
                   smil_switch_t const*& smil_switch) const;

  uint32_t get_minimum_fragment_duration(http_streaming_t http_streaming) const;
  uint32_t get_default_fragment_duration(http_streaming_t http_streaming) const;
  uint32_t get_client_manifest_version(http_streaming_t http_streaming) const;

  url_t const& get_url() const;
  void set_url(url_t const& url);
  std::string get_presentation_name() const;
  url_t get_database_url() const;

  type_t get_type() const;
  bool is_isml() const;
  bool is_smil() const;
  url_t get_base_url(mp4_process_context_t& context, http_streaming_t http_streaming) const;

private:
  url_t url_;
  type_t type_;

public:
  std::string client_manifest_relative_path_;

  // the audio/video/textstream/data tracks
  tracks_t tracks_;

  // live
  std::string database_path_;

  // recording
  uint32_t lookahead_fragments_;
  uint32_t dvr_window_length_;
  uint32_t archive_length_;
  uint32_t archive_segment_length_;
  bool archiving_;
  bool restart_on_encoder_reconnect_;
  std::string event_id_;

  // playback
  drm_t drm_;

  // HTTP Smooth Streaming
  playout_type_t iss_playout_;
  uint32_t iss_minimum_fragment_length_;
  uint32_t iss_client_manifest_version_;
  std::string iss_base_path_;

  // when set, text tracks are not encrypted when DRM is used.
  bool iss_no_text_drm_;

  // HTTP Live Streaming
  playout_type_t hls_playout_;
  uint32_t hls_minimum_fragment_length_;
  uint32_t hls_client_manifest_version_;
  std::string hls_base_path_;
  bool hls_no_audio_only_;

  // add padding to the end, so that the last TS packet's continuity counter
  // equals 15.
  bool hls_no_discontinuities_;

  // do not pad the end of a PES, but (try and) insert the PES in the last
  // TS packet.
  bool hls_optimized_;

  // inline the drm specific data (e.g. faxs) in m3u8 playlists
  bool hls_inline_drm_;

  // for HLS manifest version >= 4, do not include an audio track to the
  // video presentations. This saves the audio bandwidth, since the player
  // may decide to use an alternate audio rendering. The default is to include
  // an audio track, since the URL/fragments are then identical to version 1
  // playlists and (may) give better caching results.
  bool hls_no_multiplex_;

  // Pass SEI messages as ID3 frames.
  bool hls_pass_sei_;

  // milliseconds between pat/pmt (defaults to 0, i.e. only ony pat/pmt is
  // written at the beginning of a fragment).
  uint32_t hls_psi_;

  // HTTP Dynamic Streaming
  playout_type_t hds_playout_;
  uint32_t hds_minimum_fragment_length_;
  uint32_t hds_client_manifest_version_;
  std::string hds_base_path_;
  bool hds_inline_drm_;

  // see note above about hls_no_multiplex_ (HDS manifest version >= 2)
  bool hds_no_multiplex_;

  // create a multi-level manifest (i.e. one set-level manifest and multiple
  // stream-level manifests).
  bool hds_multi_level_;

  // HTTP DASH Streaming
  playout_type_t mpd_playout_;
  uint32_t mpd_minimum_fragment_length_;
  std::string mpd_base_path_;
  bool mpd_inline_drm_;

  // the value of the @minBufferTime attribute in the MPD element
  // (in milliseconds).
  uint32_t mpd_min_buffer_time_;

  // Create MP4 from files in server manifest (progressive)
  bool progressive_playout_;

  // Only publish the segment once for all the streams. Discontinuity is
  // handled at the application level for Just-In-Time Packaging.
  uint32_t ref_video_system_bitrate_;

  // additional time shift to delay live streams (in seconds).
  uint32_t time_shift_;

  // The # of fragments to skip at the beginning, respectively the end of the
  // DVR window when ingesting F4M like streams.
  uint32_t f4m_dvr_offset_begin_;
  uint32_t f4m_dvr_offset_end_;

  // Variant sets. Each 
  typedef std::vector<smil_switch_t> variants_t;

  struct variant_set_t
  {
    variant_set_t(std::string const& include)
    : include_(include)
    {
    }

    // the playout formats for which to include this variant set. E.g.
    // include="m3u8" or include="m3u8,f4m"
    std::string include_;

    variants_t::const_iterator begin() const { return variants_.begin(); }
    variants_t::const_iterator end() const { return variants_.end(); }

    variants_t variants_;
  };

  typedef std::vector<variant_set_t> variant_sets_t;
  variant_sets_t variant_sets_;

  // Section 8.3.2 of [DSystem]
  std::string base_location_;

  // Section 8.3.3 of [DSystem]
  std::string purchase_location_;

  // the Asset Physical Identifier (APID) as defined in Section 5.5.1
  // "Asset Identifiers" of [DSystem]
  std::string apid_;
};

MP4_DLL_LOCAL extern
fmp4_result set_value_from_args(ism_t& ism, std::string const& args);

MP4_DLL_EXPORT extern
fmp4_result set_value(ism_t& ism, char const* name, char const* value,
                      bool is_query);

MP4_DLL_EXPORT extern
fmp4_result set_drm_option(ism_t::drm_t::specific_t& specific,
                           std::string const& drm_type,
                           char const* name, std::string const& value);

MP4_DLL_EXPORT extern std::string to_string(ism_t const& ism);

MP4_DLL_EXPORT extern fmp4_result set_drm_defaults(ism_t& ism);

MP4_DLL_EXPORT extern
std::string get_codec(smil_switch_t const& smil_switch, bool hex = true);

MP4_DLL_LOCAL extern
fmp4_result trak_set_info(moov_t& moov, trak_t& trak,
                          ism_t const& ism, smil_switch_t const& smil_switch);

MP4_DLL_EXPORT extern
fmp4_result create_key_pair(char const* first, char const* last,
                            ism_t::drm_t::key_pair_t& key_pair);

MP4_DLL_LOCAL extern
url_t get_base_url(mp4_process_context_t& context,
                   http_streaming_t http_streaming_t,
                   std::string const& base);

MP4_DLL_LOCAL extern
char const* skip_presentation_name(ism_t const& ism,
                                   char const* first, char const* last);

#if 0
MP4_DLL_LOCAL extern
fmp4_result update_tracks_info(mp4_process_context_t& context,
                               ism_t const& ism, ism_t::tracks_t& tracks);

MP4_DLL_LOCAL extern
fmp4_result update_track_info(mp4_process_context_t& context,
                              ism_t const& ism, smil_switch_t& smil_switch);
#endif

MP4_DLL_LOCAL extern
fmp4_result get_track_info(ism_t const& ism,
                           char const*& first, char const* last,
                           ism_t::tracks_t& tracks);

MP4_DLL_LOCAL extern
fmp4_result get_track_info(ism_t::tracks_t const& tracks,
                           smil_switch_t const*& sync_track,
                           smil_switch_t const*& audio_track,
                           smil_switch_t const*& video_track,
                           smil_switch_t const*& data_track,
                           smil_switch_t const*& text_track);

MP4_DLL_LOCAL extern
smil_switch_t const* find_sync_track(ism_t::tracks_t const& tracks);

} // namespace fmp4

#endif // ISM_READER_HPP_AKW

// End Of File


/*******************************************************************************
 mp4_exception.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_EXCEPTION_HPP_AKW
#define MP4_EXCEPTION_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_error.h"
#include <inttypes.h>
#include <string>
#include <stdexcept>

// By default the library uses exceptions. If, for a good reason, you want
// to change this to using return values instead, you have to define the macro
// FMP4_NO_EXCEPTIONS.
//
// Note that with exceptions the errors hold an additional error description.
// When using return values, there is only an error code.

// #define FMP4_NO_EXCEPTIONS

struct mp4_process_context_t;

namespace fmp4
{

struct MP4_DLL_EXPORT exception : public std::runtime_error
{
public:
  exception(std::string const& str, fmp4_result result)
  : std::runtime_error(str)
  , result_(result)
  {
  }

  fmp4_result result_;
};

// When FMP4_NO_EXCEPTIONS is undefined fmp4_throw throws an fmp4::exception.
// When defined it simply returns the result code.

MP4_DLL_EXPORT extern
fmp4_result fmp4_throw(fmp4_result rc, char const* str = 0);

MP4_DLL_EXPORT extern
fmp4_result fmp4_throw(fmp4_result rc, std::string const& str);

// Utility functions to copy the exception info into a zero terminated buffer.

MP4_DLL_LOCAL extern
uint32_t fmp4_exception(fmp4::exception const& ex, char* msg, int msg_size);

MP4_DLL_LOCAL extern
uint32_t fmp4_exception(std::exception const& ex, char* msg, int msg_size);

MP4_DLL_EXPORT extern
void throw_assert(char const *file, int line, char const* function, char const* expr);

#if __GNUC__ >= 2
#define FMP4_PRETTY_FUNCTION __PRETTY_FUNCTION__
#elif defined(_MSC_VER)
#define FMP4_PRETTY_FUNCTION __FUNCTION__
#else
#define FMP4_PRETTY_FUNCTION 0
#endif

#if 1 || defined(_DEBUG)
#define fmp4_assert(expr)                                                \
  if(!(expr))                                                            \
  {                                                                      \
    fmp4::throw_assert(__FILE__, __LINE__, FMP4_PRETTY_FUNCTION, #expr); \
  }
#else
#define fmp4_assert(expr)
#endif

#if defined(_DEBUG)
#define fmp4_assert_debug(expr) fmp4_assert(expr)
#else
#define fmp4_assert_debug(expr)
#endif

MP4_DLL_EXPORT extern
fmp4_result throw_parse_error(char const *file, int line, char const* function, char const* expr);

#define fmp4_assert_parse0(expr)                                          \
  if(!(expr))                                                            \
  {                                                                      \
    return fmp4::throw_parse_error(__FILE__, __LINE__, FMP4_PRETTY_FUNCTION, #expr); \
  }

#define fmp4_assert_parse1(expr, msg)                                          \
  if(!(expr))                                                            \
  {                                                                      \
    return fmp4::throw_parse_error(__FILE__, __LINE__, msg, #expr); \
  }

// Convert the result code to an HTTP status code.

MP4_DLL_EXPORT extern uint32_t fmp4_result_to_http(fmp4_result rc);

// MP4_DLL_LOCAL extern uint32_t fmp4_result_to_http(mp4_process_context_t& context);
MP4_DLL_EXPORT extern uint32_t rethrow(mp4_process_context_t& context);

} // fmp4

#endif // MP4_EXCEPTION_HPP_AKW

// End Of File


/*******************************************************************************
 mp4_reader.hpp - A library for general MPEG4 I/O.

 Copyright (C) 2007-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_READER_HPP_AKW
#define MP4_READER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_io.hpp"
#include <inttypes.h>
#include <list>

struct fmp4_handler_io_t;

namespace fmp4
{

struct mp4_context_t;

class MP4_DLL_EXPORT moof_reader_t
{
public:
  moof_reader_t(moov_t const& moov, trex_t const& trex, tenc_t const& tenc);

  trak_t const* get_trak(uint32_t track_id) const;
  trex_t const& get_trex(uint32_t track_id) const;
  tenc_t const& get_tenc(uint32_t track_id,
                         uint32_t sample_description_index) const;

private:
  // initialization segment
  moov_t const& moov_;

  // default for boxes when they are not available in the initialization segment
  trex_t trex_;
  tenc_t tenc_;

public:
  // start offset of the moof box
  uint64_t moof_offset_;

  // size of the moof box
  uint32_t moof_size_;

  // allow for absolute offsets? Okay when processing files, but not for
  // in-memory fragments.
  bool absolute_offsets_ok_;

  // the (signed) offset of the sample data relative to the moof_offset.
  int32_t data_offset_;
};

MP4_DLL_EXPORT extern
fmp4_result moov_read(moov_t& moov, uint8_t const* buffer, uint32_t size,
                      url_t const& url);

MP4_DLL_LOCAL extern
fmp4_result mvhd_read(mvhd_t& mvhd, uint8_t const* buffer, uint32_t size);

MP4_DLL_LOCAL extern
fmp4_result trak_read(trak_t& trak, uint8_t const* buffer, uint32_t size);

MP4_DLL_LOCAL extern
fmp4_result tkhd_read(tkhd_t& tkhd, uint8_t const* buffer, uint32_t size);

MP4_DLL_LOCAL extern
fmp4_result hdlr_read(hdlr_t& hdlr, uint8_t const* buffer, uint32_t size);

MP4_DLL_EXPORT extern
fmp4_result sidx_read(sidx_t& sidx, uint8_t const* first, uint32_t size);

MP4_DLL_EXPORT extern
fmp4_result moof_read(moof_t& moof, uint8_t const* buffer, uint32_t size,
                      moof_reader_t const& moof_reader);

MP4_DLL_EXPORT extern
fmp4_result mfra_read(mfra_t& mfra, uint8_t const* buffer, uint32_t size);

enum mp4_open_flags
{
  MP4_OPEN_FTYP = 0x00000001,
  MP4_OPEN_BLOC = 0x00000002,
  MP4_OPEN_MOOV = 0x00000004,
  MP4_OPEN_SIDX = 0x00000008,
  MP4_OPEN_MOOF = 0x00000010,
  MP4_OPEN_MFRA = 0x00000020,
  MP4_OPEN_ALL  = 0x0000003f
};

MP4_DLL_EXPORT extern
fmp4_result mp4_open(fmp4_handler_io_t& src_io,
                     mp4_context_t* mp4_context,
                     int open_flags, int must_exist_flags);

MP4_DLL_EXPORT extern
fmp4_result moof_build_index(moov_t& moov,
                             std::list<moof_t*> const& moofs);

MP4_DLL_EXPORT extern
fmp4_result avcC_read(avcC_t& avcC, uint8_t const* buffer, std::size_t size);

MP4_DLL_LOCAL extern
fmp4_result tfxd_read(tfxd_t& tfxd, uint8_t const* buffer, uint32_t size);

MP4_DLL_LOCAL extern
fmp4_result hvcC_read(hvcC_t& hvcC, uint8_t const* buffer, std::size_t size);

MP4_DLL_EXPORT extern
fmp4_result trak_build_index(moov_t const& moov, trak_t& trak);

} // namespace fmp4

#endif // MP4_READER_HPP_AKW

// End Of File


/*******************************************************************************
 adts_util.hpp - ADTS utility functions

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef ADTS_UTIL_HPP_AKW
#define ADTS_UTIL_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_memory_reader.hpp"
#include <inttypes.h>
#include <vector>

namespace fmp4
{

struct adts_t
{
  adts_t(uint8_t const* first, std::size_t size)
  : data_(first, first + size)
  {
  }

  uint32_t get_syncword() const
  {
    return read_bits<0, 12>(&data_[0]);
  }

  uint32_t get_id() const
  {
    return read_bits<12, 1>(&data_[0]);
  }

  uint32_t get_layer() const
  {
    return read_bits<13, 2>(&data_[0]);
  }

  uint32_t get_protection_absent() const
  {
    return read_bits<15, 1>(&data_[0]);
  }

  uint32_t get_profile() const
  {
    return read_bits<16, 2>(&data_[0]);
  }

  uint32_t get_samplerate_index() const
  {
    return read_bits<18, 4>(&data_[0]);
  }

  uint32_t get_private_bit() const
  {
    return read_bits<22, 1>(&data_[0]);
  }

  uint32_t get_channel_configuration() const
  {
    return read_bits<23, 3>(&data_[0]);
  }

  uint32_t get_original_copy() const
  {
    return read_bits<26, 1>(&data_[0]);
  }

  uint32_t get_home() const
  {
    return read_bits<27, 1>(&data_[0]);
  }

  uint32_t get_copyright_identication_bit() const
  {
    return read_bits<28, 1>(&data_[0]);
  }

  uint32_t get_copyright_identication_start() const
  {
    return read_bits<29, 1>(&data_[0]);
  }

  uint32_t get_aac_frame_length() const
  {
    return read_bits<30,13>(&data_[0]);
  }

  uint32_t get_adts_buffer_fullness() const
  {
    return read_bits<43,11>(&data_[0]);
  }

  uint32_t get_no_raw_data_blocks_in_frame() const
  {
    return read_bits<54,2>(&data_[0]);
  }

private:
  std::vector<uint8_t> data_;
};

} // namespace fmp4

#endif // ADTS_UTIL_HPP_AKW

// End Of File


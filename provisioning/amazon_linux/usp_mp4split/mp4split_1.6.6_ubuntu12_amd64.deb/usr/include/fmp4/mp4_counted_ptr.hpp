/*******************************************************************************
 mp4_counted_ptr.hpp -

 Copyright (C) 2012-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_COUNTED_PTR_HPP_AKW
#define MP4_COUNTED_PTR_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <memory>
#include <algorithm>

namespace fmp4 {

struct counter_t
{
  counter_t()
  : count_(1)
  {
  }

  unsigned int count_;
};

namespace detail {

struct static_cast_tag {};
struct dynamic_cast_tag {};

} // namespace detail

template<typename T>
class counted_ptr
{
private:
  void acquire(counter_t* counter)
  {
    counter_ = counter;
    if(counter_)
    {
      ++counter_->count_;
    }
  }

  void release()
  {
    if(counter_)
    {
      --counter_->count_;
      if(counter_->count_ == 0)
      {
        delete obj_;
        delete counter_;
      }
      counter_ = 0;
      obj_ = 0;
    }
  }

public:
  counted_ptr()
  : obj_(0)
  , counter_(0)
  {
  }

  template<class X>
  counted_ptr(X* obj)
  : obj_(obj)
  , counter_(obj == 0 ? 0 : new counter_t())
  {
  }

  template<class X>
  counted_ptr(counted_ptr<X> const& rhs)
  : obj_(rhs.obj_)
  , counter_(rhs.counter_)
  {
    if(counter_)
    {
      ++counter_->count_;
    }
  }

  template<class X>
  counted_ptr(counted_ptr<X> const & rhs, detail::static_cast_tag)
  : obj_(static_cast<T*>(rhs.obj_))
  , counter_(rhs.counter_)
  {
    if(counter_)
    {
      ++counter_->count_;
    }
  }

  template<class X>
  counted_ptr(counted_ptr<X> const& rhs, detail::dynamic_cast_tag)
  : obj_(dynamic_cast<T*>(rhs.obj_))
  , counter_(rhs.counter_)
  {
    fmp4_assert(obj_ != 0);

    if(counter_)
    {
      ++counter_->count_;
    }
  }

  ~counted_ptr()
  {
    release();
  }

  void reset()
  {
    counted_ptr().swap(*this);
  }

  template<typename X>
  void reset(X* obj)
  {
    fmp4_assert(obj == 0 || obj != obj_);
    counted_ptr(obj).swap(*this);
  }

  counted_ptr(counted_ptr const& rhs)
  : obj_(rhs.obj_)
  {
    acquire(rhs.counter_);
  }

  counted_ptr& operator=(counted_ptr rhs)
  {
    swap(rhs);

    return *this;
  }

  T& operator*() const
  {
    fmp4_assert(obj_ != 0);

    return *obj_;
  }

  T* operator->() const
  {
    fmp4_assert(obj_ != 0);

    return obj_;
  }

  T* get() const
  {
    return obj_;
  }

  bool unique() const
  {
    return counter_ && counter_->count_ == 1;
  }

  void swap(counted_ptr& rhs)
  {
    std::swap(obj_, rhs.obj_);
    std::swap(counter_, rhs.counter_);
  }

  T* obj_;
  counter_t* counter_;
};

template<class T, class U> counted_ptr<T>
static_pointer_cast(counted_ptr<U> const& rhs)
{
  return counted_ptr<T>(rhs, detail::static_cast_tag());
}

template<class Derived, class Base> counted_ptr<Derived>
dynamic_pointer_cast(counted_ptr<Base> const& rhs)
{
  return counted_ptr<Derived>(rhs, detail::dynamic_cast_tag());
}

} // namespace fmp4

#endif // MP4_COUNTED_PTR_HPP_AKW

// End Of File


/*******************************************************************************
 mp4_piff.hpp - A library for MPEG4 PIFF I/O.

 Copyright (C) 2009-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_PIFF_HPP_AKW
#define MP4_PIFF_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_io.hpp"
#include <inttypes.h>
#include <vector>
#include <string>

struct mp4_process_context_t;

namespace fmp4
{

struct mp4_writer_t;
class memory_writer;
class moof_reader_t;
struct smil_switch_t;

enum
{
  CENC_NONE    = 0x000000,
  CENC_AES_CTR = 0x000001,
  CENC_AES_CBC = 0x000002
};

MP4_DLL_LOCAL extern const uint8_t mp4_uuid_pssh[16];
MP4_DLL_EXPORT extern const uint8_t mp4_uuid_senc[16];
MP4_DLL_LOCAL extern const uint8_t mp4_uuid_tenc[16];

MP4_DLL_EXPORT extern const uint8_t mp4_system_id_playready[16];
MP4_DLL_EXPORT extern const uint8_t mp4_system_id_flashaccess[16];
MP4_DLL_EXPORT extern const uint8_t mp4_system_id_marlin[16];
MP4_DLL_EXPORT extern const uint8_t mp4_system_id_verimatrix[16];
MP4_DLL_EXPORT extern const uint8_t mp4_system_id_widevine[16];

MP4_DLL_LOCAL extern
std::size_t sinf_write(mp4_writer_t& mp4_writer, sinf_t const& sinf, memory_writer& mem_writer);
MP4_DLL_LOCAL extern std::size_t sinf_size(mp4_writer_t& mp4_writer, sinf_t const& sinf);

MP4_DLL_LOCAL extern std::size_t
piff_senc_write(mp4_writer_t& mp4_writer, senc_t const& senc, memory_writer& mem_writer);
MP4_DLL_LOCAL extern std::size_t
dash_senc_write(mp4_writer_t& mp4_writer, senc_t const& senc, memory_writer& mem_writer);
MP4_DLL_LOCAL extern
std::size_t piff_senc_size(mp4_writer_t& mp4_writer, senc_t const& senc);
MP4_DLL_LOCAL extern
std::size_t dash_senc_size(mp4_writer_t& mp4_writer, senc_t const& senc);
MP4_DLL_LOCAL extern
fmp4_result senc_read(senc_t& senc, uint8_t const* buffer, uint32_t size,
                      tfhd_t const& tfhd, moof_reader_t const& moof_reader);

MP4_DLL_LOCAL extern std::size_t saiz_size(mp4_writer_t& mp4_writer, senc_t const& senc);
MP4_DLL_LOCAL extern std::size_t saiz_write(mp4_writer_t& mp4_writer, senc_t const& senc, memory_writer& mem_writer);
MP4_DLL_LOCAL extern std::size_t saio_size(mp4_writer_t& mp4_writer, senc_t const& senc);
MP4_DLL_LOCAL extern std::size_t saio_write(mp4_writer_t& mp4_writer, senc_t const& senc, memory_writer& mem_writer);

struct aeib_t
{
  std::string encryption_algorithm_; // AES-CBC
  unsigned int key_size_;
};

struct akey_t
{
  akey_t();
  akey_t(akey_t const& rhs);
  ~akey_t();

  unknown_atoms_t unknown_atoms_;
  struct flxs_t* flxs_;
};

struct aprm_t
{
  unknown_atoms_t unknown_atoms_;
  // Encryption information box
  aeib_t aeib_;
  // Key information box
  akey_t akey_;
};

struct ahdr_t
{
  ahdr_t();

  unknown_atoms_t unknown_atoms_;

  // 1 = FMRMS v1.x products
  // 2 = Flash Access 2.0 products
  unsigned int version_;
  // Standard encryption params box
  aprm_t aprm_;
};

struct adaf_t
{
  bool selective_encryption_;
  unsigned int iv_size_;
};

struct adkm_t
{
  unknown_atoms_t unknown_atoms_;
  // Adobe DRM Header box
  ahdr_t ahdr_;
  // Access Unit Format box
  adaf_t adaf_;
};

struct flxs_t
{
  std::vector<uint8_t> metadata_;
};

MP4_DLL_LOCAL extern
fmp4_result create_wrmheader(uint128_t const& kid,
                             uint128_t const& cek,
                             std::string const& url,
                             std::vector<uint8_t>& wrmheader);

MP4_DLL_LOCAL extern
pssh_t pssh_set_playready(std::vector<uint8_t> const& wrmheader,
                          bool include_els);

MP4_DLL_LOCAL extern pssh_t pssh_set_flashaccess(mp4_process_context_t& context,
                                                 adkm_t const& adkm);

MP4_DLL_LOCAL extern pssh_t pssh_set_verimatrix_hls(std::string const& url);

struct piff_context_t
{
  piff_context_t();

  piff_context_t(uint32_t scheme_type, uint32_t algorithm_id,
                 unsigned int iv_size, uint128_t const& kid);
  
  // scheme_type = FOURCC_cenc or FOURCC_piff
  uint32_t scheme_type_;
  // algorithm_id = CENC_AES_CTR, PIFF_CTR, PIFF_CBC
  uint32_t algorithm_id_;
  unsigned int iv_size_;
  uint128_t kid_;

  std::string url_;
  uint128_t cek_;
  uint8_t iv_[16];
};

struct add_scheme_specific_data_t
{
  virtual ~add_scheme_specific_data_t() = 0;
  virtual fmp4_result operator()(schi_t& schi) = 0;
};

struct add_cenc_specific_data : public add_scheme_specific_data_t
{
  add_cenc_specific_data(uint32_t algorithm_id,
                         unsigned int iv_size,
                         uint128_t const& kid);

  fmp4_result operator()(schi_t& schi);

private:
  uint32_t algorithm_id_;
  unsigned int iv_size_;
  uint128_t kid_;
};

struct add_adkm_specific_data : public add_scheme_specific_data_t
{
  add_adkm_specific_data(unsigned int iv_size,
                         std::vector<uint8_t> const& faxs);

  fmp4_result operator()(schi_t& schi);

private:
  unsigned int iv_size_;
  std::vector<uint8_t> faxs_;
};

MP4_DLL_LOCAL extern fmp4_result
trak_add_encryption_boxes(trak_t& trak, uint32_t scheme_type,
                          add_scheme_specific_data_t& add_scheme_specific_data);

MP4_DLL_EXPORT extern void trak_remove_encryption_boxes(trak_t& trak);

MP4_DLL_LOCAL extern
void traf_add_encryption_boxes(traf_t& traf, piff_context_t const* piff_context,
                               bool use_subsample_encryption);

MP4_DLL_LOCAL extern
fmp4_result piff_encrypt(piff_context_t* context,
                         uint8_t* dst,
                         struct senc_t* senc,
                         uint8_t const* first, uint8_t const* last,
                         smil_switch_t const& smil_switch);

MP4_DLL_EXPORT extern
fmp4_result piff_decrypt(mp4_process_context_t const& context,
                         moov_t const& moov, moof_t& moof,
                         uint8_t* data, uint32_t data_size);

} // namespace fmp4

#endif // MP4_PIFF_HPP_AKW

// End Of File


/*******************************************************************************
 mp4_xml.hpp - A library for reading SMIL.

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_XML_HPP_AKW
#define MP4_XML_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_platform.hpp" // for atoi64
#include "mp4_util.hpp"     // for base64_decode, hex16_uuid_decode
#include <inttypes.h>
#include <string>
#include <vector>
#include <stack>
#include <algorithm>
#include <new>
#include <cstddef>
#include <iterator>
#include <map>
#if defined(_DEBUG)
#include <iostream>
#endif

struct buckets_t;

namespace fmp4
{

class xml_stack_t;

struct MP4_DLL_EXPORT xml_element_parser
{
  virtual ~xml_element_parser();
  virtual fmp4_result on_start_element(xml_stack_t& xml_stack,
                                       char const*, uint32_t, char const**);
  virtual void on_character_data(char const* first, char const* last);
  virtual fmp4_result on_end_element(char const* name);
};

struct MP4_DLL_LOCAL xml_element_string : public xml_element_parser
{
  xml_element_string(std::string& str)
  : str_(str)
  {
  }

  void on_character_data(char const* first, char const* last)
  {
    std::copy(first, last, std::back_inserter(str_));
  }

private:
  std::string& str_;
};

struct MP4_DLL_LOCAL xml_element_url : public xml_element_parser
{
  xml_element_url(url_t& val)
  : val_(val)
  {
    cdata_.reserve(32);
  }

  void on_character_data(char const* first, char const* last)
  {
    std::copy(first, last, std::back_inserter(cdata_));
  }

  fmp4_result on_end_element(char const*)
  {
    url_t url(cdata_);
    std::swap(val_, url);
    return FMP4_OK;
  }

private:
  url_t& val_;
  std::string cdata_;
};

struct MP4_DLL_LOCAL xml_element_uint32 : public xml_element_parser
{
  xml_element_uint32(uint32_t& val)
  : val_(val)
  {
    cdata_.reserve(8);
  }

  void on_character_data(char const* first, char const* last)
  {
    std::copy(first, last, std::back_inserter(cdata_));
  }

  fmp4_result on_end_element(char const*)
  {
    val_ = static_cast<uint32_t>(atoi64(cdata_.c_str()));
    return FMP4_OK;
  }

private:
  uint32_t& val_;
  std::string cdata_;
};

struct xml_element_base64 : public xml_element_parser
{
  xml_element_base64(std::vector<uint8_t>& val)
  : val_(val)
  {
    cdata_.reserve(64);
  }

  void on_character_data(char const* first, char const* last)
  {
    std::copy(first, last, std::back_inserter(cdata_));
  }

  fmp4_result on_end_element(char const*)
  {
    val_.reserve(cdata_.size() * 3 / 4);
    FMP4_CHECK(base64_decode(cdata_.data(), cdata_.data() + cdata_.size(),
                             std::back_inserter(val_)));

    return FMP4_OK;
  }

private:
  std::vector<uint8_t>& val_;
  std::string cdata_;
};

struct MP4_DLL_LOCAL xml_element_hex16_uuid : public xml_element_parser
{
  xml_element_hex16_uuid(uint128_t& val, bool little_endian)
  : val_(val)
  , little_endian_(little_endian)
  {
    cdata_.reserve(32 + 4 + 2);
  }

  void on_character_data(char const* first, char const* last)
  {
    std::copy(first, last, std::back_inserter(cdata_));
  }

  fmp4_result on_end_element(char const*)
  {
    char const* first = cdata_.empty() ? 0 : &cdata_[0];
    char const* last = first + cdata_.size();

    // skip leading/trailing whitespace (e.g. the KeyID in the EZDRM interface
    // has a trailing whitespace).
    first = skip_leading_whitespace(first, last);
    last = skip_trailing_whitespace(first, last);

    FMP4_CHECK(uuid_decode(first, last, val_));

    if(little_endian_)
    {
      val_ = uuid_swap_endianess(val_);
    }

    return FMP4_OK;
  }

private:
  uint128_t& val_;
  bool little_endian_;
  std::string cdata_;
};

#if 1
class xml_stack_t
{
public:
  explicit xml_stack_t(xml_element_parser* xml_root)
  : buf_(raw_ + ((-(raw_ - static_cast<uint8_t*>(0))) & (16 - 1)))
  , ptr_(buf_)
  {
    // push root pointer
    *reinterpret_cast<xml_element_parser**>(ptr_) = xml_root;
  }

  ~xml_stack_t()
  {
    while(ptr_ != buf_)
    {
      pop();
    }
    delete top();
  }

  template<typename T>
  T* push()
  {
    return (new(insert(static_cast<T*>(0))) T());
  }

  template<typename T, typename P1>
  T* push(P1& p1)
  {
    return (new(insert(static_cast<T*>(0))) T(p1));
  }

  template<typename T, typename P1, typename P2>
  T* push(P1& p1, P2& p2)
  {
    return (new(insert(static_cast<T*>(0))) T(p1, p2));
  }

  xml_element_parser* top()
  {
    return *reinterpret_cast<xml_element_parser**>(ptr_);
  }

  void pop()
  {
    // don't pop the root
    fmp4_assert(ptr_ != buf_);

    // destruct top element
    xml_element_parser* ptr = top();
    ptr->~xml_element_parser();

    // pop
    ptr_ = reinterpret_cast<uint8_t*>(ptr) - sizeof(xml_element_parser*);
  }

private:
  template<typename T>
  T* insert(T*)
  {
    ptr_ += sizeof(xml_element_parser*);

    // start of new object
    uint8_t* ptr = ptr_;

    // reserve memory for object
    ptr_ += (sizeof(T) + 16 - 1) & ~(16 - 1);

    // push stack pointer
    *reinterpret_cast<xml_element_parser**>(ptr_) = reinterpret_cast<T*>(ptr);

    return reinterpret_cast<T*>(ptr);
  }

private:
  uint8_t raw_[4096];
  uint8_t* buf_;
  uint8_t* ptr_;
};
#else
class xml_stack_t
{
public:
  explicit xml_stack_t(xml_element_parser* xml_root)
  {
    stack_.push(xml_root);
  }

  ~xml_stack_t()
  {
    while(!stack_.empty())
    {
      pop();
    }
  }

  template<typename T>
  T* push()
  {
    return insert(new T());
  }

  template<typename T, typename P1>
  T* push(P1& p1)
  {
    return insert(new T(p1));
  }

  template<typename T, typename P1, typename P2>
  T* push(P1& p1, P2& p2)
  {
    return insert(new T(p1, p2));
  }

  xml_element_parser* top()
  {
    return stack_.top();
  }

  void pop()
  {
    xml_element_parser* ptr = stack_.top();
    delete ptr;
    stack_.pop();
  }

private:
  template<typename T>
  T* insert(T* ptr)
  {
    stack_.push(ptr);

    return ptr;
  }

private:
  typedef std::stack< xml_element_parser* > stack_t;
  stack_t stack_;
};
#endif

template<typename T>
struct attribute_setter_t
{
  char const* name_;
  fmp4_result (*set_)(T& object, char const* value, std::size_t size);
};

template<typename T>
struct name_compare
{
  bool operator()(attribute_setter_t<T> const& lhs, char const* name) const
  {
    return strcmp(lhs.name_, name) < 0;
  }
#ifdef _DEBUG
  bool operator()(attribute_setter_t<T> const& lhs,
                  attribute_setter_t<T> const& rhs) const
  {
    return strcmp(lhs.name_, rhs.name_) < 0;
  }
  bool operator()(char const* name, attribute_setter_t<T> const& rhs) const
  {
    return strcmp(name, rhs.name_) < 0;
  }
#endif
};

template<typename T>
fmp4_result attribute_setter(T& object,
                             attribute_setter_t<T> const* first,
                             attribute_setter_t<T> const* last,
                             char const* name, char const* value)
{
  attribute_setter_t<T> const* iter =
    std::lower_bound(first, last, name, name_compare<T>());

  if(iter == last || strcmp(iter->name_, name))
  {
#if defined(_DEBUG)
    std::cout << "Skipped: " << name << std::endl;
#endif
    return FMP4_NOP;
  }
  else if(iter->set_)
  {
    FMP4_CHECK(iter->set_(object, value, std::strlen(value)));
  }

  return FMP4_OK;
}

template<typename T>
fmp4_result attribute_setter(T& object,
                             attribute_setter_t<T> const* first,
                             attribute_setter_t<T> const* last,
                             char const** atts)
{
  while(*atts != 0)
  {
    const char* name = *atts++;
    const char* value = *atts++;
    fmp4_result result = attribute_setter(object, first, last, name, value);
    if(result != FMP4_OK && result != FMP4_NOP)
    {
      return result;
    }
  }

  return FMP4_OK;
}

class MP4_DLL_EXPORT xml_parser_t
{
public:
  static char const sep = '|';

public:
  xml_parser_t(xml_element_parser* element_parser, bool use_ns = false);
  ~xml_parser_t();

  fmp4_result operator()(char const* first, char const* last, bool isFinal);
  fmp4_result operator()(buckets_t const* buckets, bool isFinal);

// private:
  void* parser_;
  xml_stack_t xml_stack_;

  // uri - prefix
  typedef std::map<std::string, std::string> namespaces_t;
  namespaces_t namespaces_;
};

} // namespace fmp4

#endif // MP4_XML_HPP_AKW

// End Of File


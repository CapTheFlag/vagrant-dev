/*******************************************************************************
 mp4_aes.hpp -

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_AES_HPP_AKW
#define MP4_AES_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_types.hpp"
#include <inttypes.h>
#include <cstddef>
#include <memory>

enum aes_type_t
{
  // no encryption
  AES_NONE,

  // AES 128-bit CTR
  AES_CTR,

  // AES 128-bit CBC
  AES_CBC
};

// Base for AES decoders. Note that you *must* support in-place (src == dst).
struct fmp4_aes_decoder
{
public:
  virtual ~fmp4_aes_decoder();
  virtual fmp4_result set_iv(uint8_t const iv[16]) = 0;
  virtual fmp4_result decode(uint8_t const* src, uint8_t* dst, std::size_t len) = 0;

#if defined(_WIN32)
  void* operator new(size_t size);
  void operator delete(void* ptr);
#endif
};

// Base for AES encoders. Note that you *must* support in-place (src == dst).
struct fmp4_aes_encoder
{
public:
  virtual ~fmp4_aes_encoder();
  virtual fmp4_result set_iv(uint8_t const iv[16]) = 0;
  virtual uint8_t const* get_iv() const = 0;
  virtual fmp4_result encode(uint8_t const* src, uint8_t* dst, std::size_t len) = 0;

#if defined(_WIN32)
  void* operator new(size_t size);
  void operator delete(void* ptr);
#endif
};

namespace fmp4 {

// Create an AES coder that provides decode functionality.
MP4_DLL_EXPORT extern
std::auto_ptr<fmp4_aes_decoder>
mp4_create_aes_decoder(aes_type_t type,
                       uint8_t const* key, unsigned int key_len);

MP4_DLL_EXPORT extern
std::auto_ptr<fmp4_aes_decoder>
mp4_create_aes_decoder(aes_type_t type, uint128_t const& key);

// Create an AES coder that provides encode functionality.
MP4_DLL_EXPORT extern
std::auto_ptr<fmp4_aes_encoder>
mp4_create_aes_encoder(aes_type_t type,
                       uint8_t const* key, unsigned int key_len);

MP4_DLL_EXPORT extern
std::auto_ptr<fmp4_aes_encoder>
mp4_create_aes_encoder(aes_type_t type, uint128_t const& key);

// Used for calculating the checksum in a wrm header
MP4_DLL_LOCAL extern
void mp4_aes_ecb_crypt(uint8_t const* src, uint8_t* dst, size_t len,
                       uint8_t const* key, unsigned int key_len);

// Only used for unit-testing
MP4_DLL_LOCAL extern
void mp4_aes_rfc3686_crypt(uint8_t const* src, uint8_t* dst, size_t len,
                           uint8_t const* key, unsigned int key_len,
                           uint8_t const nonce[4], uint8_t const iv[8]);

} // fmp4

////////////////////////////////////////////////////////////////////////////////

#endif // MP4_AES_HPP_AKW

// End Of File


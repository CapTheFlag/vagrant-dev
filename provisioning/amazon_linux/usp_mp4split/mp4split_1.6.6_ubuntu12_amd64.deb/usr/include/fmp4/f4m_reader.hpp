/*******************************************************************************
 f4m_reader.hpp - A library for reading F4M.

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef F4M_READER_HPP_AKW
#define F4M_READER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_util.hpp"
#include "mp4_uri.hpp"
#include <inttypes.h>
#include <string>
#include <vector>

struct buckets_t;
struct fmp4_handler_io_t;

namespace fmp4
{

struct indent_writer_t;

namespace f4m
{

class bootstrap_t
{
public:
  bootstrap_t();

  std::string comment_;
  std::string id_;
  url_t url_;
  std::vector<uint8_t> data_;
};

class drm_t
{
public:
  drm_t();

  std::string id_;
  url_t url_;
  std::vector<uint8_t> data_;
};

class media_t
{
public:
  media_t();

  url_t url_;
  uint32_t bitrate_;
  std::string bootstrap_id_;
  std::string drm_id_;
  std::vector<uint8_t> metadata_;

  uint32_t width_;
  uint32_t height_;

  std::string type_;
  bool alternate_;
  std::string label_;
  std::string lang_;
  url_t href_;
};

class MP4_DLL_EXPORT manifest_t
{
private:
  manifest_t(manifest_t const& rhs);
  manifest_t& operator=(manifest_t rhs);

public:
  manifest_t(url_t const& base_url);
  ~manifest_t();

  fmp4_result open(buckets_t const* buckets);
  fmp4_result open(char const* first, char const* last);
  fmp4_result open(fmp4_handler_io_t& src_io);

  bool resolve_url(url_t& url) const;

  fmp4_result find_media(unsigned int kbps, media_t const*& media) const;
  fmp4_result find_bootstrap(std::string const& id,
                             bootstrap_t const*& bootstrap) const;
  fmp4_result find_drm(std::string const& id, drm_t const*& drm) const;

public:
  url_t base_url_;

  unsigned int version_;
  std::string id_;
  int64_t duration_;
  std::string mime_type_;
  std::string stream_type_; // recorded, live
  int window_duration_;     // dvr window

  typedef std::vector<drm_t> drms_t;
  typedef std::vector<bootstrap_t> bootstraps_t;
  typedef std::vector<media_t> medias_t;

  drms_t drms_;
  bootstraps_t bootstraps_;
  medias_t medias_;
};

MP4_DLL_LOCAL extern
void output_manifest(indent_writer_t& os, manifest_t& manifest);

} // f4m

} // fmp4

#endif // F4M_READER_HPP_AKW

// End Of File


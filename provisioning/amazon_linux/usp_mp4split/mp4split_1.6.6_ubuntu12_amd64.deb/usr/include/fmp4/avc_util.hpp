/*******************************************************************************
 avc_util.hpp - AVC utility functions

 Copyright (C) 2011-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef AVC_UTIL_HPP_AKW
#define AVC_UTIL_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include <inttypes.h>
#include <vector>

namespace fmp4
{

struct bitstream_writer_t;
struct smil_switch_t;

MP4_DLL_EXPORT extern
uint8_t* remove_emulation_prevention(uint8_t* dst,
                                     uint8_t const* first, uint8_t const* last,
                                     unsigned int& prefix);

MP4_DLL_EXPORT extern
uint8_t* apply_emulation_prevention(uint8_t* dst,
                                    uint8_t const* first, uint8_t const* last,
                                    unsigned int& prefix);

struct remove_emulation_prevention_t
{
  remove_emulation_prevention_t(uint8_t const* first, uint8_t const* last)
  : first_(first)
  , last_(last)
  , prefix_(0)
  {
  }

  uint8_t peek() const
  {
    return *first_;
  }

  uint8_t read_8()
  {
    uint8_t val = *first_;

    ++first_;

    if(val == 0x00)
    {
      ++prefix_;

      if(prefix_ == 2 && first_ != last_ && *first_ == 0x03)
      {
        // skip emulation_prevention_three_byte
        ++first_;
        prefix_ = 0;
      }
    }
    else
    {
      prefix_ = 0;
    }

    return val;
  }

  uint16_t read_16()
  {
    uint32_t v  = (read_8() << 8);
             v |= (read_8() << 0);

    return v;
  }

  uint32_t read_24()
  {
    uint32_t v  = (read_8() << 16);
             v |= (read_8() << 8);
             v |= (read_8() << 0);

    return v;
  }

  uint32_t read_32()
  {
    uint32_t v  = (read_8() << 24);
             v |= (read_8() << 16);
             v |= (read_8() << 8);
             v |= (read_8() << 0);

    return v;
  }

  bool eof() const
  {
    return first_ == last_;
  }

  std::size_t left() const
  {
    return std::distance(first_, last_);
  }

private:
  uint8_t const* first_;
  uint8_t const* last_;
  uint32_t prefix_;
};

enum nal_type_t
{
  NAL_UNSPECIFIED = 0,
  NAL_NON_IDR = 1,
  NAL_PARTITION_A = 2,
  NAL_PARTITION_B = 3,
  NAL_PARTITION_C = 4,
  NAL_IDR = 5,
  NAL_SEI = 6,
  NAL_SPS = 7,
  NAL_PPS = 8,
  NAL_AUD = 9,
  NAL_END_OF_SEQUENCE = 10,
  NAL_END_OF_STREAM = 11,
  NAL_FILLER = 12
};

enum slice_type_t
{
  SLICE_P = 0,
  SLICE_B = 1,
  SLICE_I = 2,
  SLICE_SP = 3,
  SLICE_SI = 4,
  SLICE_P_ALL = 5,
  SLICE_B_ALL = 6,
  SLICE_I_ALL = 7,
  SLICE_SP_ALL = 8,
  SLICE_SI_ALL = 9
};

struct sequence_parameter_set_t;
struct picture_parameter_set_t;

#if 0

struct ref_pic_list_reordering_t
{
  uint32_t reordering_of_pic_nums_idc_;
  union
  {
    // reordering_of_pic_nums_idc_ == 0 || reordering_of_pic_nums_idc_ == 1
    uint32_t abs_diff_pic_num_minus1_;
    // reordering_of_pic_nums_idc_ == 2
    uint32_t long_term_pic_num_;
  };
};
typedef std::vector<ref_pic_list_reordering_t> ref_pic_list_reorderings_t;

struct luma_weight_offset_t
{
  bool flag_;
  int32_t weight_;
  int32_t offset_;
};
typedef std::vector<luma_weight_offset_t> luma_weight_offsets_t;

struct chroma_weight_offset_t
{
  bool flag_;
  int32_t weight_[2];
  int32_t offset_[2];
};
typedef std::vector<chroma_weight_offset_t> chroma_weight_offsets_t;

struct pred_weight_table_t
{
  uint32_t luma_log2_weight_denom_;
  uint32_t chroma_log2_weight_denom_;

  luma_weight_offsets_t luma_weight_offset_l0_;
  chroma_weight_offsets_t chroma_weight_offset_l0_;
  luma_weight_offsets_t luma_weight_offset_l1_;
  chroma_weight_offsets_t chroma_weight_offset_l1_;
};

struct operation_t
{
  uint32_t operation_;
  uint32_t value1_;
  uint32_t value2_;
};
typedef std::vector<operation_t> operations_t;

struct dec_ref_pic_marking_t
{
  // IDR
  bool no_output_of_prior_pics_flag_;
  bool long_term_reference_flag_;

  // NON_IDR
  bool adaptive_ref_pic_marking_mode_flag_;
  operations_t operations_;
};

struct slice_header_t
{
  slice_header_t();

  // the address of the first macroblock in the slice.
  uint32_t first_mb_in_slice_;

  // the coding type of the slice (table 7.6)
  uint32_t slice_type_;

  // the PPS set in use
  uint8_t pic_parameter_set_id_;

  //
  uint32_t colour_plane_id_;

  //
  uint32_t frame_num_;

  bool field_pic_flag_;
  bool bottom_field_flag_;
  uint32_t idr_pic_id_;

  // pic_order_cnt_type == 0
  uint32_t pic_order_cnt_lsb_;
  int32_t delta_pic_order_cnt_bottom_;

  // pic_order_cnt_type == 1 && !delta_pic_order_always_zero_flag
  int32_t delta_pic_order_cnt_[2];

  uint32_t redundant_pic_cnt_;
  bool direct_spatial_mv_pred_flag_;
  bool num_ref_idx_active_override_flag_;
  uint32_t num_ref_idx_l0_active_minus1_;
  uint32_t num_ref_idx_l1_active_minus1_;

  ref_pic_list_reorderings_t ref_pic_list0_;
  ref_pic_list_reorderings_t ref_pic_list1_;

  pred_weight_table_t pred_weight_table_;

  dec_ref_pic_marking_t dec_ref_pic_marking_;

  uint32_t cabac_init_idc_;
  int32_t slice_qp_delta_;

  bool sp_for_switch_flag_;
  int32_t slice_qs_delta_;

  uint32_t disable_deblocking_filter_idc_;
  int32_t slice_alpha_c0_offset_div2_;
  int32_t slice_beta_offset_div2_;

  uint32_t slice_group_change_cycle_;
};

MP4_DLL_EXPORT extern
fmp4_result write(bitstream_writer_t& os, slice_header_t const& slice_header,
                  sequence_parameter_set_t const& sps,
                  picture_parameter_set_t const& pps);

#endif

struct hrd_parameters_t
{
  hrd_parameters_t();

  uint8_t cpb_cnt_minus1_;
  uint8_t bit_rate_scale_;
  uint8_t cpb_size_scale_;
  uint32_t bit_rate_value_minus1_[32];
  uint32_t cpb_size_value_minus1_[32];
  bool cbr_flag_[32];
  uint8_t initial_cpb_removal_delay_length_minus1_;
  uint8_t cpb_removal_delay_length_minus1_;
  uint8_t dpb_output_delay_length_minus1_;
  uint8_t time_offset_length_;
};

struct vui_parameters_t
{
  static uint8_t const Extended_SAR;

  vui_parameters_t();

  bool aspect_ratio_info_present_flag_;
  uint8_t aspect_ratio_idc_;
  uint16_t sar_width_;
  uint16_t sar_height_;
  bool overscan_info_present_flag_;
  bool overscan_appropriate_flag_;
  bool video_signal_type_present_flag_;
  uint8_t video_format_;
  bool video_full_range_flag_;
  bool colour_description_present_flag_;
  uint8_t colour_primaries_;
  uint8_t transfer_characteristics_;
  uint8_t matrix_coefficients_;
  bool chroma_loc_info_present_flag_;
  uint32_t chroma_sample_loc_type_top_field_;
  uint32_t chroma_sample_loc_type_bottom_field_;
  bool timing_info_present_flag_;
  uint32_t num_units_in_tick_;
  uint32_t time_scale_;
  bool fixed_frame_rate_flag_;

  bool nal_hrd_parameters_present_flag_;
  hrd_parameters_t nal_hrd_parameters_;
  bool vcl_hrd_parameters_present_flag_;
  hrd_parameters_t vcl_hrd_parameters_;
  bool low_delay_hrd_flag_;
  bool pic_struct_present_flag_;
  bool bitstream_restriction_flag_;
  bool motion_vectors_over_pic_boundaries_flag_;
  uint32_t max_bytes_per_pic_denom_;
  uint32_t max_bits_per_mb_denom_;
  uint32_t log2_max_mv_length_horizontal_;
  uint32_t log2_max_mv_length_vertical_;
  uint32_t num_reorder_frames_;
  uint32_t max_dec_frame_buffering_;
};

struct sequence_parameter_set_t
{
  sequence_parameter_set_t();

  uint8_t profile_idc_;
  bool constraint_set0_flag_;
  bool constraint_set1_flag_;
  bool constraint_set2_flag_;
  bool constraint_set3_flag_;
  uint8_t level_idc_;
  uint8_t seq_parameter_set_id_;
  uint8_t chroma_format_idc_;
  bool separate_colour_plane_flag_;
  unsigned int bit_depth_luma_minus8_;
  unsigned int bit_depth_chroma_minus8_;
  bool qpprime_y_zero_transform_bypass_flag_;
  bool seq_scaling_matrix_present_flag_;
  uint8_t log2_max_frame_num_minus4_;
  uint8_t pic_order_cnt_type_;
  uint8_t log2_max_pic_order_cnt_lsb_minus4_;
  bool delta_pic_order_always_zero_flag_;
  int32_t offset_for_non_ref_pic_;
  int32_t offset_for_top_to_bottom_field_;
  uint8_t num_ref_frames_in_pic_order_cnt_cycle_;
  int32_t offset_for_ref_frame_[256];
  uint32_t num_ref_frames_;
  bool gaps_in_frame_num_value_allowed_flag_;
  uint32_t pic_width_in_mbs_minus1_;
  uint32_t pic_height_in_map_units_minus1_;
  unsigned int frame_mbs_only_flag_;
  bool mb_adaptive_frame_field_flag_;
  bool direct_8x8_inference_flag_;
  bool frame_cropping_flag_;
  uint32_t frame_crop_left_offset_;
  uint32_t frame_crop_right_offset_;
  uint32_t frame_crop_top_offset_;
  uint32_t frame_crop_bottom_offset_;
  bool vui_parameters_present_flag_;
  vui_parameters_t vui_parameters_;
};

// parse the (emulation prevented) Sequence Parameter Set
MP4_DLL_LOCAL extern fmp4_result
read(sequence_parameter_set_t& sps, uint8_t const* first, uint8_t const* last);

MP4_DLL_EXPORT extern
fmp4_result write(bitstream_writer_t& os, sequence_parameter_set_t const& sps);

MP4_DLL_EXPORT extern
std::vector<uint8_t> get_sps_nal_unit(sequence_parameter_set_t const& sps);

MP4_DLL_EXPORT extern
std::ostream& operator<<(std::ostream& os, sequence_parameter_set_t const& rhs);

MP4_DLL_LOCAL extern
void update_smil_switch(smil_switch_t& smil_switch, sequence_parameter_set_t const& sps);

struct picture_parameter_set_t
{
  picture_parameter_set_t();

  uint8_t pic_parameter_set_id_;
  uint8_t seq_parameter_set_id_;
  bool entropy_coding_mode_flag_;
  bool pic_order_present_flag_;
  uint32_t num_slice_groups_minus1_;
  uint8_t slice_group_map_type_;
  uint32_t run_length_minus1_[8];
  uint32_t top_left_[8];
  uint32_t bottom_right_[8];
  bool slice_group_change_direction_flag_;
  uint32_t slice_group_change_rate_minus1_;
  uint32_t pic_size_in_map_units_minus1_;
  uint32_t slice_group_id_[8];
  uint32_t num_ref_idx_l0_active_minus1_;
  uint32_t num_ref_idx_l1_active_minus1_;
  bool weighted_pred_flag_;
  uint8_t weighted_bipred_idc_;
  int32_t pic_init_qp_minus26_;
  int32_t pic_init_qs_minus26_;
  int32_t chroma_qp_index_offset_;
  bool deblocking_filter_control_present_flag_;
  bool constrained_intra_pred_flag_;
  bool redundant_pic_cnt_present_flag_;

  bool extended_flag_;
  bool transform_8x8_mode_flag_;
  bool pic_scaling_matrix_present_flag_;
  bool pic_scaling_list_present_flag_[12];
  int32_t second_chroma_qp_index_offset_;
};

// parse the (emulation prevented) Picture Parameter Set
MP4_DLL_LOCAL extern
fmp4_result read(picture_parameter_set_t& pps,
                 uint8_t const* first, uint8_t const* last);

MP4_DLL_LOCAL extern
fmp4_result write(bitstream_writer_t& os, picture_parameter_set_t const& pps);

MP4_DLL_EXPORT extern
std::vector<uint8_t> get_pps_nal_unit(picture_parameter_set_t const& pps);

MP4_DLL_EXPORT extern
std::ostream& operator<<(std::ostream& os, picture_parameter_set_t const& rhs);

MP4_DLL_LOCAL extern
fmp4_result avc_has_captions(smil_switch_t& smil_switch,
                             uint8_t const* first, uint8_t const* last);

MP4_DLL_LOCAL extern
fmp4_result avc_get_framerate(smil_switch_t const& smil_switch,
                              uint32_t& ticks, uint32_t& scale);

} // namespace fmp4

#endif // AVC_UTIL_HPP_AKW

// End Of File


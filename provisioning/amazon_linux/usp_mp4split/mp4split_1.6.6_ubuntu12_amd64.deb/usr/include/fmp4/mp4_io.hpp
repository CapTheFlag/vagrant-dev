/*******************************************************************************
 mp4_io.hpp - A library for general MPEG4 I/O.

 Copyright (C) 2007-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef MP4_IO_HPP_AKW
#define MP4_IO_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_counted_ptr.hpp"
#include "mp4_uri.hpp"
#include "mp4_types.hpp"
#include <inttypes.h>
#include <string>
#include <vector>
#include <memory>
#include <list>
#include <map>

struct fmp4_handler_io_t;

namespace fmp4
{

class io_buf;
typedef counted_ptr<io_buf> io_buf_ptr;

struct mp4_writer_t;
class memory_writer;
struct sample_entry_t;
struct tenc_t;

#if defined(__MINGW32__) && __MSVCRT_VERSION__ < 0x800
#define ftello ftello64
#define fseeko fseeko64
#elif defined(_WIN32)
#define ftello _ftelli64
#define fseeko _fseeki64
#endif

MP4_DLL_EXPORT extern char const* fragment_type_audio;
MP4_DLL_EXPORT extern char const* fragment_type_video;
MP4_DLL_EXPORT extern char const* fragment_type_text;
MP4_DLL_EXPORT extern char const* fragment_type_data;
MP4_DLL_EXPORT extern char const* fragment_type_img;
MP4_DLL_EXPORT extern char const* fragment_type_hint;

MP4_DLL_EXPORT extern char const* mime_type_flv;
MP4_DLL_LOCAL extern char const* mime_type_ismc;
MP4_DLL_LOCAL extern char const* mime_type_csm;
MP4_DLL_LOCAL extern char const* mime_type_m3u8;
MP4_DLL_EXPORT extern char const* mime_type_mp4;
MP4_DLL_EXPORT extern char const* mime_type_ts;
MP4_DLL_LOCAL extern char const* mime_type_f4m;
MP4_DLL_LOCAL extern char const* mime_type_mpd;
MP4_DLL_LOCAL extern char const* mime_type_f4f;
MP4_DLL_LOCAL extern char const* mime_type_drmmeta;
MP4_DLL_LOCAL extern char const* mime_type_webvtt;
MP4_DLL_LOCAL extern char const* mime_type_jpg;

MP4_DLL_LOCAL extern const unsigned char mp4_uuid_refs_box[16];
MP4_DLL_EXPORT extern const unsigned char mp4_uuid_stream_box[16];
MP4_DLL_LOCAL extern const unsigned char mp4_uuid_tfxd[16];
MP4_DLL_EXPORT extern const unsigned char mp4_uuid_tfrf[16];

MP4_DLL_LOCAL extern const uint32_t mp4_aac_samplerates[16];

#define ATOM_PREAMBLE_SIZE 8

#define FOURCC(a, b, c, d) ((uint32_t)(a) << 24) + \
                           ((uint32_t)(b) << 16) + \
                           ((uint32_t)(c) << 8) + \
                           ((uint32_t)(d))

#define FOURCC_aacd FOURCC('a', 'a', 'c', 'd')
#define FOURCC_abst FOURCC('a', 'b', 's', 't')
#define FOURCC_ac_3 FOURCC('a', 'c', '-', '3')
#define FOURCC_ac3d FOURCC('a', 'c', '3', 'd')
#define FOURCC_adaf FOURCC('a', 'd', 'a', 'f')
#define FOURCC_adkm FOURCC('a', 'd', 'k', 'm')
#define FOURCC_aeib FOURCC('a', 'e', 'i', 'b')
#define FOURCC_afra FOURCC('a', 'f', 'r', 'a')
#define FOURCC_afrt FOURCC('a', 'f', 'r', 't')
#define FOURCC_ahdr FOURCC('a', 'h', 'd', 'r')
#define FOURCC_ainf FOURCC('a', 'i', 'n', 'f')
#define FOURCC_akey FOURCC('a', 'k', 'e', 'y')
#define FOURCC_amf0 FOURCC('a', 'm', 'f', '0')
#define FOURCC_amhp FOURCC('a', 'm', 'h', 'p')
#define FOURCC_apad FOURCC('a', 'p', 'a', 'd')
#define FOURCC_aprm FOURCC('a', 'p', 'r', 'm')
#define FOURCC_asrt FOURCC('a', 's', 'r', 't')
#define FOURCC_avc1 FOURCC('a', 'v', 'c', '1')
#define FOURCC_avc3 FOURCC('a', 'v', 'c', '3')
#define FOURCC_avcC FOURCC('a', 'v', 'c', 'C')
#define FOURCC_bloc FOURCC('b', 'l', 'o', 'c')
#define FOURCC_btrt FOURCC('b', 't', 'r', 't')
#define FOURCC_c608 FOURCC('c', '6', '0', '8')
#define FOURCC_ccff FOURCC('c', 'c', 'f', 'f')
#define FOURCC_cenc FOURCC('c', 'e', 'n', 'c')
#define FOURCC_cmov FOURCC('c', 'm', 'o', 'v')
#define FOURCC_cmvd FOURCC('c', 'm', 'v', 'd')
#define FOURCC_co64 FOURCC('c', 'o', '6', '4')
#define FOURCC_ctts FOURCC('c', 't', 't', 's')
#define FOURCC_dac3 FOURCC('d', 'a', 'c', '3')
#define FOURCC_dash FOURCC('d', 'a', 's', 'h')
#define FOURCC_data FOURCC('d', 'a', 't', 'a')
#define FOURCC_dcom FOURCC('d', 'c', 'o', 'm')
#define FOURCC_ddts FOURCC('d', 'd', 't', 's')
#define FOURCC_dec3 FOURCC('d', 'e', 'c', '3')
#define FOURCC_dfxp FOURCC('d', 'f', 'x', 'p')
#define FOURCC_dinf FOURCC('d', 'i', 'n', 'f')
#define FOURCC_dref FOURCC('d', 'r', 'e', 'f')
#define FOURCC_dtsc FOURCC('d', 't', 's', 'c')
#define FOURCC_dtse FOURCC('d', 't', 's', 'e')
#define FOURCC_dtsh FOURCC('d', 't', 's', 'h')
#define FOURCC_dtsl FOURCC('d', 't', 's', 'l')
#define FOURCC_dts_plus FOURCC('d', 't', 's', '+')
#define FOURCC_dts_min FOURCC('d', 't', 's', '-')
#define FOURCC_dvc1 FOURCC('d', 'v', 'c', '1')
#define FOURCC_ec_3 FOURCC('e', 'c', '-', '3')
#define FOURCC_edts FOURCC('e', 'd', 't', 's')
#define FOURCC_elst FOURCC('e', 'l', 's', 't')
#define FOURCC_enca FOURCC('e', 'n', 'c', 'a')
#define FOURCC_enct FOURCC('e', 'n', 'c', 't')
#define FOURCC_encv FOURCC('e', 'n', 'c', 'v')
#define FOURCC_esds FOURCC('e', 's', 'd', 's')
#define FOURCC_f4v  FOURCC('f', '4', 'v', ' ')
#define FOURCC_flxs FOURCC('f', 'l', 'x', 's')
#define FOURCC_free FOURCC('f', 'r', 'e', 'e')
#define FOURCC_frma FOURCC('f', 'r', 'm', 'a')
#define FOURCC_ftyp FOURCC('f', 't', 'y', 'p')
#define FOURCC_hdlr FOURCC('h', 'd', 'l', 'r')
#define FOURCC_hev1 FOURCC('h', 'e', 'v', '1')
#define FOURCC_hint FOURCC('h', 'i', 'n', 't')
#define FOURCC_hmhd FOURCC('h', 'm', 'h', 'd')
#define FOURCC_hvc1 FOURCC('h', 'v', 'c', '1')
#define FOURCC_hvcC FOURCC('h', 'v', 'c', 'C')
#define FOURCC_isml FOURCC('i', 's', 'm', 'l')
#define FOURCC_iso2 FOURCC('i', 's', 'o', '2')
#define FOURCC_iso6 FOURCC('i', 's', 'o', '6')
#define FOURCC_isom FOURCC('i', 's', 'o', 'm')
#define FOURCC_lmsg FOURCC('l', 'm', 's', 'g')
#define FOURCC_lyra FOURCC('l', 'y', 'r', 'a')
#define FOURCC_m4v  FOURCC('m', '4', 'v', ' ')
#define FOURCC_mdat FOURCC('m', 'd', 'a', 't')
#define FOURCC_mdhd FOURCC('m', 'd', 'h', 'd')
#define FOURCC_mdia FOURCC('m', 'd', 'i', 'a')
#define FOURCC_mehd FOURCC('m', 'e', 'h', 'd')
#define FOURCC_mfhd FOURCC('m', 'f', 'h', 'd')
#define FOURCC_mfra FOURCC('m', 'f', 'r', 'a')
#define FOURCC_mfro FOURCC('m', 'f', 'r', 'o')
#define FOURCC_mhlr FOURCC('m', 'h', 'l', 'r')
#define FOURCC_minf FOURCC('m', 'i', 'n', 'f')
#define FOURCC_mlpa FOURCC('m', 'l', 'p', 'a')
#define FOURCC_moof FOURCC('m', 'o', 'o', 'f')
#define FOURCC_moov FOURCC('m', 'o', 'o', 'v')
#define FOURCC_mp42 FOURCC('m', 'p', '4', '2')
#define FOURCC_mp4a FOURCC('m', 'p', '4', 'a')
#define FOURCC_msdh FOURCC('m', 's', 'd', 'h')
#define FOURCC_mvex FOURCC('m', 'v', 'e', 'x')
#define FOURCC_mvhd FOURCC('m', 'v', 'h', 'd')
#define FOURCC_nmhd FOURCC('n', 'm', 'h', 'd')
#define FOURCC_ovc1 FOURCC('o', 'v', 'c', '1')
#define FOURCC_owma FOURCC('o', 'w', 'm', 'a')
#define FOURCC_piff FOURCC('p', 'i', 'f', 'f')
#define FOURCC_pssh FOURCC('p', 's', 's', 'h')
#define FOURCC_rtmp FOURCC('r', 't', 'm', 'p')
#define FOURCC_saio FOURCC('s', 'a', 'i', 'o')
#define FOURCC_saiz FOURCC('s', 'a', 'i', 'z')
#define FOURCC_sbgp FOURCC('s', 'b', 'g', 'p')
#define FOURCC_sbtl FOURCC('s', 'b', 't', 'l')
#define FOURCC_schi FOURCC('s', 'c', 'h', 'i')
#define FOURCC_schm FOURCC('s', 'c', 'h', 'm')
#define FOURCC_sdtp FOURCC('s', 'd', 't', 'p')
#define FOURCC_seig FOURCC('s', 'e', 'i', 'g')
#define FOURCC_senc FOURCC('s', 'e', 'n', 'c')
#define FOURCC_serg FOURCC('s', 'e', 'r', 'g')
#define FOURCC_sgpd FOURCC('s', 'g', 'p', 'd')
#define FOURCC_sidx FOURCC('s', 'i', 'd', 'x')
#define FOURCC_sinf FOURCC('s', 'i', 'n', 'f')
#define FOURCC_smhd FOURCC('s', 'm', 'h', 'd')
#define FOURCC_soun FOURCC('s', 'o', 'u', 'n')
#define FOURCC_stbl FOURCC('s', 't', 'b', 'l')
#define FOURCC_stco FOURCC('s', 't', 'c', 'o')
#define FOURCC_stpp FOURCC('s', 't', 'p', 'p')
#define FOURCC_stsc FOURCC('s', 't', 's', 'c')
#define FOURCC_stsd FOURCC('s', 't', 's', 'd')
#define FOURCC_stss FOURCC('s', 't', 's', 's')
#define FOURCC_stsz FOURCC('s', 't', 's', 'z')
#define FOURCC_stts FOURCC('s', 't', 't', 's')
#define FOURCC_styp FOURCC('s', 't', 'y', 'p')
#define FOURCC_subt FOURCC('s', 'u', 'b', 't')
#define FOURCC_tenc FOURCC('t', 'e', 'n', 'c')
#define FOURCC_text FOURCC('t', 'e', 'x', 't')
#define FOURCC_tfad FOURCC('t', 'f', 'a', 'd')
#define FOURCC_tfdt FOURCC('t', 'f', 'd', 't')
#define FOURCC_tfhd FOURCC('t', 'f', 'h', 'd')
#define FOURCC_tfra FOURCC('t', 'f', 'r', 'a')
#define FOURCC_tfxd FOURCC('t', 'f', 'x', 'd')
#define FOURCC_tkhd FOURCC('t', 'k', 'h', 'd')
#define FOURCC_traf FOURCC('t', 'r', 'a', 'f')
#define FOURCC_trak FOURCC('t', 'r', 'a', 'k')
#define FOURCC_tref FOURCC('t', 'r', 'e', 'f')
#define FOURCC_trex FOURCC('t', 'r', 'e', 'x')
#define FOURCC_trun FOURCC('t', 'r', 'u', 'n')
#define FOURCC_tx3g FOURCC('t', 'x', '3', 'g')
#define FOURCC_url  FOURCC('u', 'r', 'l', ' ')
#define FOURCC_urn  FOURCC('u', 'r', 'n', ' ')
#define FOURCC_uuid FOURCC('u', 'u', 'i', 'd')
#define FOURCC_vc_1 FOURCC('v', 'c', '-', '1')
#define FOURCC_vide FOURCC('v', 'i', 'd', 'e')
#define FOURCC_vmhd FOURCC('v', 'm', 'h', 'd')
#define FOURCC_wave FOURCC('w', 'a', 'v', 'e')
#define FOURCC_wfex FOURCC('w', 'f', 'e', 'x')
#define FOURCC_wma  FOURCC('w', 'm', 'a', ' ')
#define FOURCC_zaac FOURCC('z', 'a', 'a', 'c')
#define FOURCC_zac3 FOURCC('z', 'a', 'c', '3')
#define FOURCC_zach FOURCC('z', 'a', 'c', 'h')
#define FOURCC_zacp FOURCC('z', 'a', 'c', 'p')
#define FOURCC_zavc FOURCC('z', 'a', 'v', 'c')
#define FOURCC_zlib FOURCC('z', 'l', 'i', 'b')

#define FOURCC_AAC  FOURCC('A', 'A', 'C', ' ')
#define FOURCC_AACH FOURCC('A', 'A', 'C', 'H')
#define FOURCC_AACL FOURCC('A', 'A', 'C', 'L')
#define FOURCC_AACP FOURCC('A', 'A', 'C', 'P')
#define FOURCC_AC_3 FOURCC('A', 'C', '-', '3')
#define FOURCC_APIC FOURCC('A', 'P', 'I', 'C')
#define FOURCC_AVC1 FOURCC('A', 'V', 'C', '1')
#define FOURCC_AVCB FOURCC('A', 'V', 'C', 'B')
#define FOURCC_COMM FOURCC('C', 'O', 'M', 'M')
#define FOURCC_DFXP FOURCC('D', 'F', 'X', 'P')
#define FOURCC_DTS1 FOURCC('D', 'T', 'S', '1')
#define FOURCC_DTS2 FOURCC('D', 'T', 'S', '2')
#define FOURCC_DTS3 FOURCC('D', 'T', 'S', '3')
#define FOURCC_DTSH FOURCC('D', 'T', 'S', 'H')
#define FOURCC_DAVC FOURCC('D', 'A', 'V', 'C')
#define FOURCC_EC_3 FOURCC('E', 'C', '-', '3')
#define FOURCC_GA94 FOURCC('G', 'A', '9', '4')
#define FOURCC_H264 FOURCC('H', '2', '6', '4')
#define FOURCC_ID3  FOURCC('I', 'D', '3', ' ')
#define FOURCC_PNG  FOURCC('P', 'N', 'G', ' ')
#define FOURCC_PRIV FOURCC('P', 'R', 'I', 'V')
#define FOURCC_JPEG FOURCC('J', 'P', 'E', 'G')
#define FOURCC_TTML FOURCC('T', 'T', 'M', 'L')
#define FOURCC_WMA2 FOURCC('W', 'M', 'A', '2')
#define FOURCC_WMAP FOURCC('W', 'M', 'A', 'P')
#define FOURCC_WVC1 FOURCC('W', 'V', 'C', '1')
#define FOURCC_X264 FOURCC('X', '2', '6', '4')

struct MP4_DLL_LOCAL mp4_atom_t
{
  uint32_t type_;
  uint64_t size_;
  uint64_t start_;
  uint64_t end_;
};

MP4_DLL_EXPORT extern
fmp4_result mp4_read_preamble(fmp4_handler_io_t& src_io,
                              uint64_t filepos,
                              uint64_t* size, uint32_t* type,
                              uint32_t* preamble,
                              char const* log);

MP4_DLL_EXPORT extern
fmp4_result mp4_read_preamble(uint8_t const* first, uint64_t bytes_left,
                              uint64_t* size, uint32_t* type,
                              uint32_t* preamble,
                              char const* log);

MP4_DLL_EXPORT extern
fmp4_result mp4_read_preamble(uint8_t const* first,
                              uint64_t bytes_left,
                              uint32_t* size, uint32_t* type,
                              uint32_t* preamble,
                              char const* log);

MP4_DLL_EXPORT extern
fmp4_result mp4_atom_read_header(fmp4_handler_io_t& src_io, uint64_t filepos,
                                 mp4_atom_t* atom, uint32_t& preamble_size);

MP4_DLL_LOCAL extern
int mp4_atom_write_header(uint8_t* outbuffer, mp4_atom_t const* atom);

struct unknown_atom_t
{
  unknown_atom_t();
  unknown_atom_t(uint8_t const* data, uint32_t size);

  std::vector<uint8_t> data_;
};
typedef std::list<unknown_atom_t> unknown_atoms_t;

MP4_DLL_LOCAL extern
fmp4_result unknown_atom_read(unknown_atoms_t& unknown_atoms,
                              uint8_t const* data, uint32_t size);

struct trak_t;

struct mvhd_t
{
  mvhd_t(uint64_t creation_time);

  unsigned int version_;
  unsigned int flags_;
  uint64_t creation_time_;      // seconds since midnite, Jan .1 1904 (UTC)
  uint64_t modification_time_;  // seconds since midnite, Jan .1 1904 (UTC)
  uint32_t timescale_;          // time units that pass in one second
  uint64_t duration_;           // duration of the longest track
  uint32_t rate_;               // preferred playback rate (16.16)
  uint16_t volume_;             // preferred playback volume (8.8)
  uint16_t reserved1_;
  uint32_t reserved2_[2];
  uint32_t matrix_[9];
  uint32_t predefined_[6];
  uint32_t next_track_id_;
};

struct ainf_t
{
  ainf_t();

  uint32_t profile_version_;
  std::string apid_;
};

#if 0
struct kid_t
{
  kid_t()
  {
    std::fill(val_, val_ + 16, 0);
  }

  explicit kid_t(std::vector<uint8_t> const& kid)
  {
    fmp4_assert(kid.size() == 16);
    std::copy(kid.begin(), kid.end(), val_);
  }

  explicit kid_t(uint8_t const kid[16])
  {
    std::copy(kid, kid + 16, val_);
  }

  uint8_t& operator[](std::size_t pos)
  {
    return val_[pos];
  }

  uint8_t const& operator[](std::size_t pos) const
  {
    return val_[pos];
  }

  uint8_t val_[16];
};
#endif

struct MP4_DLL_EXPORT pssh_t
{
  pssh_t()
  {
  }

  pssh_t(uint128_t system_id, std::vector<uint8_t> const& data);
  ~pssh_t();

  uint128_t system_id_;
  typedef std::vector<uint128_t> kids_t;
  kids_t kids_;
  std::vector<uint8_t> data_;
};

typedef std::vector<pssh_t> psshs_t;

struct MP4_DLL_EXPORT is_system_id : public std::unary_function<pssh_t, bool>
{
  is_system_id(uint128_t system_id)
  : system_id_(system_id)
  {
  }

  is_system_id(uint8_t const system_id[16])
  : system_id_(read_128(system_id))
  {
  }

  bool operator()(pssh_t const& pssh) const
  {
    return pssh.system_id_ == system_id_;
  }

private:
  uint128_t system_id_;
};

MP4_DLL_EXPORT psshs_t::iterator insert_or_update(psshs_t& psshs, pssh_t pssh);

MP4_DLL_LOCAL int compare(pssh_t const& lhs, pssh_t const& rhs);

inline bool operator==(pssh_t const& lhs, pssh_t const& rhs)
{
  return compare(lhs, rhs) == 0;
}
inline bool operator!=(pssh_t const& lhs, pssh_t const& rhs)
{
  return !(lhs == rhs);
}
inline bool operator<(pssh_t const& lhs, pssh_t const& rhs)
{
  return compare(lhs, rhs) < 0;
}

struct bloc_t
{
  std::string base_location_;
  std::string purchase_location_;
};

struct MP4_DLL_EXPORT moov_t
{
private:
  moov_t(moov_t const& rhs);
  moov_t& operator=(moov_t const& rhs);

public:
  moov_t(uint64_t creation_time = 0);
  ~moov_t();

  trak_t* find(uint32_t track_id);
  trak_t const* find(uint32_t track_id) const;

  unknown_atoms_t unknown_atoms_;

  // Movie Header
  mvhd_t mvhd_;

  // Asset Information
  ainf_t ainf_;

  // Protection System Specific 
  psshs_t psshs_;

  void add_track(trak_t* trak);

  typedef std::pair<uint32_t, trak_t*> track_id_to_trak;
  typedef std::map<uint32_t, trak_t*> traks_t;
  traks_t traks_;

  // Movie Extends
  struct mvex_t* mvex_;

//  int is_indexed_;
};

MP4_DLL_EXPORT extern trak_t* moov_add_track(moov_t& moov);
MP4_DLL_EXPORT extern
fmp4_result trak_get_sample_entry(trak_t const& trak,
                                  unsigned int sample_description_index,
                                  sample_entry_t*& sample_entry);
MP4_DLL_LOCAL extern
fmp4_result trak_get_tenc(trak_t const& trak,
                          unsigned int sample_description_index,
                          tenc_t const*& tenc);
MP4_DLL_EXPORT extern
fmp4_result moov_get_tenc(moov_t const& moov, unsigned int track_id,
                          unsigned int sample_description_index,
                          tenc_t const*& tenc);
#if 0
MP4_DLL_LOCAL extern
fmp4_result get_sync_track(moov_t const& moov, trak_t const*& sync_trak);
#endif

struct tkhd_t
{
  tkhd_t();

  unsigned int version_;
  unsigned int flags_;
  uint64_t creation_time_;      // seconds since midnite, Jan .1 1904 (UTC)
  uint64_t modification_time_;  // seconds since midnite, Jan .1 1904 (UTC)
  uint32_t track_id_;
  uint32_t reserved_;
  uint64_t duration_;           // duration of this track (mvhd.timescale)
  uint32_t reserved2_[2];
  uint16_t layer_;              // front-to-back ordering
  uint16_t alternate_group_;
  uint16_t volume_;             // relative audio volume (8.8)
  uint16_t reserved3_;
  uint32_t matrix_[9];          // transformation matrix
  uint32_t width_;              // visual presentation width (16.16)
  uint32_t height_;             // visual presentation height (16.16)
};

struct tref_t
{
  tref_t();

  struct type_t
  {
    type_t()
    {
    }

    type_t(uint32_t reference_type, std::vector<uint32_t> const& track_ids)
    : reference_type_(reference_type)
    , track_ids_(track_ids)
    {
    }

    uint32_t reference_type_;
    std::vector<uint32_t> track_ids_;
  };
  typedef std::vector<type_t> types_t;
  types_t types_;
};

struct is_reference_type : public std::unary_function<tref_t::type_t, bool>
{
  is_reference_type(uint32_t reference_type)
  : reference_type_(reference_type)
  {
  }

  bool operator()(tref_t::type_t const& rhs) const
  {
    return reference_type_ == rhs.reference_type_;
  }

private:
  uint32_t reference_type_;
};

struct mdhd_t
{
  mdhd_t(uint64_t creation_time);

  unsigned int version_;
  unsigned int flags_;
  uint64_t creation_time_;      // seconds since midnite, Jan .1 1904 (UTC)
  uint64_t modification_time_;  // seconds since midnite, Jan .1 1904 (UTC)
  uint32_t timescale_;          // time units that pass in one second
  uint64_t duration_;           // duration of this media
  char language_[3];            // language code for this media (ISO 639-2/T)
  uint16_t predefined_;
};

struct hdlr_t
{
  hdlr_t();

  uint32_t handler_type_;       // format of the contents ('vide', 'soun', ...)
  std::string name_;            // human-readable name for the track type (UTF8)

  bool is_video() const;
  bool is_audio() const;
  bool is_text() const;
  bool is_data() const;
};

struct MP4_DLL_EXPORT stsd_t
{
public:
  stsd_t();
  stsd_t(stsd_t const& rhs);
  stsd_t& operator=(stsd_t rhs);
  ~stsd_t();

  fmp4_result add_entry(std::string const& type, sample_entry_t*& entry);

  unsigned int version_;
  unsigned int flags_;
  std::vector<uint8_t> data_;

  typedef std::vector<sample_entry_t*> sample_entries_t;
  sample_entries_t sample_entries_;
};

struct stts_table_t
{
  stts_table_t()
  {
  }

  stts_table_t(uint32_t sample_count, uint32_t sample_duration)
  : sample_count_(sample_count)
  , sample_duration_(sample_duration)
  {
  }

  uint32_t sample_count_;
  uint32_t sample_duration_;
};

struct stts_t
{
  void insert(uint32_t sample_duration);

  typedef std::vector<stts_table_t> table_t;
  table_t table_;
};
MP4_DLL_LOCAL extern unsigned int stts_get_sample(stts_t const& stts, uint64_t time);
MP4_DLL_LOCAL extern uint64_t stts_get_time(stts_t const& stts, unsigned int sample);
MP4_DLL_LOCAL extern uint64_t stts_get_duration(stts_t const& stts);
MP4_DLL_LOCAL extern unsigned int stts_get_samples(stts_t const& stts);

struct stss_t
{
  typedef std::vector<uint32_t> sync_samples_t;
  sync_samples_t sync_samples_;
};
MP4_DLL_LOCAL extern
unsigned int stss_get_nearest_keyframe(stss_t const& stss, unsigned int sample);

struct stsc_table_t
{
  stsc_table_t()
  {
  }

  stsc_table_t(uint32_t first_chunk, uint32_t samples_per_chunk,
               uint32_t sample_description_index)
  : first_chunk_(first_chunk)
  , samples_per_chunk_(samples_per_chunk)
  , sample_description_index_(sample_description_index)
  {
  }

  uint32_t first_chunk_;
  uint32_t samples_per_chunk_;
  uint32_t sample_description_index_;
};

struct stsc_t
{
  void insert(uint32_t first_chunk, uint32_t samples_per_chunk,
              uint32_t sample_description_index);

  typedef std::vector<stsc_table_t> table_t;
  table_t table_;
};

struct stsz_t
{
  stsz_t();
  uint32_t sample_size_;
  uint32_t sample_count_;
  typedef std::vector<uint32_t> sample_sizes_t;
  sample_sizes_t sample_sizes_;
};

struct stco_t
{
  typedef std::vector<uint64_t> chunk_offsets_t;
  chunk_offsets_t chunk_offsets_;

  unsigned char* stco_inplace_; // newly generated stco (patched inplace)
};

struct ctts_table_t
{
  ctts_table_t()
  {
  }

  ctts_table_t(uint32_t sample_count, int32_t sample_offset)
  : sample_count_(sample_count)
  , sample_offset_(sample_offset)
  {
  }

  uint32_t sample_count_;
  int32_t sample_offset_;
};

struct ctts_t
{
  ctts_t();
  void insert(int32_t sample_offset);

  unsigned int version_;
  typedef std::vector<ctts_table_t> table_t;
  table_t table_;
};
MP4_DLL_EXPORT extern unsigned int ctts_get_samples(ctts_t const& ctts);

struct stbl_t
{
  stbl_t();
  ~stbl_t();

  unknown_atoms_t unknown_atoms_;
  stsd_t stsd_;                 // sample description
  stts_t stts_;                 // decoding time-to-sample
  stss_t stss_;                 // sync sample
  stsc_t stsc_;                 // sample-to-chunk
  stsz_t stsz_;                 // sample size
  stco_t stco_;                 // chunk offset
  ctts_t ctts_;                 // composition time-to-sample
};
MP4_DLL_LOCAL extern
unsigned int stbl_get_nearest_keyframe(stbl_t const& stbl, unsigned int sample);

struct dref_table_t
{
  dref_table_t(uint32_t flags, std::string const& name,
               std::string const& location);

  unsigned int flags_;          // 0x000001 is self contained
  std::string name_;            // name is a URN
  std::string location_;        // location is a URL
};

struct dref_t
{
  dref_t();
  ~dref_t();

  unsigned int version_;
  unsigned int flags_;
  typedef std::vector<dref_table_t> table_t;
  table_t table_;
};

struct dinf_t
{
  dinf_t();
  ~dinf_t();

  unknown_atoms_t unknown_atoms_;
  dref_t dref_;                 // declares the location of the media info
};

struct minf_t
{
  minf_t();
  minf_t(minf_t const& rhs);
  ~minf_t();

  unknown_atoms_t unknown_atoms_;
  struct vmhd_t* vmhd_;
  struct smhd_t* smhd_;
  struct nmhd_t* nmhd_;
  struct hmhd_t* hmhd_;
  dinf_t dinf_;
  stbl_t stbl_;
};

struct mdia_t
{
  mdia_t(uint64_t creation_time);
  ~mdia_t();

  unknown_atoms_t unknown_atoms_;
  mdhd_t mdhd_;
  hdlr_t hdlr_;
  minf_t minf_;
};

enum
{
  SAMPLE_IS_SYNC_SAMPLE       = 0x00000000,
  SAMPLE_IS_DIFFERENCE_SAMPLE = 0x00010000
};

struct sample_t
{
  // decoding/presentation time
  uint64_t pts_;

  // composition time offset
  int32_t cto_;
//uint32_t duration_;

  uint32_t sample_description_index_;

  // byte offset
  uint64_t pos_;

  // size in bytes
  uint32_t size_;

  uint32_t depends_on() const
  {
    return (flags_ >> 24) & 3;
  }

  uint32_t is_depended_on() const
  {
    return (flags_ >> 22) & 3;
  }

  bool is_difference_sample() const
  {
    return (flags_ >> 16) & 1;
  }

  bool is_sync_sample() const
  {
    return !is_difference_sample();
  }

  uint32_t degradation_priority() const
  {
    return flags_ & 0xffff;
  }

  void set_is_sync_sample(bool is_sync_sample)
  {
    flags_ &= 0xfff8ffff;
    flags_ |= static_cast<uint32_t>(!is_sync_sample) << 16;
  }

  uint32_t flags_;              // sample flags
};

struct edts_t;

struct MP4_DLL_EXPORT trak_t
{
private:
  trak_t& operator=(trak_t const& rhs);

public:
  trak_t(url_t const& url, uint64_t creation_time = 0);
  trak_t(trak_t const& rhs);
  ~trak_t();

  unknown_atoms_t unknown_atoms_;
  tkhd_t tkhd_;
  tref_t tref_;
  mdia_t mdia_;
  edts_t* edts_;

  unsigned int samples_size_;
  sample_t* samples_;

  // the samples are in this file when self-contained
  url_t url_;
};
MP4_DLL_EXPORT extern
void trak_bitrate(trak_t const& trak, uint32_t& avg_bitrate,
                  uint32_t& max_bitrate);

MP4_DLL_LOCAL extern
fmp4_result trak_get_location(trak_t const& trak,
                              unsigned int sample_description_index,
                              url_t& location);

struct elst_t
{
  struct entry_t
  {
    entry_t()
    {
    }

    entry_t(uint64_t segment_duration, int64_t media_time)
    : segment_duration_(segment_duration)
    , media_time_(media_time)
    , media_rate_integer_(1)
    , media_rate_fraction_(0)
    {
    }

    uint64_t segment_duration_;
    int64_t media_time_;
    int16_t media_rate_integer_;
    int16_t media_rate_fraction_;
  };

  elst_t();
  ~elst_t();

  uint64_t get_initial_delay() const;

#if 0
  int64_t get_time_offset(uint32_t moov_timescale,
                          uint32_t trak_timescale) const;
#endif

  typedef std::vector<entry_t> table_t;
  table_t table_;
};

struct edts_t
{
  edts_t();
  edts_t(edts_t const& rhs);
  ~edts_t();

  unknown_atoms_t unknown_atoms_;
  elst_t* elst_;
};

struct MP4_DLL_EXPORT vmhd_t
{
  vmhd_t();

  unsigned int version_;
  unsigned int flags_;
  uint16_t graphics_mode_;      // composition mode (0=copy)
  uint16_t opcolor_[3];
};

struct MP4_DLL_EXPORT smhd_t
{
  smhd_t();

  unsigned int version_;
  unsigned int flags_;
  uint16_t balance_;            // place mono audio tracks in stereo space (8.8)
  uint16_t reserved_;
};

struct nmhd_t
{
};

struct hmhd_t
{
  hmhd_t();

  // size of the largest PDU in hint stream (in bytes).
  uint16_t max_pdu_size_;

  // average size of a PDU in entires presentation (in bytes).
  uint16_t avg_pdu_size_;

  // maximum rate over an interval of 1 second (in bits per second).
  uint32_t max_bitrate_;

  // average rate over entire presentation (in bits per second).
  uint32_t avg_bitrate_;
};

struct MP4_DLL_EXPORT avcC_t
{
  typedef std::vector<uint8_t> sps_t;
  typedef std::vector<uint8_t> pps_t;
  typedef std::vector<sps_t> spss_t;
  typedef std::vector<pps_t> ppss_t;

  avcC_t();

  std::vector<uint8_t> get_priv_data() const;

  unsigned int configuration_version_;
  unsigned int profile_indication_;
  unsigned int profile_compatibility_;
  unsigned int level_indication_;
  unsigned int nal_unit_length_;
  spss_t sps_;
  ppss_t pps_;
};

MP4_DLL_EXPORT
void write_decoder_configuration_record(memory_writer& mem_writer,
                                        avcC_t const& avcC);

MP4_DLL_EXPORT
std::size_t sizeof_decoder_configuration_record(avcC_t const& avcC);


MP4_DLL_EXPORT extern
fmp4_result avcC_from_sps_pps(avcC_t& avcC,
                              uint8_t const* first, uint8_t const* last,
                              unsigned int nal_unit_length);

struct vc1_sequence_header_b_t
{
  uint8_t data_[12];
};
struct vc1_sequence_header_c_t
{
  uint8_t data_[4];
};
struct vc1_adv_dec_spec_t
{
  vc1_adv_dec_spec_t();

  unsigned int level_;
  unsigned int cbr_;
  unsigned int no_interlace_;
  unsigned int no_multiple_seq_;
  unsigned int no_multiple_entry_;
  unsigned int no_slice_code_;
  unsigned int no_bframe_;
  unsigned int framerate_;
//std::string seqhdr_ephdr;
};

struct dvc1_t
{
  dvc1_t();

  unsigned int profile_;
  unsigned int level_;

  // simple / main
  vc1_sequence_header_c_t sequence_header_c_;
  vc1_sequence_header_b_t sequence_header_b_;

  // advanced
  vc1_adv_dec_spec_t adv_dec_spec_;
};

// ISO/IEC 14496-15:2013(E) Third edition
struct hvcC_t
{
  struct array_t
  {
    typedef std::vector<uint8_t> nal_units_t;

    unsigned int completeness_;
    uint8_t nal_unit_type_;
    uint16_t num_nalus_;
    nal_units_t nal_units_;
  };
  typedef std::vector<array_t> arrays_t;

  hvcC_t();

  std::vector<uint8_t> get_priv_data() const;

  unsigned int configuration_version_;
  unsigned int general_profile_space_;
  unsigned int general_tier_flag_;
  unsigned int general_profile_idc_;
  uint32_t general_profile_compatibility_flags_;
  uint8_t general_constraint_indicator_flags_[6];
  uint8_t general_level_idc_;
  unsigned int min_spatial_segmentation_idc_;
  unsigned int parallelism_type_;
  unsigned int chroma_format_;
  unsigned int bit_depth_luma_minus_8_;
  unsigned int bit_depth_chroma_minus_8_;
  uint16_t avg_framerate_;
  unsigned int constant_framerate_;
  unsigned int num_temporal_layers_;
  unsigned int temporal_id_nested_;
  unsigned int length_size_minus_one_;
  arrays_t arrays_;
};

struct mux_hint_process_entry_t
{
  enum
  {
    MHPE_TRAILER_LENGTH    = 0x80,
    MHPE_LENGTH            = 0x40,
    MHPE_MODE              = 0x20,
    MHPE_CONSTRUCTOR_COUNT = 0x10,
    MHPE_PACKET_COUNT      = 0x08,
    MHPE_RESERVED          = 0x07
  };

  mux_hint_process_entry_t(uint8_t hint_track_mode, uint8_t flags,
                           uint8_t trailer_default_size)
  : hint_track_mode_(hint_track_mode)
  , flags_(flags)
  , trailer_default_size_(trailer_default_size)
  {
  }

  uint8_t hint_track_mode_;
  uint8_t flags_;
  uint8_t trailer_default_size_;
};

struct amhp_t
{
  typedef std::vector<mux_hint_process_entry_t> entries_t;
  std::vector<mux_hint_process_entry_t> entries_;
};

struct rtmp_t
{
  uint16_t hint_track_version_;
  uint16_t highest_compatible_version_;
  uint16_t max_packet_size_;
  amhp_t amhp_;
};

struct frma_t                   // original format box
{
  frma_t();
  ~frma_t();

  uint32_t fourcc_;
};

struct MP4_DLL_EXPORT sinf_t    // protection scheme information box
{
  sinf_t();
  sinf_t(sinf_t const& rhs);
  ~sinf_t();

  unknown_atoms_t unknown_atoms_;
  unsigned int version_;
  unsigned int flags_;
  frma_t frma_;
  struct schm_t* schm_;
  struct schi_t* schi_;
};

struct MP4_DLL_EXPORT schm_t    // scheme type box
{
  schm_t();
  ~schm_t();

  uint32_t scheme_type_;
  unsigned int major_version_;
  unsigned int minor_version_;
  std::string scheme_uri_;
};

struct MP4_DLL_EXPORT schi_t    // scheme information box
{
  schi_t();
  schi_t(schi_t const& rhs);
  ~schi_t();

  unknown_atoms_t unknown_atoms_;
  unsigned int version_;
  unsigned int flags_;
  tenc_t* tenc_;
  struct adkm_t* adkm_;
};

// The track encryption box is also used for:
// the CencSampleEncryptionInformationVideoGroupEntry (seig) and
// the CencSampleEncryptionInformationAudioGroupEntry (seig).
struct MP4_DLL_EXPORT tenc_t
{
  tenc_t();
  tenc_t(uint32_t is_encrypted, uint8_t iv_size, uint128_t const& kid);

  uint32_t is_encrypted_:24;    // 0=not encrypted, 1=encrypted
  uint8_t iv_size_:8;           // default initialization vector size (in bytes)
  uint128_t kid_;               // default key identifier for this track
};

struct MP4_DLL_EXPORT senc_t
{
  senc_t();
  senc_t(bool use_subsample_encryption, uint32_t is_encrypted,
         uint8_t iv_size, uint128_t const& kid);

  unsigned int flags_;
  uint32_t algorithm_id_;
  unsigned int iv_size_;
  uint128_t kid_;

  struct sample_t
  {
    uint8_t iv_[16];
    typedef std::pair<uint16_t, uint32_t> clear_encrypted_pair_t;
    typedef std::vector<clear_encrypted_pair_t> pairs_t;
    pairs_t pairs_;
  };

  typedef std::vector<sample_t> samples_t;
  samples_t samples_;
};

// Sample To Group Box
struct MP4_DLL_LOCAL sbgp_t
{
  struct entry_t
  {
    uint32_t sample_count_;
    uint32_t group_description_index_;
  };

  uint32_t grouping_type_;      // criterion used to form the sample groups

  // subtype of the grouping.
  uint32_t grouping_type_parameter_;

  typedef std::vector<entry_t> table_t;
  table_t table_;
};

// Sample Group Description Box
struct MP4_DLL_LOCAL sgpd_t
{
  uint32_t grouping_type_;
  uint32_t default_length_;
  uint32_t entry_count_;
  // while(entry_count_--)
  //   if(version == 1)
  //     if(default_length_ == 0)
  //       description_length = read_32()
  //   VisualSampleGroupEntry(grouping_type)[description_length]
};

// CencSampleEncryptionInformationVideoGroupEntry
struct MP4_DLL_LOCAL seig_t
{
  uint32_t is_encrypted_;
  uint8_t iv_size_;
  uint128_t kid_;
};

// CencKeyRotSampleEncryptionInformationVideoGroupEntry
struct MP4_DLL_LOCAL serg_t
{
  uint32_t is_encrypted_;
  uint8_t iv_size_;
  uint128_t kid_;               // the long-term key
  uint32_t keysize_;            // the short-term key
  std::vector<uint8_t> encrypted_key_;
};

struct MP4_DLL_EXPORT sample_entry_t
{
private:
  sample_entry_t& operator=(sample_entry_t rhs);

public:
  sample_entry_t();
  virtual ~sample_entry_t();
  virtual sample_entry_t* clone() const;

  virtual std::size_t write(mp4_writer_t& mp4_writer, memory_writer& mem_writer) const;
  virtual std::size_t size(mp4_writer_t& mp4_writer) const;

  uint32_t fourcc_;
  unsigned int data_reference_index_;

  std::vector<uint8_t> private_data_;

  // sound (WAVEFORMATEX) structure
  uint16_t wFormatTag;
//  uint16_t nChannels;
//  uint32_t nSamplesPerSec;
  uint32_t nAvgBytesPerSec;
//  uint16_t nBlockAlign;
//  uint16_t wBitsPerSample;

//  unsigned int samplerate_hi_;
//  unsigned int samplerate_lo_;

  // esds
  uint8_t object_type_id_;
  uint32_t buffer_size_db_;
  uint32_t max_bitrate_;
  uint32_t avg_bitrate_;

  // protection scheme information box
  typedef std::list<sinf_t> sinfs_t;
  sinfs_t sinfs_;

  unknown_atoms_t unknown_atoms_;

  void set_private_data(uint8_t const* data, std::size_t size);
  sinfs_t::const_iterator find_sinf(uint32_t scheme_type) const;

  // returns the four-character code of the original un-transformed
  // sample description.
  uint32_t get_original_fourcc() const;
};

struct MP4_DLL_EXPORT video_sample_entry_t : public sample_entry_t
{
public:
  video_sample_entry_t();
  video_sample_entry_t(video_sample_entry_t const& rhs);
  ~video_sample_entry_t();
  virtual sample_entry_t* clone() const;

  virtual std::size_t write(mp4_writer_t& mp4_writer, memory_writer& mem_writer) const;
  virtual std::size_t size(mp4_writer_t& mp4_writer) const;

//  void from_avcC(uint8_t const* first, uint8_t const* last);
  void from_vc1_seqhdr(uint8_t const* first, uint8_t const* last);

  uint16_t width_;
  uint16_t height_;
  uint32_t horiz_resolution_;   // pixels per inch (16.16)
  uint32_t vert_resolution_;    // pixels per inch (16.16)
  uint32_t data_size_;
  uint16_t frame_count_;        // number of frames in each sample
  std::string compressor_name_; // informative purposes (pascal string)
  uint16_t depth_;              // images are in colour with no alpha (24)

  avcC_t* avcC_;
  dvc1_t* dvc1_;
  hvcC_t* hvcC_;
};

struct MP4_DLL_EXPORT audio_sample_entry_t : public sample_entry_t
{
public:
  audio_sample_entry_t();
  virtual sample_entry_t* clone() const;

  virtual std::size_t write(mp4_writer_t& mp4_writer, memory_writer& mem_writer) const;
  virtual std::size_t size(mp4_writer_t& mp4_writer) const;

//  uint16_t version_;
//  uint16_t revision_;
//  uint32_t vendor_;
  uint16_t channel_count_;      // mono(1), stereo(2)
  uint16_t sample_size_;        // (bits)
  uint16_t compression_id_;
  uint16_t packet_size_;
  uint32_t samplerate_;         // sampling rate (16.16)
};

struct text_sample_entry_t : public sample_entry_t
{
public:
  text_sample_entry_t();
  virtual sample_entry_t* clone() const;

  virtual std::size_t write(mp4_writer_t& mp4_writer, memory_writer& mem_writer) const;
  virtual std::size_t size(mp4_writer_t& mp4_writer) const;

  uint32_t display_flags_;
  uint32_t justification_;
  uint16_t background_color_[3];
  uint16_t text_box_top_;
  uint16_t text_box_left_;
  uint16_t text_box_bottom_;
  uint16_t text_box_right_;
};

struct MP4_DLL_EXPORT hint_sample_entry_t : public sample_entry_t
{
public:
  hint_sample_entry_t();
  hint_sample_entry_t(hint_sample_entry_t const& rhs);
  ~hint_sample_entry_t();
  virtual sample_entry_t* clone() const;

  virtual std::size_t write(mp4_writer_t& mp4_writer, memory_writer& mem_writer) const;
  virtual std::size_t size(mp4_writer_t& mp4_writer) const;

  rtmp_t* rtmp_;
};

struct unknown_sample_entry_t : public sample_entry_t
{
public:
  unknown_sample_entry_t();
  virtual sample_entry_t* clone() const;

  virtual std::size_t write(mp4_writer_t& mp4_writer, memory_writer& mem_writer) const;
  virtual std::size_t size(mp4_writer_t& mp4_writer) const;

  std::vector<uint8_t> data_;
};

enum h264_profile_t
{
  H264_PROFILE_BASELINE = 66,
  H264_PROFILE_MAIN = 77,
  H264_PROFILE_EXTENDED = 88,
  H264_PROFILE_HIGH = 100,
  H264_PROFILE_HIGH10 = 110,
  H264_PROFILE_HIGH422 = 122,
  H264_PROFILE_HIGH444 = 144,
  H264_PROFILE_HIGH444_PREDICTIVE = 244
};

enum vc1_profile_t
{
  VC1_PROFILE_SIMPLE = 0,
  VC1_PROFILE_MAIN = 4,
  VC1_PROFILE_ADVANCED = 12
};

struct MP4_DLL_LOCAL audio_specific_config_t
{
  uint32_t object_type_;
  uint32_t sampling_frequency_index_;
  uint32_t sampling_frequency_;
  uint32_t channel_configuration_;
  int sbr_present_;
  int ps_present_;
  uint32_t extension_object_type_;
  uint32_t extension_sampling_frequency_index_;
};
MP4_DLL_LOCAL extern
void get_audio_specific_config(audio_specific_config_t& config,
                               std::vector<uint8_t> const& data);

MP4_DLL_LOCAL extern
int mp4_samplerate_to_index(unsigned int samplerate);

MP4_DLL_EXPORT extern
fmp4_result create_adts(std::vector<uint8_t> const& priv_data,
                        unsigned int sample_size, uint8_t* buf);

// MP4_DLL_EXPORT extern
// uint8_t* create_aac_sequence_header(unsigned int samplerate,
//                                     unsigned int channels,
//                                     uint8_t* buf);

enum rescale_rounding_t
{
  RESCALE_FLOOR,
  RESCALE_ROUND,
  RESCALE_CEIL
};

// TODO: The default should be RESCALE_ROUND, but let's do this one at a time
// since we need to update/validate all our reference files
MP4_DLL_EXPORT extern
int32_t rescale_time(int32_t t, uint32_t dst_timescale,
                     uint32_t src_timescale,
                     rescale_rounding_t rounding = RESCALE_FLOOR);
MP4_DLL_EXPORT extern
uint32_t rescale_time(uint32_t t, uint32_t dst_timescale,
                      uint32_t src_timescale,
                      rescale_rounding_t rounding = RESCALE_FLOOR);
MP4_DLL_EXPORT extern
uint64_t rescale_time(uint64_t t, uint32_t dst_timescale,
                      uint32_t src_timescale,
                      rescale_rounding_t rounding = RESCALE_FLOOR);
MP4_DLL_EXPORT extern
int64_t rescale_time(int64_t t, uint32_t dst_timescale,
                     uint32_t src_timescale,
                     rescale_rounding_t rounding = RESCALE_FLOOR);

struct mehd_t
{
  mehd_t();

  uint64_t duration_;
};

struct MP4_DLL_EXPORT trex_t
{
  trex_t();

  trex_t(uint32_t track_id, uint32_t description_index,
         uint32_t duration, uint32_t size, uint32_t flags)
  : track_id_(track_id)
  , default_sample_description_index_(description_index)
  , default_sample_duration_(duration)
  , default_sample_size_(size)
  , default_sample_flags_(flags)
  {
  }

  uint32_t track_id_;
  uint32_t default_sample_description_index_;
  uint32_t default_sample_duration_;
  uint32_t default_sample_size_;
  uint32_t default_sample_flags_;
};

struct MP4_DLL_EXPORT mvex_t
{
  mvex_t();
  ~mvex_t();

  trex_t const* find(uint32_t track_id) const;

  unknown_atoms_t unknown_atoms_;
  struct mehd_t* mehd_;
  typedef std::vector<trex_t*> trexs_t;
  trexs_t trexs_;
};

struct mfhd_t
{
  mfhd_t();

  // the ordinal number of this fragment, in increasing order
  uint32_t sequence_number_;
};

struct traf_t;

struct MP4_DLL_EXPORT moof_t
{
private:
  moof_t(moof_t const& rhs);
  moof_t& operator=(moof_t const& rhs);

public:
  moof_t();
  ~moof_t();

  traf_t* find(uint32_t track_id);

  unknown_atoms_t unknown_atoms_;
  mfhd_t mfhd_;
  typedef std::vector<traf_t*> trafs_t;
  trafs_t trafs_;
};
MP4_DLL_EXPORT extern
traf_t& moof_add_track_vod(moof_t& moof, unsigned int track_id);
MP4_DLL_EXPORT extern
traf_t& moof_add_track_live(moof_t& moof, unsigned int track_id,
                            uint64_t dts, uint64_t duration);
uint32_t moof_get_duration(uint8_t const* first, uint8_t const* last,
                           uint32_t track_id);
MP4_DLL_EXPORT extern bool is_encrypted(moof_t const& moof);

enum
{
  TFHD_BASE_DATA_OFFSET         = 0x000001,
  TFHD_SAMPLE_DESCRIPTION_INDEX = 0x000002,
  TFHD_DEFAULT_SAMPLE_DURATION  = 0x000008,
  TFHD_DEFAULT_SAMPLE_SIZE      = 0x000010,
  TFHD_DEFAULT_SAMPLE_FLAGS     = 0x000020,
  TFHD_DEFAULT_BASE_IS_MOOF     = 0x020000
};

struct tfhd_t
{
  tfhd_t();

  uint32_t flags_;
  uint32_t track_id_;
  // all the following are optional fields
  uint64_t base_data_offset_;
  uint32_t sample_description_index_;
  uint32_t default_sample_duration_;
  uint32_t default_sample_size_;
  uint32_t default_sample_flags_;
};

struct MP4_DLL_EXPORT traf_t
{
private:
  traf_t(traf_t const& rhs);
  traf_t& operator=(traf_t const& rhs);

public:
  traf_t();
  ~traf_t();

  // returns the sum of all the tracks run durations.
  uint32_t get_duration() const;

  // returns the sum of all the tracks run sizes.
  uint32_t get_size() const;

  unknown_atoms_t unknown_atoms_;
  tfhd_t tfhd_;
  struct tfxd_t* tfxd_;
  struct tfdt_t* tfdt_;
  uint8_t const* saiz_;
  uint8_t const* saio_;
  struct senc_t* senc_;
  typedef std::vector<struct trun_t*> truns_t;
  truns_t truns_;
  struct tfrf_t* tfrf_;
};
MP4_DLL_LOCAL extern void traf_update(traf_t& traf);

struct tfra_table_t
{
  tfra_table_t()
  {
  }

  tfra_table_t(uint64_t time, uint64_t moof_offset, uint32_t traf_number,
               uint32_t trun_number, uint32_t sample_number)
  : time_(time)
  , moof_offset_(moof_offset)
  , traf_number_(traf_number)
  , trun_number_(trun_number)
  , sample_number_(sample_number)
  {
  }

  uint64_t time_;
  uint64_t moof_offset_;
  uint32_t traf_number_;
  uint32_t trun_number_;
  uint32_t sample_number_;
};

MP4_DLL_EXPORT extern
bool operator<(tfra_table_t const& lhs, tfra_table_t const& rhs);

struct MP4_DLL_EXPORT tfra_t
{
private:
  tfra_t(tfra_t const& rhs);
  tfra_t& operator=(tfra_t const& rhs);

public:
  typedef std::vector<tfra_table_t> table_t;

  tfra_t();

  table_t::const_iterator find(uint64_t time) const;
  table_t::const_iterator find_lower_bound(uint64_t time) const;

  uint32_t track_id_;
  unsigned int length_size_of_traf_num_;
  unsigned int length_size_of_trun_num_;
  unsigned int length_size_of_sample_num_;
  table_t table_;
};

struct MP4_DLL_EXPORT mfra_t
{
public:
  mfra_t();
  ~mfra_t();

  fmp4_result find(uint32_t track_id, tfra_t*& tfra) const;

  unknown_atoms_t unknown_atoms_;
  typedef std::vector<tfra_t*> tfras_t;
  tfras_t tfras_;
};
MP4_DLL_EXPORT extern
fmp4_result mfra_get_size(fmp4_handler_io_t& src_io, uint64_t offset,
                          uint32_t* moof_size, uint32_t* mdat_size);
MP4_DLL_EXPORT extern
fmp4_result mfra_read(fmp4_handler_io_t& src_io, io_buf_ptr& mfra_data);
MP4_DLL_EXPORT extern
fmp4_result mfra_read(fmp4_handler_io_t& src_io, mfra_t& mfra);

enum {
  TRUN_DATA_OFFSET                    = 0x000001,
  TRUN_FIRST_SAMPLE_FLAGS             = 0x000004,
  TRUN_SAMPLE_DURATION                = 0x000100,
  TRUN_SAMPLE_SIZE                    = 0x000200,
  TRUN_SAMPLE_FLAGS                   = 0x000400,
  TRUN_SAMPLE_COMPOSITION_TIME_OFFSET = 0x000800
};

struct MP4_DLL_EXPORT trun_t
{
  struct sample_t
  {
    sample_t(uint32_t duration, uint32_t size, uint32_t flags, int32_t cto)
    : duration_(duration)
    , size_(size)
    , flags_(flags)
    , composition_time_offset_(cto)
    {
    }

    uint32_t duration_;
    uint32_t size_;
    uint32_t flags_;
    int32_t composition_time_offset_;

    static uint32_t create_flags(unsigned int frame_type);
  };

  trun_t();

  // returns the total duration of the samples specified in the tracks run.
  uint32_t get_duration() const;

  // returns the total size of the samples specified in the tracks run.
  uint32_t get_size() const;

  void insert(uint32_t duration, uint32_t size, uint32_t flags, int32_t cto);

  unsigned int version_;
  unsigned int flags_;
  // the offset that is added to the implicit or explicit data_offset
  // established in the track fragment header
  int32_t data_offset_;
  // provides a set of flags for the first sample only of this run
  uint32_t first_sample_flags_;

  typedef std::vector<sample_t> samples_t;
  samples_t samples_;
};

struct MP4_DLL_EXPORT tfxd_t
{
  tfxd_t();

  uint64_t pts_;
  uint64_t duration_;
};

struct tfdt_t
{
  tfdt_t();

  uint64_t pts_;
};

struct time_duration_pair_t
{
  time_duration_pair_t(uint64_t time, uint64_t duration)
  : time_(time)
  , duration_(duration)
  {
  }

  uint64_t time_;
  uint64_t duration_;
};

struct tfrf_t
{
  tfrf_t(std::size_t entries);

  typedef std::vector<time_duration_pair_t> time_duration_pairs_t;
  time_duration_pairs_t time_duration_pairs_;
};

struct saiz_t
{
  saiz_t();

  uint32_t aux_info_type_;
  uint32_t aux_info_type_parameter_;
  unsigned int default_sample_info_size_;
  unsigned int samples_;
  typedef std::vector<uint8_t> sizes_t;
  sizes_t sizes_;
};

struct saio_t
{
  saio_t();

  uint32_t aux_info_type_;
  uint32_t aux_info_type_parameter_;

  // for a saio box appearing in a stbl there must be a single entry or the
  // same number of entries as the stco box. The offsets are absolute.
  // 
  // For a saio box appearing in a traf there must be a single entry or the
  // same number of truns. The offsets are relative to the base offset
  // established by the tfhd box.
  typedef std::vector<uint64_t> offsets_t;
  offsets_t offsets_;
};

struct MP4_DLL_EXPORT sidx_t
{
  sidx_t();

  uint32_t track_id_;
  uint32_t timescale_;
  uint64_t earliest_presentation_time_;
  uint64_t first_offset_;
  struct index_t
  {
    uint32_t reference_type_ : 1;
    uint32_t reference_size_ : 31;
    uint32_t subsegment_duration_;
    uint32_t starts_with_sap_ : 1;
    uint32_t sap_type_ : 3;
    uint32_t sap_delta_time_ : 28;
  };
  typedef std::vector<index_t> indexes_t;
  indexes_t indexes_;
};

// random access structure similar to mfra, but with size field
struct rxs_t
{
  uint64_t time_;
  uint64_t offset_;
  uint64_t size_;
};

#define MP4_ELEMENTARY_STREAM_DESCRIPTOR_TAG   3
#define MP4_DECODER_CONFIG_DESCRIPTOR_TAG      4
#define MP4_DECODER_SPECIFIC_DESCRIPTOR_TAG    5

#define MP4_MPEG4Audio                      0x40  // ISO 14496-3
#define MP4_MPEG2AudioMain                  0x66  // ISO 13818-7 Main Profile
#define MP4_MPEG2AudioLowComplexity         0x67  // ISO 13818-7 LowComplexity
#define MP4_MPEG2AudioScaleableSamplingRate 0x68  // ISO 13818-7 SSR
#define MP4_MPEG2AudioPart3                 0x69  // ISO 13818-3
#define MP4_MPEG1Audio                      0x6b  // ISO 11172-3

struct MP4_DLL_EXPORT mp4_context_t
{
private:
  mp4_context_t(mp4_context_t const& rhs);
  mp4_context_t& operator=(mp4_context_t const& rhs);

public:
  mp4_context_t(int verbose);
  ~mp4_context_t();

  int verbose_;

  // the actual binary data
  std::vector<uint8_t> ftyp_data_;

  // BaseLocationBox
  bloc_t* bloc_;

  // the parsed atoms
  moov_t* moov_;

  //
  sidx_t* sidx_;

  typedef std::list<moof_t*> moofs_t;
  moofs_t moofs_;

  //
  mfra_t* mfra_;
};

} // namespace fmp4

#endif // MP4_IO_HPP_AKW

// End Of File


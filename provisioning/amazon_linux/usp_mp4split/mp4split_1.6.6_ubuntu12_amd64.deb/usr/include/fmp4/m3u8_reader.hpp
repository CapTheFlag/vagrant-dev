/*******************************************************************************
 m3u8_reader.hpp - A library for reading M3U8.

 Copyright (C) 2010-2014 CodeShop B.V.
 http://www.code-shop.com

 For licensing see the LICENSE file
******************************************************************************/ 

#ifndef M3U8_READER_HPP_AKW
#define M3U8_READER_HPP_AKW

#include "mod_streaming_export.h"
#include "mp4_exception.hpp"
#include "mp4_util.hpp"
#include "mp4_types.hpp"
#include <inttypes.h>
#include <string>
#include <vector>

struct mp4_process_context_t;
struct fmp4_handler_io_t;

namespace fmp4
{

namespace m3u8
{

struct stream_inf_t
{
  stream_inf_t();

  bool is_iframe_index_;
  uint32_t program_id_;
  uint32_t bandwidth_;
  std::vector<std::string> codecs_;
  uint32_t width_;
  uint32_t height_;
};

struct media_t
{
  media_t();

  std::string type_;
  std::string group_id_;
  std::string language_;
  std::string name_;
  std::string default_;
  std::string autoselect_;
  std::string forced_;
  std::string instream_id_;
  uint32_t bandwidth_;
  std::vector<std::string> codecs_;
  uint32_t width_;
  uint32_t height_;
};

struct extinf_t
{
  extinf_t();

  uint32_t media_sequence_;
  uint32_t duration_;
  std::string url_;

  std::string key_method_;
  std::string key_url_;
  bool iv_present_;
  uint128_t key_iv_;
  std::string key_format_;
};

struct playlist_t
{
  explicit playlist_t(url_t const& url);

  // the location of the (.m3u8) playlist
  url_t url_;

  // the media segments
  typedef std::vector<extinf_t> extinfs_t;
  extinfs_t extinfs_;

  // the stream info (USP-X-STREAM-INF or USP-X-I-FRAME-STREAM-INF)
  stream_inf_t stream_inf_;

  // the media info (USP-X-MEDIA)
  media_t media_;
};

struct is_url : public std::unary_function<playlist_t, bool>
{
  is_url(url_t const& url)
  : url_(url)
  {
  }

  bool operator()(playlist_t const& playlist) const
  {
    return playlist.url_ == url_;
  }

private:
  url_t url_;
};

class MP4_DLL_EXPORT manifest_t
{
private:
  manifest_t(manifest_t const& rhs);
  manifest_t& operator=(manifest_t rhs);

public:
  manifest_t(mp4_process_context_t& context, url_t const& url);
  ~manifest_t();

  fmp4_result open(char const* first, char const* last);
  fmp4_result open(fmp4_handler_io_t& src_io);
  fmp4_result open(url_t const& url);

  bool resolve_url(url_t& url) const;

public:
  mp4_process_context_t& context_;
  url_t url_;

  typedef std::vector<playlist_t> playlists_t;
  playlists_t playlists_;
};

} // m3u8

} // fmp4

#endif // M3U8_READER_HPP_AKW

// End Of File

